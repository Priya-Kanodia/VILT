package com.fidelity.timeservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * The Spring Boot Application that hosts the TimeZoneRestfulService web service.
 * 
 * @author ROI Instructor
 *
 */
@SpringBootApplication(scanBasePackages = { "com.fidelity.restservices", "com.fidelity.business" })
public class TimeZoneServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(TimeZoneServiceApplication.class, args);
	}

}
