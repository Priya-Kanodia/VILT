package com.fidelity.restservices;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fidelity.business.Book;
import com.fidelity.business.BookList;
import com.fidelity.integration.LibraryDao;


@RestController
@RequestMapping("/library")
public class LibraryService {
	@Autowired
	private LibraryDao dao;
	
	public LibraryService() {
	}

	public BookList<Book> getBooks() {
		BookList<Book> books = null;
				
		return books;
	}

	public Book getBookById(String id) {
		Book book = null;
		
		return book;
	}
}
