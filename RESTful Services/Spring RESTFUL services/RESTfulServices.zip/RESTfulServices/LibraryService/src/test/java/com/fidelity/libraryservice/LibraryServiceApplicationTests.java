package com.fidelity.libraryservice;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fidelity.restservices.LibraryService;

@SpringBootTest(classes = { LibraryServiceApplication.class })
class LibraryServiceApplicationTests {
	@Autowired 
	LibraryService service;
	
	@Test
	void contextLoads() {
	}

	@Test 
	void testServiceIsAutowired() {
		assertNotNull(service);
	}
}
