package com.fidelity.timeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
