package com.fidelity.business.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fidelity.business.Widget;
import com.fidelity.integration.WarehouseDaoMyBatisImpl;

class WarehouseBusinessServiceTest {
	@Mock
	WarehouseDaoMyBatisImpl mockDao;
	
	@InjectMocks
	WarehouseBusinessService service;
	
	@BeforeEach
	void setUp() throws Exception {
		service = new WarehouseBusinessService();
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testFindAllWidgets() {
		// Initialize the list of Widgets that will be returned by the mock DAO
		List<Widget> widgets = Arrays.asList(
			    new Widget(1, "Low Impact Widget", 12.99, 2, 3),
			    new Widget(2, "High Impact Widget", 15.99, 4, 5));

		when(mockDao.getAllWidgets())
        	.thenReturn(widgets);
		
		List<Widget> allWidgets = service.findAllWidgets();

		assertThat(allWidgets, equalTo(widgets));
	}

}
