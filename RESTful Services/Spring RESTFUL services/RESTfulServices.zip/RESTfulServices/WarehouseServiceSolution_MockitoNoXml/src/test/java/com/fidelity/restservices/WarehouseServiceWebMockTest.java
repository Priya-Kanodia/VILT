package com.fidelity.restservices;

import static org.mockito.Mockito.when;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fidelity.business.Widget;
import com.fidelity.business.service.WarehouseBusinessService;
import com.fidelity.integration.WarehouseDao;

/**
 * The WarehouseService has a dependency on the WarehouseDao. The WarehouseDao
 * will be automatically injected by Spring into the WarehouseService (because
 * of the constructor signature).
 * 
 * To test this controller with @WebMvcTest you can do this We use @MockBean to
 * create and inject a mock for the WarehouseDao (if you don’t do this the
 * application context cannot start), and we set its expectations using Mockito.
 *
 * Note that Spring Boot needs to find an application class in order to scan
 * for components. The trivial class com.fidelity.TestApplication in src/test/java 
 * contains the @SpringBootApplication annotation, which triggers the component scan.
 * 
 * @author ROI Instructor
 */

@WebMvcTest(controllers=WarehouseService.class)
public class WarehouseServiceWebMockTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private WarehouseDao dao;

	@MockBean
	WarehouseBusinessService service;
	
	private static List<Widget> widgets;

	@BeforeAll
	public static void init() {
		widgets = Arrays.asList(
			new Widget(1, "Test Widget 1", 1.99, 2, 10),
			new Widget(2, "Test Widget 2", 2.99, 4, 20)
		);
	}

	/**
	 * This test verifies the WarehouseService can query successfully for all the
	 * Widgets in the Warehouse.
	 */
	@Test
	public void testQueryForAllWidgets() throws Exception {
//		when(dao.getAllWidgets()).thenReturn(widgets);
		when(service.findAllWidgets()).thenReturn(widgets);
		
		mockMvc.perform(get("/warehouse/widgets"))
			   .andDo(print())
			   .andExpect(status().isOk())
			   .andExpect(jsonPath("$.length()").value(2))
			   .andExpect(jsonPath("$[0].description").value("Test Widget 1"))
			   .andExpect(jsonPath("$[1].description").value("Test Widget 2"));
	}

	@Test
	public void testQueryForAllWidgets_DaoReturnsEmptyList() throws Exception {
//		when(dao.getAllWidgets()).thenReturn(new ArrayList<Widget>());
		when(service.findAllWidgets()).thenReturn(new ArrayList<Widget>());
		
		mockMvc.perform(get("/warehouse/widgets"))
			   .andDo(print())
			   .andExpect(status().isNoContent())
			   .andExpect(content().string(is(emptyOrNullString())));
	}

	@Test
	public void testQueryForAllWidgets_DaoThrowsException() throws Exception {
//		when(dao.getAllWidgets()).thenThrow(new RuntimeException());
		when(service.findAllWidgets()).thenThrow(new RuntimeException());		
		mockMvc.perform(get("/warehouse/widgets"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}
	/**
	 * This test verifies the WarehouseService can successfully add a Widget to the
	 * Warehouse.
	 */
	@Test
	public void testAddWidgetToWarehouse() throws Exception {
		Widget w = new Widget(42, "Test widget", 4.52, 20, 10);
		
		when(dao.insertWidget(w)).thenReturn(1);
		
		// Creating the ObjectMapper object
		ObjectMapper mapper = new ObjectMapper();
		// Converting the Object to JSONString
		String jsonString = mapper.writeValueAsString(w);
		
		mockMvc.perform(post("/warehouse/widgets")
							.contentType(MediaType.APPLICATION_JSON)
							.content(jsonString))
			   .andDo(print())
			   .andExpect(status().isOk())
			   .andExpect(jsonPath("$.rowCount").value(1));
	}

	/**
	 * This test verifies the WarehouseService can successfully remove a Widget from
	 * the Warehouse.
	 */
	@Test
	public void testRemoveWidgetFromWarehouse() throws Exception{
		int id = 1;
		when(dao.deleteWidget(id)).thenReturn(1);
		
		mockMvc.perform(delete("/warehouse/widgets/" + id))
			   .andDo(print())
			   .andExpect(status().isOk())
			   .andExpect(jsonPath("$.rowCount").value(1));
	}

}
