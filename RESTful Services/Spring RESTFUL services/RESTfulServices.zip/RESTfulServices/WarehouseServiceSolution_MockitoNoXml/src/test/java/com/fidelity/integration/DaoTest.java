package com.fidelity.integration;

import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.jdbc.JdbcTestUtils;
import com.fidelity.business.Gadget;
import com.fidelity.business.Widget;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

/**
 * DaoTest is an integration test for WarehouseDaoMyBatisImpl.
 * 
 * Note the use of @Sql on the class to execute the database setup scripts before
 * each test case. Because @SpringBootTest runs Tomcat in a different thread than the
 * test cases themselves, @Transactional has no effect here. So we need to re-initialize 
 * the database after each test case.
 * 
 * The database scripts referenced in @Sql are in src/test/resources
 *
 * To verify that the DAO is actually working, we'll need to query the database 
 * directly, so we'll use Spring's JdbcTestUtils class, which has methods like 
 * countRowsInTable() and deleteFromTables().
 *
 * @author ROI Instructor
 *
 */
@SpringBootTest
@Sql(scripts={"/schema-dev.sql", "/data-dev.sql"},
     executionPhase=Sql.ExecutionPhase.BEFORE_TEST_METHOD) // also: AFTER_TEST_METHOD
public class DaoTest {

	@Autowired
	private WarehouseDaoMyBatisImpl dao;

	private JdbcTemplate jdbcTemplate;  // for executing SQL queries
	
	// We can't autowire a JdbcTemplate directly, but we can create an instance
	// of JdbcTemplate when a DataSource is available
	@Autowired
	void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	// Because the test database is tiny, we can check all products.
	// If the database was larger, we could just spot-check a few products.
	
	private static List<Widget> allWidgets = Arrays.asList(
		new Widget(1, "Low Impact Widget", 12.99, 2, 3),
		new Widget(2, "Medium Impact Widget", 42.99, 5, 5),
		new Widget(3, "High Impact Widget", 89.99, 10, 8)
	);

	private static List<Gadget> allGadgets = Arrays.asList(
		new Gadget(1, "Two Cylinder Gadget", 19.99, 2), 
		new Gadget(2, "Four Cylinder Gadget", 29.99, 4), 
		new Gadget(3, "Eight Cylinder Gadget", 49.99, 8) 
	);

	@Test
	void testGetAllWidgets() {
		List<Widget> widgets = dao.getAllWidgets();
		
		assertThat(widgets, is(equalTo(allWidgets)));
	}

	@Test
	void testGetWidget() {
		Widget widget = dao.getWidget(1);
		
		assertThat(widget, is(equalTo(allWidgets.get(0))));
	}

	@Test
	void testDeleteWidget() {
		int id = 1;
		// verify that Widget 1 is in the database
		assertThat(1, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "widgets", "id = " + id))));

		int rows = dao.deleteWidget(id);
		
		assertThat(rows, is(equalTo(1)));
		// verify that Widget 1 is no longer in the database
		assertThat(0, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "widgets", "id = " + id))));
	}

	@Test
	void testInsertWidget() {
		int id = 42;
		assertThat(0, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "widgets", "id = " + id))));

		Widget w = new Widget(id, "Test widget", 4.52, 20, 10);

		int rows = dao.insertWidget(w);
		
		assertThat(rows, is(equalTo(1)));
		assertThat(1, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "widgets", "id = " + id))));
	}

	@Test
	void testUpdateWidget() {
		int id = 1;
		Widget originalWidget = loadWidgetFromDb(id);
		originalWidget.setPrice(originalWidget.getPrice() + 1.0);

		int rows = dao.updateWidget(originalWidget);
		
		assertThat(rows, is(equalTo(1)));
		// reload widget from database and verify that only the price was updated
		Widget updatedWidget = loadWidgetFromDb(id);
		assertThat(originalWidget, is(equalTo(updatedWidget)));

	}

	@Test
	void testGetAllGadgets() {
		List<Gadget> gadgets = dao.getAllGadgets();
		
		assertThat(gadgets, is(equalTo(allGadgets)));
	}

	@Test
	void testGetGadget() {
		Gadget gadget = dao.getGadget(1);
		
		assertThat(gadget, is(equalTo(allGadgets.get(0))));
	}

	@Test
	void testDeleteGadget() {
		// verify that Gadget 1 is in the database
		int id = 1;
		assertThat(1, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "gadgets", "id = " + id))));

		int rows = dao.deleteGadget(id);
		
		assertThat(rows, is(equalTo(1)));
		// verify that Gadget 1 is no longer in the database
		assertThat(0, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "gadgets", "id = " + id))));
	}

	@Test
	void testInsertGadget() {
		int id = 42;
		assertThat(0, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "gadgets", "id = " + id))));

		Gadget g = new Gadget(id, "Test Gadget", 99.99, 2);

		int rows = dao.insertGadget(g);
		
		assertThat(rows, is(equalTo(1)));
		assertThat(1, is(equalTo(
			JdbcTestUtils.countRowsInTableWhere(jdbcTemplate, "gadgets", "id = " + id))));
	}

	@Test
	void testUpdateGadget() {
		int id = 1;
		Gadget originalGadget = loadGadgetFromDb(id);
		originalGadget.setCylinders(originalGadget.getCylinders() * 2);

		int rows = dao.updateGadget(originalGadget);
		
		assertThat(rows, is(equalTo(1)));
		// reload gadget from database and verify that only the cylinder count was updated
		Gadget updatedGadget = loadGadgetFromDb(id);
		assertThat(originalGadget, is(equalTo(updatedGadget)));

	}

	private Widget loadWidgetFromDb(int id) {
		String sql = "select * from widgets where id = " + id;
		
		return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> 
			new Widget(rs.getInt("id"), rs.getString("description"), rs.getDouble("price"), 
					   rs.getInt("gears"), rs.getInt("sprockets")));
	}
	
	private Gadget loadGadgetFromDb(int id) {
		String sql = "select * from gadgets where id = " + id;
		
		return jdbcTemplate.queryForObject(sql, (rs, rowNum) -> 
			new Gadget(rs.getInt("id"), rs.getString("description"), 
					   rs.getDouble("price"), rs.getInt("cylinders")));
	}
	
}
