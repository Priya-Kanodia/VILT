package com.fidelity.business.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.fidelity.business.Widget;

@SpringBootTest
@Transactional
class WarehouseBusineesServiceIntegrationTest {
	@Autowired
	WarehouseBusinessService service;
	
	// Because the test database is tiny, we can check all products.
	// If the database was larger, we could just spot-check a few products.
	
	private static List<Widget> allWidgets = Arrays.asList(
		new Widget(1, "Low Impact Widget", 12.99, 2, 3),
		new Widget(2, "Medium Impact Widget", 42.99, 5, 5),
		new Widget(3, "High Impact Widget", 89.99, 10, 8)
	);


	@Test
	void basicSanityTest() {
		assertNotNull(service);
	}

	@Test
	void testGetAllWidgets() {
		List<Widget> widgets = service.findAllWidgets();
		
		assertThat(widgets, is(equalTo(allWidgets)));
	}

}
