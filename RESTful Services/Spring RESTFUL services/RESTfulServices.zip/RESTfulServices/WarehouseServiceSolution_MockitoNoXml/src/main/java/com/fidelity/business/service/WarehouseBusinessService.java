package com.fidelity.business.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fidelity.business.Widget;
import com.fidelity.integration.WarehouseDao;

@Service
public class WarehouseBusinessService {
	@Autowired
	private WarehouseDao dao;

	public List<Widget> findAllWidgets() {
		List<Widget> widgets;
		
		try {
			widgets = dao.getAllWidgets();
		} catch (Exception e) {
			String msg = "Error querying the Warehouse database.";
			throw new WarehouseDatabaseException(msg, e);
		}
		
		return widgets;
	}

	public WarehouseDao getDao() {
		return dao;
	}

	public void setDao(WarehouseDao dao) {
		this.dao = dao;
	}
	
	
}
