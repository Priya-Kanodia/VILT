package com.fidelity.server.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.fidelity.configuration" })
public class WarehouseSpringBootServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseSpringBootServiceApplication.class, args);
	}
}
