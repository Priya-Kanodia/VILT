package com.fidelity.lambda;

import com.amazonaws.services.lambda.runtime.Context; 
import com.amazonaws.services.lambda.runtime.LambdaLogger;

public class Greeter {
    public Greetings myHandler(String name, Context context) {
        LambdaLogger logger = context.getLogger();
        logger.log("Received : " + name);
        String greeting = name + " Welcome to the Wonderful World of Lambda";
        Greetings greetings = new Greetings(greeting);
        
        return greetings;
    }
}




