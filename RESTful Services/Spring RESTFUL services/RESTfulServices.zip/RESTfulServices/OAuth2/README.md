# OAuthServer

Exercise 2.2.1: Using OAuth2 for Authorization

Step 5b: It is not necessary to do this. Just set the 3 form parameters in the body.


