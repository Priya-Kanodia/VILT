package com.fidelity.business;

import java.util.ArrayList;
import java.util.List;


public class BookList<T> {

	private List<Book> bookList;

	public BookList() {
		bookList = new ArrayList<>();
	}

	public BookList(List<Book> list) {
		bookList = list;
	}

	
	public List<Book> getItems() {
		return bookList;
	}
}
