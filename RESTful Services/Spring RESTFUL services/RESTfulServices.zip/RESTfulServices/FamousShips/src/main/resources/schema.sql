-- Schema definition for the the famous ships database

-- Drop the tables if they exist
drop table FamousShips if exists;

-- FamousShips
CREATE TABLE FamousShips(
	Id IDENTITY,
	Name varchar(50),
    Nickname varchar(50),
	Captain varchar(50),
	Description varchar(1024),
	Type varchar(50)
);

