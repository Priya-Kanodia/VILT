package com.fidelity.famousShips;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//tell Spring Boot where to scan for annotated components
@ComponentScan(basePackages={"com.fidelity.integration", "com.fidelity.restservices"})
//tell MyBatis where to scan for mapping interface files
@MapperScan(basePackages="com.fidelity.integration.mapper")  
public class FamousShipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FamousShipsApplication.class, args);
	}

}
