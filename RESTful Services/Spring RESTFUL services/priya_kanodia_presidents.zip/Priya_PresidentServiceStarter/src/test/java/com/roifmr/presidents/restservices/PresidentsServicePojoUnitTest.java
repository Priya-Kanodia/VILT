package com.roifmr.presidents.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.business.service.DatabaseException;
import com.roifmr.presidents.business.service.PresidentBusinessService;
import com.roifmr.presidents.business.service.PresidentBusinessServiceImpl;
import com.roifmr.presidents.integration.PresidentsDao;

public class PresidentsServicePojoUnitTest {


	@Mock
	static PresidentsDao mockDao;
	
	@InjectMocks
	static PresidentBusinessService service;
	
	
	@BeforeAll
	static void setUp() throws Exception {
		service = new PresidentBusinessServiceImpl();
	}
	
	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);		
	}

	List<President> presidents = Arrays.asList(
			   new President(1,"George","Washington",1789,1797,"georgewashington.jpg",
					   "On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street"
					   + " in New York, took his oath of office as the first President of the United States."
					   + " \"As the first of every thing, in our situation will serve to establish a Precedent,"
					   + "\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents "
					   + "may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman."),
			   new President(2,"John","Adams",1797,1801,"johnadams.jpg","Learned and thoughtful, John Adams was more remarkable as a "
			   		+ "political philosopher than as a politician. \"People and nations are forged in the fires of adversity,\" he said, "
			   		+ "doubtless thinking of his own as well as the American experience. Adams was born in the Massachusetts Bay Colony in 1735. "
			   		+ "A Harvard-educated lawyer, he early became identified with the patriot cause; a delegate to the First and Second Continental Congresses, he led in the movement for independence."));

	@Test
	void testFindAllPresidents() throws DatabaseException {
		when(mockDao.queryForAllPresidents())
        	.thenReturn(presidents);
		
		List<President> allPresidents = service.findAllPresidents();

		assertThat(allPresidents, equalTo(presidents));
	}

	@Test
	void testGetBiographyById() throws DatabaseException {
		int id = 1;
		 String bio = presidents.get(0).getBiography();
		
		when(mockDao.queryForPresidentBiography(id))
			.thenReturn(bio);
		
		String biography = service.getBioById(id);
		assertThat(biography, equalTo(bio));
	}

	
	@Test
	void testFindAllPresidentsThrowsException() {
		when(mockDao.queryForAllPresidents())
			.thenThrow(RuntimeException.class);

		assertThrows(DatabaseException.class, 
					() -> service.findAllPresidents());
	}

	@Test
	void testFindBioByIdThrowsException() {
		int id = 42;
		when(mockDao.queryForPresidentBiography(id))
			.thenThrow(RuntimeException.class);

		assertThrows(DatabaseException.class, 
					() -> service.getBioById(id));
	}

}
