package com.roifmr.presidents.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.jdbc.JdbcTestUtils;

import com.roifmr.presidents.PresidentsServiceApplication;
import com.roifmr.presidents.business.President;

@SpringBootTest(classes=PresidentsServiceApplication.class,webEnvironment=WebEnvironment.RANDOM_PORT)
@Sql(scripts  = {"classpath:schema.sql", "classpath:data.sql"}, 
		executionPhase=Sql.ExecutionPhase.BEFORE_TEST_METHOD) 
public class PresidentsServiceE2eTest {
	
	@Autowired
	private TestRestTemplate restTemplate;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Test
	public void testQueryForAllPresidentsOkResponseStatus() {
		String request = "/presidents/all";
		ResponseEntity<President[]> response = restTemplate.getForEntity(request, President[].class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
	
	}
	
	@Test
	public void testQueryForAllPresidentsSametotalCountReturned() {
		int count = JdbcTestUtils.countRowsInTable(jdbcTemplate, "presidents");
		
		String request = "/presidents/all";

		ResponseEntity<President[]> response = restTemplate.getForEntity(request, President[].class);
		
		President[] responsePresidents = response.getBody();
		assertThat(responsePresidents.length, is(equalTo(count))); 
		
	}
	
	@Test
	public void testQueryForAllPresidentsCheckContent() {
	
		String request = "/presidents/all";

		ResponseEntity<President[]> response = restTemplate.getForEntity(request, President[].class);
		
		// verify that the service returned all presidents database
		President[] responsePresidents = response.getBody();
		assertThat(responsePresidents[0].getFirstName(), is(equalTo("George")));
	}
	
	@Test
	public void testQueryForAllPresidentsNoContentCode() {
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		
		String request = "/presidents/all";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
	@Test
	public void testQueryForAllPresidentsNoContentHasEmptyBody() {
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		
		String request = "/presidents/all";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		assertThat(response.getBody(), is(emptyOrNullString()));
	}
	
	@Test
	public void testQueryForAllPresidentsDbException() {
		JdbcTestUtils.dropTables(jdbcTemplate, "presidents");
		
		String request = "/presidents/all";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.INTERNAL_SERVER_ERROR)));
	}
	
	@Test
	public void testQueryForGetBiographyByIdOkStatus() {
		String request = "/presidents/1";

		ResponseEntity<Bio> response = restTemplate.getForEntity(request, Bio.class);
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		
	}
	@Test
	public void testQueryForGetBiographyByIdContentCheck() {
		String request = "/presidents/1";

		ResponseEntity<Bio> response = restTemplate.getForEntity(request, Bio.class);
		assertThat(response.getBody().getBio(), is(equalTo("On April 30, 1789, George Washington, "
				+ "standing on the balcony of Federal Hall on Wall Street in New York, "
				+ "took his oath of office as the first President of the United States. "
				+ "\"As the first of every thing, in our situation will serve to establish"
				+ " a Precedent,\" he wrote James Madison, \"it is devoutly wished on my"
				+ " part, that these precedents may be fixed on true principles.\" "
				+ "Born in 1732 into a Virginia planter family, he learned the morals,"
				+ " manners, and body of knowledge requisite for an 18th century Virginia"
				+ " gentleman."
		)));
	}


	@Test
	public void testQueryForGetBiographyByIdWhenIdNotPresent() {
		String request = "/presidents/99";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}

	@Test
	public void testQueryForGetBiographyByIdWhenDbException() {
		JdbcTestUtils.dropTables(jdbcTemplate, "presidents");

		String request = "/presidents/45";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.INTERNAL_SERVER_ERROR)));
	}
	@Test
	public void testQueryForGetBiographyByIdClientErrorException() {
		String request = "/presidents/-45";

		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.BAD_REQUEST)));
	}
	

}
