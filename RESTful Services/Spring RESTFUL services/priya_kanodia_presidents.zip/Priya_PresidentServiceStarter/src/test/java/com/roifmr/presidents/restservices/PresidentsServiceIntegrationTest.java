package com.roifmr.presidents.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.test.jdbc.JdbcTestUtils;
import org.springframework.transaction.annotation.Transactional;

import com.roifmr.presidents.business.service.DatabaseException;
import com.roifmr.presidents.business.President;
import com.roifmr.presidents.business.service.PresidentBusinessService;

@SpringBootTest
@Transactional
public class PresidentsServiceIntegrationTest {

	@Autowired
	private PresidentBusinessService service;
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) throws SQLException {
		
		jdbcTemplate = new JdbcTemplate(dataSource);
		Connection connection = dataSource.getConnection();

		Resource schema = new ClassPathResource("schema.sql");
		Resource data = new ClassPathResource("data.sql");
		
		ScriptUtils.executeSqlScript(connection, schema);
		ScriptUtils.executeSqlScript(connection, data);
		
				connection.close();
	}
	
	private static List<President> allPresidents = Arrays.asList(
			  new President(1,"George","Washington",1789,1797,"georgewashington.jpg",
					   "On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street"
					   + " in New York, took his oath of office as the first President of the United States."
					   + " \"As the first of every thing, in our situation will serve to establish a Precedent,"
					   + "\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents "
					   + "may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman."),
			   new President(2,"John","Adams",1797,1801,"johnadams.jpg","Learned and thoughtful, John Adams was more remarkable as a "
			   		+ "political philosopher than as a politician. \"People and nations are forged in the fires of adversity,\" he said, "
			   		+ "doubtless thinking of his own as well as the American experience. Adams was born in the Massachusetts Bay Colony in 1735. "
			   		+ "A Harvard-educated lawyer, he early became identified with the patriot cause; a delegate to the First and Second Continental Congresses, he led in the movement for independence.")
			   );

	@Test
	void basicSanityTest() {
		assertNotNull(service);
	}


	@Test
	void testGetAllPresidents() throws DatabaseException {
		List<President> presidents = service.findAllPresidents();
		
		President president = presidents.get(0);
		assertThat(president, is(equalTo(allPresidents.get(0))));
	}

	@Test
	void testCountOfAllPresidents() throws DatabaseException {
		List<President> presidents = service.findAllPresidents();
		int count  = presidents.size();
		assertThat(count, equalTo(JdbcTestUtils.countRowsInTable(jdbcTemplate, "presidents")));
	}
	@Test
	void testFindBiographyById() throws DatabaseException {
		int id = 1;
		String bio = service.getBioById(id);
		
		assertThat(bio, equalTo(allPresidents.get(0).getBiography()));
	}
}
