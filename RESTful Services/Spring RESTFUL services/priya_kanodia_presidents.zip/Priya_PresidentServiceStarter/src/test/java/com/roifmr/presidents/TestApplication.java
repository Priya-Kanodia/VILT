package com.roifmr.presidents;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
class TestApplication {

}
