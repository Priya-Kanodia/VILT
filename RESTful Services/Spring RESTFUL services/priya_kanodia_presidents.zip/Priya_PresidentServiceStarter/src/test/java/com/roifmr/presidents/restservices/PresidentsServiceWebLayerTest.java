package com.roifmr.presidents.restservices;

import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.business.service.PresidentBusinessService;

@WebMvcTest(controllers  = PresidentsService.class)
public class PresidentsServiceWebLayerTest {
	
	@Autowired
	MockMvc mockMvc;
	
	@MockBean
	PresidentBusinessService service;

	static List<President> allPresidents;
	@BeforeAll
	public static void init() {
		 allPresidents = Arrays.asList(
				  new President(1,"George","Washington",1789,1797,"georgewashington.jpg",
						   "On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street in New York, took his oath of office as the first President of the United States. \"As the first of every thing, in our situation will serve to establish a Precedent,\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman."),
				   new President(2,"John","Adams",1797,1801,"johnadams.jpg","Learned and thoughtful, John Adams was more remarkable as a "
				   		+ "political philosopher than as a politician. \"People and nations are forged in the fires of adversity,\" he said, "
				   		+ "doubtless thinking of his own as well as the American experience. Adams was born in the Massachusetts Bay Colony in 1735. "
				   		+ "A Harvard-educated lawyer, he early became identified with the patriot cause; a delegate to the First and Second Continental Congresses, he led in the movement for independence.")
				   );
	}
		
	@Test
	public void testQueryForAllPresidents() throws Exception {
		when(service.findAllPresidents()).thenReturn(allPresidents);
		
		mockMvc.perform(get("/presidents/all"))
			   .andDo(print())
			   .andExpect(status().isOk());
	}
	
	@Test
	public void testQueryForAllPresidetntsDaoReturnsEmptyList() throws Exception {
		when(service.findAllPresidents()).thenReturn(new ArrayList<President>());
		
		mockMvc.perform(get("/presidents/all"))
			   .andDo(print())
			   .andExpect(status().isNoContent())
			   .andExpect(content().string(is(emptyOrNullString())));
	}


	@Test
	public void testQueryForAllPresidentsDaoThrowsException() throws Exception {
		when(service.findAllPresidents()).thenThrow(new RuntimeException());
		
		mockMvc.perform(get("/presidents/all"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}


	@Test
	public void testQueryForPresidentBioById() throws Exception {
		int id = 1;
		
		when(service.getBioById(id)).thenReturn(allPresidents.get(0).getBiography());
		
		mockMvc.perform(get("/presidents/1"))
			   .andDo(print())
			   .andExpect(status().isOk())
			   .andExpect(jsonPath("$.bio").value("On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street in New York, took his oath of office as the first President of the United States. \"As the first of every thing, in our situation will serve to establish a Precedent,\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman."));		
	}
	@Test
	public void testQueryForPresidentBioByIdReturnsNoContent() throws Exception {
		int id = 1;
		
		when(service.getBioById(id)).thenReturn(null);
		
		mockMvc.perform(get("/presidents/1"))
			   .andDo(print())
			   .andExpect(status().isNoContent())
			   .andExpect(content().string(is(emptyOrNullString())));
					   
	}
	@Test
	public void testQueryForPresidentBioByIdReturnsServerError() throws Exception {
		int id = 1;
		
		when(service.getBioById(id)).thenThrow( new RuntimeException());
		
		mockMvc.perform(get("/presidents/1"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
					   
	}

}
