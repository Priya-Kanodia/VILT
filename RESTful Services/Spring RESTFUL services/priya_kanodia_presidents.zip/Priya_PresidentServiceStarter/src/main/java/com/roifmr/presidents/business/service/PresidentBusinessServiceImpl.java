package com.roifmr.presidents.business.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.roifmr.presidents.business.service.DatabaseException;
import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;

@Service
public class PresidentBusinessServiceImpl implements PresidentBusinessService {

	@Autowired
	private PresidentsDao dao;
	
	@Override
	public List<President> findAllPresidents() throws DatabaseException {
		List<President> presidents;
		
		try {
			presidents = dao.queryForAllPresidents();
		} catch (Exception exp) {
			String msg = "Error querying all in the database.";
			throw new DatabaseException(msg, exp);
		}
		
		return presidents;
	}

	@Override
	public String getBioById(int id) throws DatabaseException {
		String bio = null;
		
		try {
			bio = dao.queryForPresidentBiography(id);
		} catch (Exception exp) {
			String msg = String.format("Error querying with id = %d in the database.", id);
			throw new DatabaseException(msg, exp);
		}
		
		return bio;
	}

}
