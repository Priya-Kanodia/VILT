package com.roifmr.presidents.business.service;

public class DatabaseException extends Exception {

	public DatabaseException(String msg, Exception exp) {
		super(msg, exp);
	}

}
