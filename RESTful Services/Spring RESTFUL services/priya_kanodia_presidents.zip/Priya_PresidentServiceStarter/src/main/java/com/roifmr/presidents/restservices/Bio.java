package com.roifmr.presidents.restservices;

public class Bio {

	String bio;

	public Bio() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bio(String bio) {
		super();
		this.bio = bio;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bio == null) ? 0 : bio.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bio other = (Bio) obj;
		if (bio == null) {
			if (other.bio != null)
				return false;
		} else if (!bio.equals(other.bio))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Bio [bio=" + bio + "]";
	}
}
