package com.roifmr.presidents.restservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerErrorException;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.business.service.PresidentBusinessService;

@RestController
@RequestMapping("/presidents")
public class PresidentsService {
	
	private static final String DB_ERROR_MSG = 
			"Error communicating with the database";
	
	@Autowired
	private PresidentBusinessService service;
	
	
	@GetMapping(value="/ping",
			produces=MediaType.ALL_VALUE)
	public String ping() {
		return "web service is alive and awaits your command";
	}	
	

	@GetMapping(value="/all",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<President>> getAllPresidents() {
		ResponseEntity<List<President>> result;
		List<President> presidents;
		try {
			presidents = service.findAllPresidents();
		} 
		catch(Exception e) {
			throw new ServerErrorException(DB_ERROR_MSG, e);
		}
		
		if (presidents.size() > 0) {
			result = ResponseEntity.ok(presidents);
		}
		else {
			result = ResponseEntity.noContent().build();
		}
		return result;
	}
	
	@GetMapping(value="/{id}",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Bio> getBioById(@PathVariable int id) {
		String bio = null;
		if(id <= 0) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
					"Request error as id = " + id + "is negative");
		}
		
		try {
			bio = service.getBioById(id);
		} 
		catch(Exception e) {
			throw new ServerErrorException(DB_ERROR_MSG, e);
		}
		
		if (bio == null) {
			throw new ResponseStatusException(HttpStatus.NO_CONTENT, 
					"No president bio in the database with id = " + id);
		}
		
		Bio bioObj = new Bio(bio);
		return ResponseEntity.ok(bioObj);
	}

}
