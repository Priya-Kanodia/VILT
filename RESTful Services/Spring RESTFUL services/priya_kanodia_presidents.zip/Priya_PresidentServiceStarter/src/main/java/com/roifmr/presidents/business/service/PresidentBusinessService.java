package com.roifmr.presidents.business.service;

import java.util.List;

import com.roifmr.presidents.business.service.DatabaseException;
import com.roifmr.presidents.business.President;

public interface PresidentBusinessService {

	List<President> findAllPresidents() throws DatabaseException;
	String getBioById(int id) throws DatabaseException;
}
