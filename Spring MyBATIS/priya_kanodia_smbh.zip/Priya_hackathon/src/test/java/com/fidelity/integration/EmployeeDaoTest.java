package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import com.fidelity.business.Employee;
import com.fidelity.exceptions.DatabaseException;

//Make sure DAO tests follow best practices from Relational DB course
//as well as the Spring Test Case recommendations from the current course
@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:beans.xml")
@Transactional
class EmployeeDaoTest {

	@Autowired
	private EmployeeDao dao;

	@Test
	void instantiation() {
		assertNotNull(dao);
	}
	
	@Test
	void getAllEmployeesReturnsRows() {
		List<Employee> employees = dao.getAllEmployees();
		assertTrue(employees.size() > 3);
	}
	
	@Test
	void getAllEmployeesHasNonNullFirstNames() {
		List<Employee> employees = dao.getAllEmployees();
		assertNotNull(employees.get(5).getFirstname());
	}
	
	
	@Test
	void insertEmployeeIncrementsRows() throws DatabaseException {
		List<Employee> employees = dao.getAllEmployees();
		long priorCount = employees.size();
		
		Employee employee = employees.get(0);
		employee.setFirstname("NEWFIRSTNAME");
		employee.setEmail("email@name.com");
		employee.setId(2);
		
		
		dao.add(employee);
		long newCount=dao.getAllEmployees().size();
		assertTrue(newCount == priorCount + 1);
	}
	
	@Test
	void insertNullEmployeeThrowsError() throws DatabaseException {
		Employee employee = new Employee();
		
		assertThrows(DatabaseException.class, ()->{dao.add(employee);});
	}
	

}
