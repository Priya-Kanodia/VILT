package com.fidelity.integration;

import java.util.List;

import com.fidelity.business.Job;
import com.fidelity.business.Employee;

public interface EmployeeMapper {
	//add any method specifications for relevant data operations
	
	//do not change  :)
	int insertEmployee(Employee emp);
	
	List<Employee> getAllEmployees();

	List<Employee> getAllEmployeesAndJobs();
	


}
