package com.fidelity.exceptions;

public class DatabaseException extends Exception {
	
	public DatabaseException() {
		super();
	}

	public DatabaseException(Exception exp) {
		super(exp);
	}

	public DatabaseException(Exception exp, String string) {
		super(string,exp);
	}

}
