package com.fidelity.rating;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EsrbRatingTest {

    @Test
    public void testEveryone() {
        EsrbRating rating = EsrbRating.EVERYONE;
        assertEquals("E", rating.getCode());
        assertEquals("Everyone", rating.getDescription());
        assertTrue(rating.isAppropriate(9), "9 allowed");
        assertTrue(rating.isAppropriate(10), "10 allowed");
        assertTrue(rating.isAppropriate(11), "11 allowed");
        assertTrue(rating.isAppropriate(12), "12 allowed");
        assertTrue(rating.isAppropriate(13), "13 allowed");
        assertTrue(rating.isAppropriate(14), "14 allowed");
        assertTrue(rating.isAppropriate(16), "16 allowed");
        assertTrue(rating.isAppropriate(17), "17 allowed");
        assertTrue(rating.isAppropriate(18), "18 allowed");
        assertTrue(rating.isAppropriate(19), "19 allowed");
        assertTrue(rating.isAppropriate(25), "25 allowed");
    }

    @Test
    public void testEveryone10Plus() {
        EsrbRating rating = EsrbRating.EVERYONE_10_PLUS;
        assertEquals("E10+", rating.getCode());
        assertEquals("Everyone 10+", rating.getDescription());
        assertFalse(rating.isAppropriate(9), "9 not allowed");
        assertTrue(rating.isAppropriate(10), "10 allowed");
        assertTrue(rating.isAppropriate(11), "11 allowed");
        assertTrue(rating.isAppropriate(12), "12 allowed");
        assertTrue(rating.isAppropriate(13), "13 allowed");
        assertTrue(rating.isAppropriate(14), "14 allowed");
        assertTrue(rating.isAppropriate(16), "16 allowed");
        assertTrue(rating.isAppropriate(17), "17 allowed");
        assertTrue(rating.isAppropriate(18), "18 allowed");
        assertTrue(rating.isAppropriate(19), "19 allowed");
        assertTrue(rating.isAppropriate(25), "25 allowed");
    }

    @Test
    public void testTeen() {
        EsrbRating rating = EsrbRating.TEEN;
        assertEquals("T", rating.getCode());
        assertEquals("Teen", rating.getDescription());
        assertFalse(rating.isAppropriate(9), "9 not allowed");
        assertFalse(rating.isAppropriate(10), "10 not allowed");
        assertFalse(rating.isAppropriate(11), "11 not allowed");
        assertFalse(rating.isAppropriate(12), "12 not allowed");
        assertTrue(rating.isAppropriate(13), "13 allowed");
        assertTrue(rating.isAppropriate(14), "14 allowed");
        assertTrue(rating.isAppropriate(16), "16 allowed");
        assertTrue(rating.isAppropriate(17), "17 allowed");
        assertTrue(rating.isAppropriate(18), "18 allowed");
        assertTrue(rating.isAppropriate(19), "19 allowed");
        assertTrue(rating.isAppropriate(25), "25 allowed");
    }

    @Test
    public void testMature() {
        EsrbRating rating = EsrbRating.MATURE;
        assertEquals("M", rating.getCode());
        assertEquals("Mature", rating.getDescription());
        assertFalse(rating.isAppropriate(9), "9 not allowed");
        assertFalse(rating.isAppropriate(10), "10 not allowed");
        assertFalse(rating.isAppropriate(11), "11 not allowed");
        assertFalse(rating.isAppropriate(12), "12 not allowed");
        assertFalse(rating.isAppropriate(13), "13 not allowed");
        assertFalse(rating.isAppropriate(14), "14 not allowed");
        assertFalse(rating.isAppropriate(16), "16 not allowed");
        assertTrue(rating.isAppropriate(17), "17 allowed");
        assertTrue(rating.isAppropriate(18), "18 allowed");
        assertTrue(rating.isAppropriate(19), "19 allowed");
        assertTrue(rating.isAppropriate(25), "25 allowed");
    }

    @Test
    public void testAdultsOnly() {
        EsrbRating rating = EsrbRating.ADULTS_ONLY;
        assertEquals("AO", rating.getCode());
        assertEquals("Adults Only", rating.getDescription());
        assertFalse(rating.isAppropriate(9), "9 not allowed");
        assertFalse(rating.isAppropriate(10), "10 not allowed");
        assertFalse(rating.isAppropriate(11), "11 not allowed");
        assertFalse(rating.isAppropriate(12), "12 not allowed");
        assertFalse(rating.isAppropriate(13), "13 not allowed");
        assertFalse(rating.isAppropriate(14), "14 not allowed");
        assertFalse(rating.isAppropriate(16), "16 not allowed");
        assertFalse(rating.isAppropriate(17), "17 not allowed");
        assertTrue(rating.isAppropriate(18), "18 allowed");
        assertTrue(rating.isAppropriate(19), "19 allowed");
        assertTrue(rating.isAppropriate(25), "25 allowed");
    }

    @Test
    public void testRatingPending() {
        EsrbRating rating = EsrbRating.RATING_PENDING;
        assertEquals("RP", rating.getCode());
        assertEquals("Rating Pending", rating.getDescription());
        assertFalse(rating.isAppropriate(9), "9 not allowed");
        assertFalse(rating.isAppropriate(10), "10 not allowed");
        assertFalse(rating.isAppropriate(11), "11 not allowed");
        assertFalse(rating.isAppropriate(12), "12 not allowed");
        assertFalse(rating.isAppropriate(13), "13 not allowed");
        assertFalse(rating.isAppropriate(14), "14 not allowed");
        assertFalse(rating.isAppropriate(16), "16 not allowed");
        assertFalse(rating.isAppropriate(17), "17 not allowed");
        assertFalse(rating.isAppropriate(18), "18 not allowed");
        assertFalse(rating.isAppropriate(19), "19 not allowed");
        assertFalse(rating.isAppropriate(25), "25 not allowed");
    }

}
