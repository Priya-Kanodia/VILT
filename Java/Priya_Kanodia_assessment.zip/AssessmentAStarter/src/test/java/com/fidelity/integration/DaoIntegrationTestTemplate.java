package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.jdbc.core.JdbcTemplate;
import static org.springframework.test.jdbc.JdbcTestUtils.*;

import com.fidelity.model.Client;
import com.fidelity.model.ClientRisk;

/*
 * Integration tests for a DAO.
 * This test suite requires a connection to an Oracle instance that contains
 * the required tables.
 */
class DaoIntegrationTestTemplate {
	private JdbcTemplate jdbcTemplate;
	
	@BeforeEach
	void setUp() {
		DbTestUtils.INSTANCE.initDb();
		jdbcTemplate = DbTestUtils.INSTANCE.initJdbcTemplate();

	}

	@AfterEach
	void tearDown() {
		DbTestUtils.INSTANCE.close();
	}
	
	@AfterAll
	static void resetDb() {
		DbTestUtils.INSTANCE.initDb();
	}

}
