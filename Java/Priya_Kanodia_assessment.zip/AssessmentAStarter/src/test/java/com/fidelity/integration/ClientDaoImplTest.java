package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Savepoint;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.ClientDao;
import com.fidelity.model.Client;
import com.fidelity.model.ClientRisk;

class ClientDaoImplTest {

	ClientDao clientDao;
	Client client;
	Savepoint savepoint;
	
	@BeforeEach
	void setUp() throws Exception {
		clientDao= new ClientDaoImpl();
		client= new Client(1,"Ford Prefect",ClientRisk.valueOf("HIGH"),"+441174960234");
		savepoint = clientDao.beginTransaction("Test");
	}

	@AfterEach
	void tearDown() throws Exception {
		clientDao.rollbackTransaction(savepoint);
		clientDao.close();
		clientDao = null;
	}

	@Test
	public void objectCreated() {
		assertNotNull(clientDao);
	}
	
	@Test
	public void getAllClientReturnsCorrectSize() throws DatabaseException {
		assertTrue(clientDao.getClients().size() > 2);
	}
	
	@Test
	public void getAllClientContainsClient() throws DatabaseException {
		assertTrue(clientDao.getClients().contains(client));
	}
	
	@Test
	void insertingAClientIncreasesRows() throws DatabaseException {
		long priorCount = clientDao.getClients().size();
		Client newClient = new Client(10,"Ford Ferrari",ClientRisk.valueOf("LOW"),"+44189798989");

		clientDao.insertClient(newClient);
		assertEquals(clientDao.getClients().size() ,priorCount + 1);
		
	}
	
	@Test
	void EmptyNameThrowsError() throws DatabaseException {
		Client newClient = new Client(10,"",ClientRisk.valueOf("LOW"),"+44189798989");
		assertThrows(IllegalArgumentException.class, ()-> clientDao.insertClient(newClient));
		
	}
	
	@Test
	void insertingAClientContainsClient() throws DatabaseException {
		Client newClient = new Client(10,"Ford Ferrari",ClientRisk.valueOf("LOW"),"+44189798989");

		clientDao.insertClient(newClient);
		assertTrue(clientDao.getClients().contains(newClient));
		
	}
	
	@Test
	void deletingACarShouldDecreaseRows() throws DatabaseException {
		Client newClient = new Client(10,"Ford Ferrari",ClientRisk.valueOf("LOW"),"+44189798989");
		clientDao.insertClient(newClient);
		
		long priorCount = clientDao.getClients().size();
		clientDao.deleteClient(newClient.getClientId());
		assertTrue(clientDao.getClients().size() == priorCount - 1, " Deleting a client should decrease rows");
	}
	
	@Test
	void deletingAClientShouldRemoveItFromDB() throws DatabaseException {
		Client newClient = new Client(10,"Ford Ferrari",ClientRisk.valueOf("LOW"),"+44189798989");
		clientDao.insertClient(newClient);
		
		long priorCount = clientDao.getClients().size();
		clientDao.deleteClient(newClient.getClientId());
		assertFalse(clientDao.getClients().contains(newClient), " Deleting a client should remove it from DB");
	}

}
