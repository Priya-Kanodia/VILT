/*
 * DbTestUtils.java - utility functions for database integration tests.
 */

package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import com.fidelity.model.Client;
import com.fidelity.model.ClientRisk;

public enum DbTestUtils {
	INSTANCE;
	
	private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/xepdb1";
	private static final String USER = "scott";
	private static final String PASSWORD = "TIGER";
	
	private static final String SQL_SCRIPT = "sql/assessmentA.sql";
	
	private Connection connection;
	
	/**
	 * Re-run the database initialization script.
	 *
	 * Alternatively, for simple schemas, we could drop all rows in the required tables, 
	 * then insert test data:
	 *     Statement stmt = connection.createStatement();
	 *     stmt.executeUpdate("delete from emp");
	 *     stmt.executeUpdate("insert into emp (empno,ename,job,...) values (7369,'SMITH','CLERK',...)");
	 *       ...
	 *     stmt.close();
	 */
	public void initDb() {
		try {
			if (connection == null) {
				connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			}
			// run DB scripts

			ResourceDatabasePopulator resourceDatabasePopulator = new ResourceDatabasePopulator();
			// Only pure SQL scripts allowed - PL/SQL statements must be removed 
			resourceDatabasePopulator.setContinueOnError(true);
			resourceDatabasePopulator.addScript(new FileSystemResource(SQL_SCRIPT));
			resourceDatabasePopulator.populate(connection);
			Thread.sleep(500);
		}
		catch (Exception e) {
			close();
			throw new RuntimeException(e);
		}
		// if no errors, keep connection open
	}

	public synchronized JdbcTemplate initJdbcTemplate() {
		try {
			if (connection == null) {
				connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			}
			return new JdbcTemplate(new SingleConnectionDataSource(connection, true));
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public synchronized void close() {
		if (connection != null) {
			try {
				connection.close();
				connection = null;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Assert a Client instance has the same property values as the columnValueMap.
	 * @param client a Client instance
	 * @param clientProperties a Map returned by JdbcTemplate.queryForMap. The key for 
	 * each item is a column name, and the value is the column's value.
	 */
	public void assertClientEquals(Client client, Map<String, Object> clientProperties) {
		ClientRisk clientRiskFromDb = ClientRisk.of((String) clientProperties.get("client_risk"));
		//TODO
        assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, intValue(clientProperties.get("client_id")));
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, clientProperties.get("client_name"));
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, clientRiskFromDb);
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, clientProperties.get("phone_number"));
	}

	private int intValue(Object bigDecimal) {
		return ((BigDecimal) bigDecimal).intValue();
	}
	
	public void assertClientEquals(List<Client> clients, List<Map<String, Object>> clientProperties) {
		assertEquals(clients.size(), clientProperties.size());
		for (int i = 0; i < clients.size(); i++) {
			assertClientEquals(clients.get(i), clientProperties.get(i));
		}
	}
}
