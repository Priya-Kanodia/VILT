package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Client;

class ClientTest {

	Client client;
	
	@BeforeEach
	void setUp() throws Exception {
		client= new Client();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void NoArgsConstructorWorks() {
		assertNotNull(client);
	}

	@Test
	public void ObjectEqualsWorks() {
		assertEquals(client, new Client());
	}

}
