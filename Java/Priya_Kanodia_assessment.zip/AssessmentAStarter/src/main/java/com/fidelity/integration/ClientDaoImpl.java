package com.fidelity.integration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.ClientDao;
import com.fidelity.model.Client;
import com.fidelity.model.ClientRisk;

public class ClientDaoImpl implements ClientDao {
	
	private final Logger logger = LoggerFactory.getLogger(ClientDaoImpl.class);
	private Connection connection;

	private Connection getConnection() {
			
			if (connection == null) {
				Properties properties = new Properties();
				try {
					properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
					String dbUrl = properties.getProperty("db.url");
					String user = properties.getProperty("db.username");
					String password = properties.getProperty("db.password");
	
					connection = DriverManager.getConnection(dbUrl, user, password);
				} catch (IOException e) {
					logger.error("Cannot read db.properties", e);
	
				} catch (SQLException e) {
					logger.error("Cannot connect", e);
	
				}
			}
			return connection;
		}

	//HELPER FUNCTIONS
	private String getProperCientRiskName(String clientRiskName) {
		if (clientRiskName.equals("Low Risk")) {
			clientRiskName="LOW";
		}else if (clientRiskName.equals("Medium Risk")) {
			clientRiskName="MEDIUM";
		}else if (clientRiskName.equals("High Risk")) {
			clientRiskName="HIGH";
		}else if (clientRiskName.equals("Politically Exposed")) {
			clientRiskName="POLITICAL";
		}
		return clientRiskName;
	}

	private boolean dataVerified(Client client) {
		if (client.getClientId()<0) {
			return false;
		}
		if( client.getClientName().equals("")) {
			return false;
		}
		if( client.getPhone().equals("")) {
			return false;
		}
		return true;
	}
	
	//MAIN FUNCTIONS
	@Override
	public List<Client> getClients() throws DatabaseException {
		String getQuery ="SELECT client.CLIENT_ID , COALESCE(client.CLIENT_NAME, 'N/A') AS CLIENT_NAME, "+
						 "COALESCE(clientRisk.CLIENT_RISK_NAME, 'N/A') AS CLIENT_RISK_NAME, COALESCE(cPhone.PHONE_NUMBER, 'N/A') AS PHONE "+
						 "FROM aa_client client "+
						 "LEFT OUTER JOIN aa_client_phone cPhone "+
						 "ON client.client_id= cPhone.client_id "+
						 "LEFT JOIN aa_client_risk clientRisk "+
						 "ON client.client_risk= clientRisk.client_risk "+
						 "ORDER BY client.client_id";
		
		Connection connection = getConnection();
		List<Client> clients = new ArrayList();
		try (PreparedStatement stmt = connection.prepareStatement(getQuery) ){
			ResultSet resultSet = stmt.executeQuery();
			while(resultSet.next()) {
				int clientId = resultSet.getInt("CLIENT_ID");
				String clientName = resultSet.getString("CLIENT_NAME");
				String clientRiskName = getProperCientRiskName(resultSet.getString("CLIENT_RISK_NAME"));
				ClientRisk clientRisk = ClientRisk.valueOf(clientRiskName);
				String clientPhone = resultSet.getString("PHONE");
				
				clients.add(new Client(clientId,clientName,clientRisk,clientPhone));
				
			}
		}
		catch(SQLException e) {
			logger.error("Cannot get cars", e);
			throw new DatabaseException("Cannot get cars", e);
		}
		return clients;
	}

	@Override
	public void insertClient(Client client) throws DatabaseException {
		//COMMENTED OUT TRANSACTION BECAUSE CAN' TEST WITH SAVEPOINT
		
		String insertCleientQuery= "INSERT INTO aa_client (client_id, client_name, client_risk) VALUES (?, ?, ?)";
		String insertPhoneQuery = "INSERT INTO aa_client_phone (client_id, phone_number) VALUES (?, ?)";
		if (!(dataVerified(client))) {
			throw new IllegalArgumentException();
		}
		Connection connection = getConnection();
//			connection.setAutoCommit(false);
		
		try (PreparedStatement stmt2 = connection.prepareStatement(insertCleientQuery);
			PreparedStatement stmt3 = connection.prepareStatement(insertPhoneQuery);){
			
			stmt2.setInt(1, client.getClientId());
			stmt2.setString(2, client.getClientName());
			stmt2.setString(3, client.getClientRisk().getCode());
			
			stmt3.setInt(1, client.getClientId());
			stmt3.setString(2, client.getPhone());
			
			stmt2.executeUpdate();
			stmt3.executeUpdate();
			
		}
		catch(SQLException e) {
//				connection.rollback();
//				connection.setAutoCommit(true);
			logger.error("Cannot insert", e);
			throw new DatabaseException("Cannot insert car into E_CARS", e);
		}
	}

	@Override
	public void deleteClient(int clientId) throws DatabaseException {
		//COMMENTED OUT TRANSACTION BECAUSE CAN' TEST WITH SAVEPOINT
		String deletePhoneQuery = "DELETE FROM AA_CLIENT_PHONE WHERE CLIENT_ID = ?";
		String deleteClientQuery = "DELETE FROM AA_CLIENT WHERE CLIENT_ID = ?";
		Connection conn = getConnection();
//		conn.setAutoCommit(false);
		try (PreparedStatement stmt1 = conn.prepareStatement(deletePhoneQuery);
			PreparedStatement stmt2 = conn.prepareStatement(deleteClientQuery);){
			stmt1.setInt(1, clientId);
			stmt2.setInt(1, clientId);
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			
		}
		catch(SQLException e) {
//			conn.rollback();
//			conn.setAutoCommit(true);
			logger.error("Cannot delete car engine", e);
			throw new DatabaseException("Cannot delete car engine", e);
		}
}

	@Override
	public void close() throws DatabaseException {
		if(connection != null) {
			try {
				connection.close();
				connection = null;
			}
			catch(SQLException e) {
				logger.error("Cannot close connection", e);
				throw new DatabaseException("Cannot close connection", e);
			}
			
		}
	}

	@Override
	public Savepoint beginTransaction(String name) throws DatabaseException {
		Savepoint sp = null;
		Connection connection = getConnection();
		try {
			connection.setAutoCommit(false);
			// If savepoint fails, may leave AutoCommit in the wrong state
			sp = connection.setSavepoint(name);
		} catch (SQLException e) {
			throw new DatabaseException(e);
		}
		return sp;
	}
	
	@Override
	public void rollbackTransaction(Savepoint sp) throws DatabaseException {
		Connection conn = getConnection();
		try {
			conn.rollback(sp);
			// If rollback fails, may leave AutoCommit in the wrong state
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			throw new DatabaseException(e);
		}
	}
}
