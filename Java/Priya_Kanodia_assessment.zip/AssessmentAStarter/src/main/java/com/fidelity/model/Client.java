package com.fidelity.model;

public class Client {

	private int clientId;
	private String clientName;
	private ClientRisk clientRisk;
	private String phone;
	
	public Client(int clientId, String clientName, ClientRisk clientRisk, String phone) {
		super();
		this.clientId = clientId;
		this.clientName = clientName;
		this.clientRisk = clientRisk;
		this.phone = phone;
	}

	public Client() {
		this(0,"",ClientRisk.valueOf("MEDIUM"),"");
	}

	public int getClientId() {
		return clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public ClientRisk getClientRisk() {
		return clientRisk;
	}

	public String getPhone() {
		return phone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + clientId;
		result = prime * result + ((clientName == null) ? 0 : clientName.hashCode());
		result = prime * result + ((clientRisk == null) ? 0 : clientRisk.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		if (clientId != other.clientId)
			return false;
		if (clientName == null) {
			if (other.clientName != null)
				return false;
		} else if (!clientName.equals(other.clientName))
			return false;
		if (clientRisk != other.clientRisk)
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Client [clientId=" + clientId + ", clientName=" + clientName + ", clientRisk=" + clientRisk + ", phone="
				+ phone + "]";
	}
}
