package com.fidelity.interfaces;

import java.sql.Savepoint;
import java.util.List;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.model.Client;

public interface ClientDao {
	List<Client> getClients() throws DatabaseException;
	void insertClient(Client client) throws DatabaseException;
	void deleteClient(int clientId) throws DatabaseException;

	void close() throws DatabaseException;
	Savepoint beginTransaction(String name) throws DatabaseException;
	void rollbackTransaction(Savepoint sp) throws DatabaseException;
}
