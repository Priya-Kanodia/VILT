package com.fidelity.integration;

import java.sql.Savepoint;
import java.util.List;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.ClientDao;
import com.fidelity.model.Client;

public class ClientDaoMockImpl implements ClientDao {

	@Override
	public List<Client> getClients() throws DatabaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertClient(Client client) throws DatabaseException {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteClient(int clientId) throws DatabaseException {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() throws DatabaseException {
		// TODO Auto-generated method stub

	}

	@Override
	public Savepoint beginTransaction(String name) throws DatabaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void rollbackTransaction(Savepoint sp) throws DatabaseException {
		// TODO Auto-generated method stub

	}

}
