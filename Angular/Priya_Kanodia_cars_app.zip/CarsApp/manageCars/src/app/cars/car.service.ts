import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Car } from '../models/car';

@Injectable({
  providedIn: 'root'
})
export class CarService {

  public url: string= 'http://localhost:8080/CarService/jaxrs/cars';

  getCars() : Observable<Car[]>{
    return this.http.get<Car[]>(this.url);
  }

  getCarsByPrice(): Observable<Car[]>{
    return this.http.get<Car[]>(this.url+'?filter=price');
  }

  constructor(private http: HttpClient) { }
}
