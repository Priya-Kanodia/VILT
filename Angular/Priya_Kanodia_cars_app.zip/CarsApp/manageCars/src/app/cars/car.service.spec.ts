import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule} from '@angular/common/http/testing';

import { CarService } from './car.service';
import { Car } from '../models/car';

const testCars:Car[]=[
  {"doors":2,"make":"Tesla","model":"ABCS","price":120000.0,"year":2017},
  {"doors":2,"make":"Ferrari","model":"F40","price":500000.0,"year":2017}
];

describe('CarService', () => {
  let service: CarService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[
        HttpClientTestingModule
      ]
    });
    service = TestBed.inject(CarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
