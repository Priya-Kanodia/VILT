import { Car } from './car';

describe('Car', () => {
  it('should create an instance', () => {
    expect(new Car(0,'','',0,0)).toBeTruthy();
  });
});
