export class Car {
    constructor(
        public doors: number,
        public make: string,
        public model: string,
        public price: number,
        public year: number
    ){}
}
