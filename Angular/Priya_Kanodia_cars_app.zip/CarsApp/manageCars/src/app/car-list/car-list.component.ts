import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { CarService } from '../cars/car.service';
import { Car } from '../models/car';

@Component({
  selector: 'app-car-list',
  templateUrl: './car-list.component.html',
  styleUrls: ['./car-list.component.scss']
})
export class CarListComponent implements OnInit {
  
  carList: Car[]= [];
  
  constructor(private carService: CarService) { }

  getCars(){
    this.carService.getCars().
      subscribe(data => this.carList= data);
  }

  getCarsByPrice(){
    this.carService.getCarsByPrice().
      subscribe(data=> this.carList= data);
  }

  ngOnInit(): void {
    this.getCars();
  }

}
