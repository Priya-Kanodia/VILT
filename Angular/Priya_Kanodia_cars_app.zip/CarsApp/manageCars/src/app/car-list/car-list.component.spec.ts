import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Car } from '../models/car';
import { of } from 'rxjs';

import { CarListComponent } from './car-list.component';
import { CarService } from '../cars/car.service';

describe('CarListComponent', () => {
  let component: CarListComponent;
  let fixture: ComponentFixture<CarListComponent>;

  beforeEach(async () => {
    const testCars:Car[]=[
      {"doors":2,"make":"Tesla","model":"ABCS","price":120000.0,"year":2017},
      {"doors":2,"make":"Ferrari","model":"F40","price":500000.0,"year":2017}
    ];
    let carService:any= jasmine.createSpyObj('CarService',['getCars']);
    carService.getCars.and.returnValue(of(testCars));


    await TestBed.configureTestingModule({
      declarations: [ CarListComponent ],
      providers: [
        {provide: CarService, useValue: carService}
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a table', ()=> {
    const compiled= fixture.debugElement.nativeElement;
    const table= compiled.querySelector('table');
    expect(table).toBeTruthy();
    expect(table.rows.length).toBeGreaterThanOrEqual(1);
    expect(table.rows[1].cells[1].textContent).toBe(' Ferrari ');
  });

  it('should get cars from service', ()=>{
    expect(component.carList).toBeTruthy();
    expect(component.carList.length).toBeGreaterThanOrEqual(2);
    expect(component.carList[0].model).toBe('ABCS');
  });

});
