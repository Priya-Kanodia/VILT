
let MathUtils = require('../MathUtils');

// This is our test suite
describe('MathUtils', function () {
    let calc;

    // This will be called before running each spec
    beforeEach(function () {
        calc = new MathUtils();
    });

    // This will be called after running each spec
    // Setting calc to null is not really necessary, but shown as an example
    afterEach(function () {
        calc = null;
    });

    // describes may be nested to group related tests together
    describe('when calc is used to perform basic math operations', function () {

        describe('when calc is used to calculate sums', function () {
            // Spec for sum operation
            it('should be able to calculate sum of 3 and 5', function () {
                expect(calc.sum(3, 5)).toEqual(8);
            });

            it('should be able to calculate sum of -1 and 1', function() {
                expect(calc.sum(-1, 1)).toEqual(0);
            });
        });

        describe('when calc is used to calculate differences', function () {
            it('should be able to calculate difference of 3 and 5', function () {
                expect(calc.subtract(3, 5)).toEqual(-2);
            });

            it('should be able to calculate difference of -1 and 1', function() {
                expect(calc.subtract(-1, 1)).toEqual(-2);
            });
        });

        describe('when calc is used to calculate products', function () {
            it('should be able to multiply 3 and 5', function () {
                expect(calc.multiply(3, 5)).toEqual(15);
            });

            it('should be able to multiply of -1 and 1', function() {
                expect(calc.multiply(-1, 1)).toEqual(-1);
            });
        });

        describe('when calc is used to calculate quotients', function () {
            it('should be able to divide 3 by 5', function () {
                expect(calc.divide(3, 5)).toEqual(0.6);
            });

            it('should be able to divide -1 by 1', function() {
                expect(calc.divide(-1, 1)).toEqual(-1);
            });

            it('should be able to divide 3 by 0 and calculate infinity', function() {
                expect(calc.divide(3, 0)).toEqual(Infinity);
            });
        });
    });

    // describes may be nested to group related tests together
    describe('when calc is used to calculate factorials', function () {
        // Done: write a test for function factorial using the number 9
        it('should be able to calculate factorial of 9', function () {
            expect(calc.factorial(9)).toEqual(362880);
        });

        // Done: write a test for function factorial using the number -7
        // You expect this spec to throw an error
        // HINT: you will need toThrowError instead of toEqual
        it('should throw error in factorial operation when the number is negative', function () {
            expect(function () {
                calc.factorial(-7)
            }).toThrowError(Error);
        });

    });

});