import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ReviewsRoutingModule } from './reviews-routing.module';
import { ReviewPageComponent } from './review-page/review-page.component';
import { ReviewFormComponent } from './review-form/review-form.component';

@NgModule({
    declarations: [
        ReviewPageComponent,
        ReviewFormComponent
    ],
    imports: [
        CommonModule,
        ReviewsRoutingModule,
        FormsModule
    ]
})
export class ReviewsModule { }
