export class Review {
    constructor(
        public content: string,
        public bookId: number
    ) { }
}
