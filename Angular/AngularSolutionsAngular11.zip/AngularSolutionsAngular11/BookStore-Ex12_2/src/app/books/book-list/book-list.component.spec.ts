import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Pipe, PipeTransform } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { BookListComponent } from './book-list.component';

@Pipe({
    name: 'noImage'
})
class MockNoImagePipe implements PipeTransform {
    transform(value: string): string {
        return value;
    }
}

describe('BookListComponent', () => {
    let component: BookListComponent;
    let fixture: ComponentFixture<BookListComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                BookListComponent,
                MockNoImagePipe
            ],
            imports: [
                RouterTestingModule
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(BookListComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should contain a table', () => {
        component.books = [{
            title: 'The Lord of the Rings',
            author: 'J R R Tolkien',
            cover: '',
            bookId: 1
        }, {
            title: 'The Left Hand of Darkness',
            author: 'Ursula K Le Guin',
            cover: '',
            bookId: 2
        }];
        fixture.detectChanges();
        const compiled = fixture.debugElement.nativeElement;
        const table = compiled.querySelector('table');
        // console.log(table);
        expect(table.rows.length).toBe(3);
        expect(table.rows[0].cells[0].textContent).toBe('Title');
        expect(table.rows[1].cells[0].textContent).toBe('The Lord of the Rings');
        expect(table.rows[2].cells[0].textContent).toBe('The Left Hand of Darkness');
    });

    it('should contain a div if there are no books', () => {
        component.books = [];
        fixture.detectChanges();
        const compiled = fixture.debugElement.nativeElement;
        const table = compiled.querySelector('table');
        const div = compiled.querySelector('#nobooks');
        expect(div).toBeTruthy();
        expect(table.rows.length).toBe(1);
    });
});
