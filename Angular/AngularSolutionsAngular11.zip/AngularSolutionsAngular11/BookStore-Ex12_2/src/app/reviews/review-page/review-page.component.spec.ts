import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';

import { ReviewPageComponent } from './review-page.component';

describe('ReviewPageComponent', () => {
    let component: ReviewPageComponent;
    let fixture: ComponentFixture<ReviewPageComponent>;
    const mockActivatedRoute = {
        snapshot: {
            params: {
                id: 42
            }
        }
    }

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                ReviewPageComponent
            ],
            imports: [
                RouterTestingModule
            ],
            providers: [
                { provide: ActivatedRoute, useValue: mockActivatedRoute }
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ReviewPageComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should receive route parameters', () => {
        expect(component.bookId).toBe(42);
    });
});
