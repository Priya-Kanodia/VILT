package com.fidelity.integration;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.PhoneContractDao;
import com.fidelity.model.PhoneContract;

public class PhoneContractMockImpl implements PhoneContractDao {

	private PhoneContract phoneContract1;
	private PhoneContract phoneContract2;
	
	public PhoneContractMockImpl() {
		phoneContract1 = new PhoneContract(1,"Cheap USA","weekend",2, new BigDecimal("0.84"));
		phoneContract2 = new PhoneContract(2,"India","weekend",2, new BigDecimal("1.84"));
	}
	
	@Override
	public List<PhoneContract> getFullPhoneContracts() {
		List<PhoneContract> details= new ArrayList<PhoneContract>();
		details.add(phoneContract1);
		details.add(phoneContract2);
		return details;
	}

	@Override
	public List<PhoneContract> getPhoneContractByID(int pcId) {
		List<PhoneContract> details= new ArrayList<PhoneContract>();
		if (pcId==1) {
			details.add(phoneContract1);
		}
		if (pcId==2) {
			details.add(phoneContract2);
		}
		return details;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public Savepoint beginSavepoint(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void rollbackSavepoint(Savepoint savePoint) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertQuery(PhoneContract phoneContract) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertQueryWithTransaction(PhoneContract phoneContact) throws DatabaseException, SQLException {
		// TODO Auto-generated method stub
		
	}

}
