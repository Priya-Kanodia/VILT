package com.fidelity.interfaces;

import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.List;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.model.PhoneContract;

public interface PhoneContractDao {
	List<PhoneContract> getFullPhoneContracts();
	List<PhoneContract> getPhoneContractByID(int pcId);

	void close();
	Savepoint beginSavepoint(String string);
	void rollbackSavepoint(Savepoint savePoint);
	void insertQuery(PhoneContract phoneContract) throws DatabaseException, IllegalArgumentException;
	void insertQueryWithTransaction(PhoneContract phoneContact) throws DatabaseException, SQLException;
}
