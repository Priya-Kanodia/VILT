package com.fidelity.integration;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.PhoneContractDao;
import com.fidelity.model.PhoneContract;

public class PhoneContractDaoImpl implements PhoneContractDao {
	private final Logger logger = LoggerFactory.getLogger(PhoneContractDaoImpl.class);

	private Connection connection;

	@Override
	public void close() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				connection = null;
			}
		}
	}

	private Connection getConnection() {
		if (connection == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				connection = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				logger.error("Cannot read db.properties", e);
				throw new DatabaseException("Cannot read db.properties", e);
			} catch (SQLException e) {
				logger.error("Cannot connect", e);
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return connection;
	}

	@Override
	public Savepoint beginSavepoint(String string) {
		Savepoint savePoint= null;
		Connection connection= getConnection();
		try {
			connection.setAutoCommit(false);
			savePoint= connection.setSavepoint(string);
		}
		catch(SQLException error) {
			logger.error("Can't savePoint",error);
			throw new DatabaseException("Can't savePoint",error);
		}
		return savePoint;
	}

	@Override
	public void rollbackSavepoint(Savepoint savePoint) {
		Connection connection= getConnection();
		try {
			connection.rollback(savePoint);
			connection.setAutoCommit(true);
		}
		catch(SQLException error) {
			logger.error("Can't Rollback",error);
			throw new DatabaseException("Can't Rollback",error);
		}
		
	}
	
	@Override
	public List<PhoneContract> getFullPhoneContracts() {
		
		String sql = "SELECT pc.pcid, pc.pcname, " +
				"coalesce(r.ratesname,'N/A') r_name," +
				"coalesce(h.hours_quantity,0) h_quantity," + 
				"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
				"FROM b_phonecontracts pc " + 
				"LEFT OUTER JOIN b_hours h " + 
				"ON h.pcid = pc.pcid " + 
				"LEFT OUTER JOIN b_rates r " + 
				"ON h.ratesid = r.ratesid " + 
				"ORDER BY pc.pcname ";
		List<PhoneContract> details = new ArrayList<>();

		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet resultSet = stmt.executeQuery(sql);
			details = handleResults(resultSet);		
		} catch (SQLException e) {
			logger.error("Cannot execute getFullPhoneContracts", e);
			throw new DatabaseException("Cannot execute getFullPhoneContracts", e);
		}
		return details;
	}

	private List<PhoneContract> handleResults(ResultSet resultSet) throws SQLException {
		List<PhoneContract> details = new ArrayList<>();
		while (resultSet.next()) {
			int pcId = resultSet.getInt("pcid");
			String pcName = resultSet.getString("pcname");
			String rateName = resultSet.getString("r_name");
			int quantity = resultSet.getInt("h_quantity");
			BigDecimal totalValue = resultSet.getBigDecimal("value");
			PhoneContract detail = new PhoneContract(pcId, pcName, rateName,
							quantity, totalValue);
			details.add(detail);
		}
		return details;
	}

	@Override
	public List<PhoneContract> getPhoneContractByID(int pcId) {
		String sql = "SELECT pc.pcid, pc.pcname, " +
				"coalesce(r.ratesname,'N/A') r_name," +
				"coalesce(h.hours_quantity,0) h_quantity," + 
				"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
				"FROM b_phonecontracts pc " + 
				"LEFT OUTER JOIN b_hours h " + 
				"ON h.pcid = pc.pcid " + 
				"LEFT OUTER JOIN b_rates r " + 
				"ON h.ratesid = r.ratesid " +
				"WHERE pc.pcid = ? " +
				"ORDER BY pc.pcname ";
		List<PhoneContract> details = new ArrayList<>();

		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, pcId);
			ResultSet rs = stmt.executeQuery();
			details = handleResults(rs);		
		} catch (SQLException e) {
			logger.error("Cannot execute getPhoneContractByID", e);
			throw new DatabaseException("Cannot execute getPhoneContractByID", e);
		}
		return details;
	}
	
	@Override
	public void insertQueryWithTransaction(PhoneContract phoneContract) throws DatabaseException, SQLException {
		String sql1= "INSERT INTO B_PHONECONTRACTS (PCID, PCNAME) VALUES (?, ?) ";
		String sql2= "INSERT INTO B_RATES (RATESID, RATESNAME, RATESPRICE) VALUES (?, ?, ?) ";
		String sql3= "INSERT INTO B_HOURS (HOURSID, PCID, RATESID, HOURS_QUANTITY) VALUES (?, ?, ?, ?) ";
		Connection connection= getConnection();
		if (!(dataVerified(phoneContract))) {
			throw new IllegalArgumentException();
		}
		Double price= phoneContract.getTotalValue().doubleValue()/phoneContract.getQuantity();
		Double ratesPrice= BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP).doubleValue();
		
		try(PreparedStatement stmt1= connection.prepareStatement(sql1);
				PreparedStatement stmt2= connection.prepareStatement(sql2);
				PreparedStatement stmt3= connection.prepareStatement(sql3)){
			connection.setAutoCommit(false);
			
			stmt1.setInt(1, phoneContract.getPhoneContractId());
			stmt1.setString(2, phoneContract.getPhoneContractName());
			stmt2.setInt(1, 50);
			stmt2.setString(2, phoneContract.getRateName());
			stmt2.setDouble(3,ratesPrice);
			stmt3.setInt(1, 150);
			stmt3.setInt(2, phoneContract.getPhoneContractId());
			stmt3.setInt(3, 50);
			stmt3.setInt(4, phoneContract.getQuantity());
			
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			stmt3.executeUpdate();
			connection.commit();
		}
		catch(SQLException error) {
			connection.rollback();
			logger.error("Cannot Insert",error);
			throw new DatabaseException("Cannot Insert", error);
		}
		finally {
			connection.setAutoCommit(true);
		}
	}

	@Override
	public void insertQuery(PhoneContract phoneContract)throws DatabaseException, IllegalArgumentException {
		String sql1= "INSERT INTO B_PHONECONTRACTS (PCID, PCNAME) VALUES (?, ?) ";
		String sql2= "INSERT INTO B_RATES (RATESID, RATESNAME, RATESPRICE) VALUES (?, ?, ?) ";
		String sql3= "INSERT INTO B_HOURS (HOURSID, PCID, RATESID, HOURS_QUANTITY) VALUES (?, ?, ?, ?) ";
		Connection connection= getConnection();
		if (!(dataVerified(phoneContract))) {
			throw new IllegalArgumentException();
		}
		Double price= phoneContract.getTotalValue().doubleValue()/phoneContract.getQuantity();
		Double ratesPrice= BigDecimal.valueOf(price).setScale(2, RoundingMode.HALF_UP).doubleValue();
		
		try(PreparedStatement stmt1= connection.prepareStatement(sql1);
			PreparedStatement stmt2= connection.prepareStatement(sql2);
			PreparedStatement stmt3= connection.prepareStatement(sql3)){
			
			stmt1.setInt(1, phoneContract.getPhoneContractId());
			stmt1.setString(2, phoneContract.getPhoneContractName());
			stmt2.setInt(1, 50);
			stmt2.setString(2, phoneContract.getRateName());
			stmt2.setDouble(3,ratesPrice);
			stmt3.setInt(1, 150);
			stmt3.setInt(2, phoneContract.getPhoneContractId());
			stmt3.setInt(3, 50);
			stmt3.setInt(4, phoneContract.getQuantity());
			
			stmt1.executeUpdate();
			stmt2.executeUpdate();
			stmt3.executeUpdate();
		}
		catch(SQLException error) {
			logger.error("Cannot Insert",error);
			throw new DatabaseException("Cannot Insert", error);
		}
	}

	private boolean dataVerified(PhoneContract phoneContract) {
		if (phoneContract.getPhoneContractId()<0) {
			return false;
		}
		if (phoneContract.getPhoneContractName()==null || phoneContract.getPhoneContractName().isEmpty()) {
			return false;
		}
		if (phoneContract.getRateName()==null || phoneContract.getRateName().isEmpty()) {
			return false;
		}
		if (phoneContract.getQuantity()<0) {
			return false;
		}
		if (phoneContract.getTotalValue().compareTo(BigDecimal.ZERO)<0) {
			return false;
		}
		return true;
	}

}
