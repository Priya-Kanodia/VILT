package com.fidelity.interfaces;

public interface IPhoneContract {

}
