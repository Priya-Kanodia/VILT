package com.fidelity.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.fidelity.interfaces.IPhoneContract;

public class PhoneContract implements IPhoneContract {

	private int phoneContractId;
	private String phoneContractName;
	private String rateName;
	private int quantity;
	private BigDecimal totalValue;
	
	// Eclipse-generated from here

	public PhoneContract(int pcId, String pcName, String rateName, int quantity,
			BigDecimal totalValue) {
		super();
		this.phoneContractId = pcId;
		this.phoneContractName = pcName;
		this.rateName = rateName;
		this.quantity = quantity;
		this.totalValue = totalValue.setScale(2,  RoundingMode.HALF_UP);
	}

	public PhoneContract() {
		this(0,"","",0,BigDecimal.ZERO);
	}

	public int getPhoneContractId() {
		return phoneContractId;
	}

	public void setPhoneContractId(int phoneContractId) {
		this.phoneContractId = phoneContractId;
	}

	public String getPhoneContractName() {
		return phoneContractName;
	}

	public void setPhoneContractName(String phoneContractName) {
		this.phoneContractName = phoneContractName;
	}

	public String getRateName() {
		return rateName;
	}

	public void setRateName(String rateName) {
		this.rateName = rateName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getTotalValue() {
		return totalValue;
	}

	public void setTotalValue(BigDecimal totalValue) {
		this.totalValue = totalValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + phoneContractId;
		result = prime * result + ((phoneContractName == null) ? 0 : phoneContractName.hashCode());
		result = prime * result + quantity;
		result = prime * result + ((rateName == null) ? 0 : rateName.hashCode());
		result = prime * result + ((totalValue == null) ? 0 : totalValue.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PhoneContract other = (PhoneContract) obj;
		if (phoneContractId != other.phoneContractId)
			return false;
		if (phoneContractName == null) {
			if (other.phoneContractName != null)
				return false;
		} else if (!phoneContractName.equals(other.phoneContractName))
			return false;
		if (quantity != other.quantity)
			return false;
		if (rateName == null) {
			if (other.rateName != null)
				return false;
		} else if (!rateName.equals(other.rateName))
			return false;
		if (totalValue == null) {
			if (other.totalValue != null)
				return false;
		} else if (!totalValue.equals(other.totalValue))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "PhoneContract [phoneContractId=" + phoneContractId + ", phoneContractName=" + phoneContractName
				+ ", rateName=" + rateName + ", quantity=" + quantity + ", totalValue=" + totalValue + "]";
	}
	

}
