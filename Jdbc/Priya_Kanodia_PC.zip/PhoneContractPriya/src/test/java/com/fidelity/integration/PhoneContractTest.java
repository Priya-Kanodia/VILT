package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.interfaces.IPhoneContract;
import com.fidelity.model.PhoneContract;

class PhoneContractTest {

	IPhoneContract phoneContract;
	
	@BeforeEach
	void setUp() throws Exception {
		phoneContract= new PhoneContract();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void NoArgsConstructorWorks() {
		assertNotNull(phoneContract);
	}

	@Test
	public void ObjectEqualsWorks() {
		assertEquals(phoneContract, new PhoneContract());
	}
}
