package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.interfaces.PhoneContractDao;
import com.fidelity.model.PhoneContract;

class PhoneContractMockImplTest {
	PhoneContractDao phoneContractDao;
	PhoneContract phoneContract1;

	@BeforeEach
	void setUp() throws Exception {
		phoneContractDao = new PhoneContractMockImpl();
		phoneContract1 = new PhoneContract(1,"Cheap USA","weekend",2, new BigDecimal("0.84"));
	}

	@AfterEach
	void tearDown() throws Exception {
		phoneContractDao.close();
	}

	@Test
	void testLoadAllPhoneContractsSize() {
		List<PhoneContract> details = phoneContractDao.getFullPhoneContracts();
		assertTrue(details.size()>1);	
	}
	
	@Test
	void testListContainsPhoneContracts() {
		List<PhoneContract> details = phoneContractDao.getFullPhoneContracts();
		assertTrue(details.contains(phoneContract1));	
	}

	@Test
	void testSinglePhoneContract() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(1);
		assertTrue(details.contains(phoneContract1));	
	}
	
	@Test
	void testSinglePhoneContractReturnsCorrectSize() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(1);
		assertEquals(details.size(),1);	
	}

	@Test
	void negativeIdReturnsEmptyList() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(-4);
		assertEquals(details.size(),0);	
	}

}
