package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.exceptions.DatabaseException;
import com.fidelity.interfaces.PhoneContractDao;
import com.fidelity.model.PhoneContract;

class PhoneContractDaoImplTest {
	PhoneContractDao phoneContractDao;
	PhoneContract phoneContract1;
	PhoneContract phoneContract2;
	Savepoint savePoint;

	@BeforeEach
	void setUp() throws Exception {
		phoneContractDao = new PhoneContractDaoImpl();
		phoneContract1 = new PhoneContract(1,"Cheap USA","weekend",2, new BigDecimal("0.84"));
		savePoint= phoneContractDao.beginSavepoint("Test");
	}

	@AfterEach
	void tearDown() throws Exception {
		phoneContractDao.rollbackSavepoint(savePoint);
		phoneContractDao.close();
	}

	@Test
	void testLoadAllPhoneContractsSize() {
		List<PhoneContract> details = phoneContractDao.getFullPhoneContracts();
		assertTrue(details.size()>3);	
	}
	
	@Test
	void testListContainsPhoneContracts() {
		List<PhoneContract> details = phoneContractDao.getFullPhoneContracts();
		assertTrue(details.contains(phoneContract1));	
	}

	@Test
	void testSinglePhoneContract() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(1);
		assertTrue(details.contains(phoneContract1));	
	}
	
	@Test
	void testSinglePhoneContractReturnsCorrectSize() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(3);
		assertEquals(details.size(),2);	
	}

	@Test
	void negativeIdReturnsEmptyList() {
		List<PhoneContract> details = phoneContractDao.getPhoneContractByID(-4);
		assertEquals(details.size(),0);	
	}
	
	@Test
	void InsertQueryWorks() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(10,"India","day",90, new BigDecimal("5.84"));
		phoneContractDao.insertQuery(phoneContract2);
		assertTrue(phoneContractDao.getPhoneContractByID(10).get(0).getPhoneContractName().equals("India"));
	}

	@Test
	void negativePhoneIdInsertThrowsError() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(-10,"India","day",90, new BigDecimal("5.84"));
		assertThrows(IllegalArgumentException.class, ()-> phoneContractDao.insertQuery(phoneContract2));
	}
	
	@Test
	void NullPhoneNameInsertThrowsError() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(10,null,"day",90, new BigDecimal("5.84"));
		assertThrows(IllegalArgumentException.class, ()-> phoneContractDao.insertQuery(phoneContract2));
	}
	
	@Test
	void EmptyPhoneNameInsertThrowsError() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(10,"","day",90, new BigDecimal("5.84"));
		assertThrows(IllegalArgumentException.class, ()-> phoneContractDao.insertQuery(phoneContract2));
	}
	
	@Test
	void negativeTotalValuensertThrowsError() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(10,"India","day",90, new BigDecimal(-5.84));
		assertThrows(IllegalArgumentException.class, ()-> phoneContractDao.insertQuery(phoneContract2));
	}
	
	@Test
	void negativeRateIdInsertThrowsError() throws DatabaseException, SQLException {
		phoneContract2 = new PhoneContract(10,"India","day",-90, new BigDecimal("5.84"));
		assertThrows(IllegalArgumentException.class, ()-> phoneContractDao.insertQuery(phoneContract2));
	}

}
