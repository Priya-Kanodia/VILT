package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Connection;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Department;

class DepartmentSimpleDaoTest {

	private DepartmentSimpleDao dao;
	
	@BeforeEach
	void setUp() {
		dao = new DepartmentSimpleDao();
	}

	@Test
	void testConnect() {
		Connection conn = dao.getConnection();
		assertNotNull(conn);
	}

	@Test
	void testQueryAll() {
		Department expected = new Department(20, "RESEARCH", "DALLAS");
		List<Department> depts = dao.queryAllDepartments();
		assertNotNull(depts, "Should return valid list of depts");
		assertTrue(depts.contains(expected), "Should contain RESEARCH");
		assertEquals(4, depts.size(), "Should be 4 records");
	}
	
	@Test
	void testInsert() {
		Department expected = new Department(90, "NEW RESEARCH", "CARY");
		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(expected), "Should not contain new dept before insert");
		assertEquals(4, depts.size(), "Should be 4 records before insert");
		dao.addNewDepartmentUnsafe(expected);
		depts = dao.queryAllDepartments();
		assertTrue(depts.contains(expected), "Should contain new dept after insert");
		assertEquals(5, depts.size(), "Should be 5 records after insert");
		
		// Reset data
		dao.deleteDepartmentUnsafe(90);
		depts = dao.queryAllDepartments();
		assertFalse(depts.contains(expected), "Should not contain new dept after reset");
		assertEquals(4, depts.size(), "Should be 4 records after reset");
	}

	@Test
	void testQueryByNameUnsafe() {
		Department expected = new Department(20, "RESEARCH", "DALLAS");
		List<Department> depts = dao.queryDepartmentsByNameUnsafe("RESEARCH");
		assertNotNull(depts, "Should return valid list of depts");
		assertTrue(depts.contains(expected), "Should contain RESEARCH");
		assertEquals(1, depts.size(), "Should be 1 record");
	}
	
	@Test
	void testQueryByNameInjection() {
		List<Department> depts = dao.queryDepartmentsByNameUnsafe("RESEARCH' OR '1'='1");
		assertEquals(4, depts.size(), "Should be 4 records");
	}
	
	@Test
	void testQueryByNameSafe() {
		Department expected = new Department(20, "RESEARCH", "DALLAS");
		List<Department> depts = dao.queryDepartmentsByNameSafe("RESEARCH");
		assertNotNull(depts, "Should return valid list of depts");
		assertTrue(depts.contains(expected), "Should contain RESEARCH");
		assertEquals(1, depts.size(), "Should be 1 record");
	}
	
	@Test
	void testQueryByNameInjectionFail() {
		List<Department> depts = dao.queryDepartmentsByNameSafe("RESEARCH' OR '1'='1");
		assertEquals(0, depts.size(), "Should be 0 records");
	}

}
