package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Department;

class DepartmentDaoFakeImplTest {

	private DepartmentDao dao;
	private Savepoint sp;

	private Department dept10;
	private Department dept20;
	private Department dept30;
	private Department dept40;

	@BeforeEach
	void setUp() {
		dept10 = new Department(10, "ACCOUNTING", "NEW YORK");
		dept20 = new Department(20, "RESEARCH", "DALLAS");
		dept30 = new Department(30, "SALES", "CHICAGO");
		dept40 = new Department(40, "OPERATIONS", "BOSTON");

		dao = new DepartmentDaoFakeImpl();
		sp = dao.beginSavepointTransaction("test");
//		dao.beginTransaction();
	}
	
	@AfterEach
	void tearDown() {
		dao.rollbackSavepointTransaction(sp);
		dao.rollbackTransaction();
//		dao.close();
	}
	
	@Test
	void testQueryAllDepartments() {
		List<Department> depts = dao.queryAllDepartments();
		assertEquals(4, depts.size(), "Should be 4 departments");
		assertTrue(depts.contains(dept20), "Should contain RESEARCH");
		assertTrue(depts.contains(dept40), "Should contain OPERATIONS");
	}

	@Test
	void testInsertDepartment() {
		Department dept90 = new Department(90, "NEW RESEARCH", "CARY");
		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(dept90), "Should not contain new dept before insert");
		dao.addNewDepartment(dept90);
		depts = dao.queryAllDepartments();
		assertTrue(depts.contains(dept90), "Should contain new dept after insert");
		assertEquals(5, depts.size(), "Should be 5 records after insert");
	}

	@Test
	void testUpdateDepartment() {
		Department expected1 = new Department(10, "NEW ACCOUNTING", "CARY");

		// Have other tests that confirm pre-update state
		
		dao.updateDepartment(expected1);
		List<Department> depts = dao.queryAllDepartments();
		assertTrue(depts.contains(expected1), "Should contain new dept 10 after update");
		assertTrue(depts.contains(dept30), "Should contain existing dept 30 after update");
		assertEquals(4, depts.size(), "Should be 4 records after update");
	}

	@Test
	void testDeleteDepartment() {
		int size = dao.queryAllDepartments().size();

		// already have tests that check dept 40 exists before delete

		dao.deleteDepartment(40);
		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(dept40), "Dept 40 should not exist after delete");
		assertEquals(size - 1, depts.size(), "Should only have deleted 1 dept");
	}

	@Test
	void testUpdateInBatch() {
		List<Department> updates = new ArrayList<>();
		Department expected1 = new Department(10, "NEW ACCOUNTING", "CARY");
		Department expected2 = new Department(20, "NEW RESEARCH", "CARY");
		updates.add(expected1);
		updates.add(expected2);

		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(expected1), "Should not contain new dept 10 before update");
		assertFalse(depts.contains(expected2), "Should not contain new dept 20 before update");
		assertTrue(depts.contains(dept30), "Should contain existing dept 30 before update");
		assertEquals(4, depts.size(), "Should be 4 records before update");

		dao.updateInBatch(updates);
		depts = dao.queryAllDepartments();
		assertTrue(depts.contains(expected1), "Should contain new dept 10 after update");
		assertTrue(depts.contains(expected2), "Should contain new dept 20 after update");
		assertTrue(depts.contains(dept30), "Should contain existing dept 30 after update");
		assertEquals(4, depts.size(), "Should be 4 records after update");
	}

	@Test
	void testUpdateByProc() {
		Department expected1 = new Department(10, "NEW ACCOUNTING", "NEW YORK");

		List<Department> depts = dao.queryAllDepartments();

		assertTrue(depts.contains(dept10), "Should contain existing 10 before update");
		assertTrue(depts.contains(dept30), "Should contain existing dept 30 before update");
		assertEquals(4, depts.size(), "Should be 4 records before update");

		dao.updateByProcedure(10);
		depts = dao.queryAllDepartments();
		assertTrue(depts.contains(expected1), "Should contain new dept 10 after update");
		assertTrue(depts.contains(dept30), "Should contain existing dept 30 after update");
		assertEquals(4, depts.size(), "Should be 4 records after update");
	}

}
