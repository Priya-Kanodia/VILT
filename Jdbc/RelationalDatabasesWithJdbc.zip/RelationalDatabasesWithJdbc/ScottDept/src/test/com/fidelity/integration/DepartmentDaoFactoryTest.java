package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DepartmentDaoFactoryTest {
	private DepartmentDao dao;
	
	@Test
	void testMysql() {
		dao = DepartmentDaoFactory.getDepartmentDao("mysql");
		assertTrue(dao instanceof DepartmentDaoMysqlImpl);
	}

	@Test
	void testOracle() {
		dao = DepartmentDaoFactory.getDepartmentDao("oracle");
		assertTrue(dao instanceof DepartmentDaoOracleImpl);
	}

	@Test
	void testHsqldb() {
		dao = DepartmentDaoFactory.getDepartmentDao("hsqldb");
		assertTrue(dao instanceof DepartmentDaoHsqldbImpl);
	}

	@Test
	void testFail() {
		assertThrows(IllegalArgumentException.class, () -> {
			dao = DepartmentDaoFactory.getDepartmentDao("invalid");
		});
	}


}
