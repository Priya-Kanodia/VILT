package com.fidelity.integration;

import java.sql.Savepoint;
import java.util.List;

import com.fidelity.model.Department;

public interface DepartmentDao {

	void close();

	void rollbackSavepointTransaction(Savepoint savepoint);

	Savepoint beginSavepointTransaction(String name);

	void rollbackTransaction();

	void beginTransaction();

	List<Department> queryAllDepartments();

	void addNewDepartment(Department dept);

	void deleteDepartment(int deptNumber);

	void updateInBatch(List<Department> depts);

	String updateByProcedure(int deptNumber);

	void updateDepartment(Department dept);

	List<Department> queryDepartmentsByName(String name);
	
	List<Department> queryDepartmentsByNameSimpler(String name);
}