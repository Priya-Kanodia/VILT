package com.fidelity.integration;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Department;

public class DepartmentDaoOracleImpl implements DepartmentDao {
	private final Logger logger = LoggerFactory.getLogger(DepartmentDaoOracleImpl.class);

	@Override
	public List<Department> queryAllDepartments() {
		String sql = "SELECT deptno, dname, loc FROM dept";
		List<Department> depts = new ArrayList<>();

		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno");
				String deptName = rs.getString("dname");
				String loc = rs.getString("loc");
				
				depts.add(new Department(deptNumber, deptName, loc));
			}
		} catch (SQLException e) {
			logger.error("Cannot execute SQL query for depts", e);
			throw new DatabaseException("Cannot execute SQL query for dept: " + sql, e);	
		}
		return depts;
	}

	// This method does not use try with resources and illustrates how fiddly finally processing can be.
	@Override
	public List<Department> queryDepartmentsByName(String name) {
		String sql = "SELECT deptno, dname, loc FROM dept WHERE dname = ?";
		List<Department> depts = new ArrayList<>();
		PreparedStatement stmt = null;
		Connection conn = getConnection();
		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, name);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno");    // or rs.getInt(1)
				String deptName = rs.getString("dname"); // or rs.getString(2)
				String loc = rs.getString("loc");
				Department dept = new Department(deptNumber, deptName, loc);
				depts.add(dept);
			}
		} catch (SQLException e) {
			logger.error("Cannot execute SQL query for dept: {}", name, e);
			throw new DatabaseException("Cannot execute SQL query for dept: " + name, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					logger.error("Cannot execute close statement", e);
				}
			}
		}
		return depts;
	}
	
	@Override
	public List<Department> queryDepartmentsByNameSimpler(String name) {
		String sql = "SELECT deptno, dname, loc FROM dept WHERE dname = ?";
		List<Department> depts = new ArrayList<>();
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, name);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno");    // or rs.getInt(1)
				String deptName = rs.getString("dname"); // or rs.getString(2)
				String loc = rs.getString("loc");
				Department dept = new Department(deptNumber, deptName, loc);
				depts.add(dept);
			}
		} catch (SQLException e) {
			logger.error("Cannot execute SQL query for dept: {}", name, e);
			throw new DatabaseException("Cannot execute SQL query for dept: " + name, e);	
		}
		return depts;
	}

	@Override
	public void addNewDepartment(Department dept) {
		String sql = "INSERT INTO dept(deptno, dname, loc) VALUES (?, ?, ?)"; 
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setInt(1, dept.getDeptNumber());
			stmt.setString(2, dept.getDeptName());
			stmt.setString(3, dept.getLocation());
			stmt.executeUpdate();
			// uncomment this line to see what happens with a stray commit
//			conn.commit();
		} catch (SQLException e) {
			logger.error("Cannot insert into dept {}", sql, e);
			throw new DatabaseException("Cannot insert into dept " + sql, e);
		}	
	}

	@Override
	public void updateDepartment(Department dept) {
		List<Department> updates = new ArrayList<>();
		updates.add(dept);
		updateInBatch(updates);
	}

	@Override
	public void updateInBatch(List<Department> depts) {
		String sql = "UPDATE DEPT SET dname = ?, loc = ? WHERE deptno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			for (Department dept: depts) {
				stmt.setString(1, dept.getDeptName());
				stmt.setString(2, dept.getLocation());
				stmt.setInt(3, dept.getDeptNumber());
				stmt.addBatch();
			}
			stmt.executeBatch();
		} catch (SQLException e) {
			logger.error("Cannot insert into dept {}", sql, e);
			throw new DatabaseException("Cannot insert into dept " + sql, e);
		}	
	}

	@Override
	public String updateByProcedure(int deptNumber) {
		String sql = "{CALL update_dept(?, ?)}";
		String result = null;
		Connection conn = getConnection();
		try (CallableStatement stmt = conn.prepareCall(sql)) {
			stmt.setInt(1, deptNumber);
			stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			stmt.executeUpdate();
			result = stmt.getString(2);
		} catch (SQLException e) {
			logger.error("Cannot update dept by proc {}", sql, e);
			throw new DatabaseException("Cannot update dept by proc " + sql, e);
		}	
		return result;
	}

	@Override
	public void deleteDepartment(int deptNumber) {
		String sql = "DELETE FROM dept WHERE deptno = ?"; 
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setInt(1, deptNumber);
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("Cannot delete from dept {}", sql, e);
			throw new DatabaseException("Cannot delete from dept " + sql, e);
		}	
	}

	
	// Standard methods below this line
	private Connection conn;

	private Connection getConnection() {
		
		if (conn == null) {
			try {
				Properties properties = new Properties();
				properties.load(this.getClass().getClassLoader()
						.getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");
				
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				throw new DatabaseException("Cannot read database properties file", e);
			} catch (SQLException e) {
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}
	
	@Override
	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				logger.error("Cannot close connection", e);
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	@Override
	public void rollbackSavepointTransaction(Savepoint savepoint) {
		Connection conn = getConnection();
		try {
			conn.rollback(savepoint);
			// If rollback fails, may leave AutoCommit in the wrong state
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			throw new DatabaseException("Cannot rollback to savepoint", e);
		}
	}

	@Override
	public Savepoint beginSavepointTransaction(String name) {
		Connection conn = getConnection();
		Savepoint sp = null;
		try {
			conn.setAutoCommit(false);
			// If savepoint fails, may leave AutoCommit in the wrong state
			sp = conn.setSavepoint(name);
		} catch (SQLException e) {
			throw new DatabaseException("Cannot create savepoint " + name, e);
		}
		return sp;
	}

	@Override
	public void rollbackTransaction() {
		Connection conn = getConnection();
		try {
			conn.rollback();
			// If rollback fails, may leave AutoCommit in the wrong state
			conn.setAutoCommit(true);
		} catch (SQLException e) {
			throw new DatabaseException("Cannot rollback", e);
		}
	}

	@Override
	public void beginTransaction() {
		Connection conn = getConnection();
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			throw new DatabaseException("Cannot create transaction", e);
		}
	}


}
