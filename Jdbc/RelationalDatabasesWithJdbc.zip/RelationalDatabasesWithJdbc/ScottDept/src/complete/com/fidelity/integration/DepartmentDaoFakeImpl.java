package com.fidelity.integration;

import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fidelity.model.Department;

public class DepartmentDaoFakeImpl implements DepartmentDao {

	private Map<Integer,Department> database;
	
	public DepartmentDaoFakeImpl() {
		database = new HashMap<>();
		resetDatabase();
	}
	
	private void resetDatabase() {
		database.clear();
		database.put(10, new Department(10, "ACCOUNTING", "NEW YORK"));
		database.put(20, new Department(20, "RESEARCH", "DALLAS"));
		database.put(30, new Department(30, "SALES", "CHICAGO"));
		database.put(40, new Department(40, "OPERATIONS", "BOSTON"));
		
	}

	@Override
	public List<Department> queryAllDepartments() {
		return new ArrayList<Department>(database.values());
	}

	@Override
	public void addNewDepartment(Department dept) {
		database.put(dept.getDeptNumber(), dept);
	}
	
	// etc


	@Override
	public void close() {
		// do nothing
	}

	@Override
	public void rollbackSavepointTransaction(Savepoint savepoint) {
		// optionally, could check the savepoint
		resetDatabase();
	}

	@Override
	public Savepoint beginSavepointTransaction(String name) {
		// do nothing
		return null;
	}

	@Override
	public void rollbackTransaction() {
		resetDatabase();
	}

	@Override
	public void beginTransaction() {
		// do nothing
	}

	@Override
	public void deleteDepartment(int deptNumber) {
		database.remove(deptNumber);
	}

	@Override
	public void updateInBatch(List<Department> depts) {
		for (Department dept: depts) {
			database.put(dept.getDeptNumber(), dept);
		}
	}

	@Override
	public String updateByProcedure(int deptNumber) {
		String result = "";
		Department dept = database.get(deptNumber);
		if (dept != null) {
			result = "NEW " + dept.getDeptName();
			Department updated = new Department(dept.getDeptNumber(), result, dept.getLocation());
			database.put(deptNumber, updated);
		}
		return result;
	}

	@Override
	public void updateDepartment(Department dept) {
		List<Department> updates = new ArrayList<>();
		updates.add(dept);
		updateInBatch(updates);
	}

	@Override
	public List<Department> queryDepartmentsByName(String name) {
		throw new UnsupportedOperationException();		
	}

	@Override
	public List<Department> queryDepartmentsByNameSimpler(String name) {
		throw new UnsupportedOperationException();		
	}


}
