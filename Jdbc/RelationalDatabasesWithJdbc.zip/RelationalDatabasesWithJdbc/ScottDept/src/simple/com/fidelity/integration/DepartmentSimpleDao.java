package com.fidelity.integration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fidelity.model.Department;

public class DepartmentSimpleDao {

	public void addNewDepartmentUnsafe(Department dept) {
		String sql = "INSERT INTO dept(deptno, dname, loc) VALUES (" 
				+ dept.getDeptNumber() + ", '"
				+ dept.getDeptName() + "', '" 
				+ dept.getLocation() + "')";
		
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace(); // better way coming soon
		}	
	}
	
	public void deleteDepartmentUnsafe(int dept) {
		String sql = "DELETE FROM dept WHERE deptno = " + dept;
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace(); // better way coming soon
		}
	}
	
	public Department queryDepartmentUnsafe(int deptQuery) {
		String sql = "SELECT deptno, dname, loc FROM dept WHERE deptno = " + deptQuery;
		Department dept = null;
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno"); // or rs.getInt(1)
				String deptName = rs.getString("dname");
				String loc = rs.getString("loc");
				dept = new Department(deptNumber, deptName, loc);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // better way coming soon
		}
		return dept;
	}
	
	public List<Department> queryAllDepartments() {
		String sql = "SELECT deptno, dname, loc FROM dept";
		List<Department> depts = new ArrayList<>();
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno"); // or rs.getInt(1)
				String deptName = rs.getString("dname");
				String loc = rs.getString("loc");
				Department dept = new Department(deptNumber, deptName, loc);
				depts.add(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // better way coming soon
		}
		return depts;
	}
	
	public List<Department> queryDepartmentsByNameUnsafe(String name) {
		String sql = "SELECT deptno, dname, loc FROM dept WHERE dname = '" + name + "'";
		List<Department> depts = new ArrayList<>();
		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno");    // or rs.getInt(1)
				String deptName = rs.getString("dname"); // or rs.getString(2)
				String loc = rs.getString("loc");
				Department dept = new Department(deptNumber, deptName, loc);
				depts.add(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace();	// better way coming soon
		}
		return depts;
	}
	
	public List<Department> queryDepartmentsByNameSafe(String name) {
		String sql = "SELECT deptno, dname, loc FROM dept WHERE dname = ?";
		List<Department> depts = new ArrayList<>();
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, name);
			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				int deptNumber = rs.getInt("deptno");    // or rs.getInt(1)
				String deptName = rs.getString("dname"); // or rs.getString(2)
				String loc = rs.getString("loc");
				Department dept = new Department(deptNumber, deptName, loc);
				depts.add(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace(); // better way coming soon
		}
		return depts;
	}
	
	private Connection conn;

	public Connection getConnection() {			
		if (conn == null) {
			// These lines are not necessary from Java 6 onwards
//			String dbDriver = "oracle.jdbc.OracleDriver";
//			try {
//				Class.forName(dbDriver);
//			} catch (ClassNotFoundException e) {
//				e.printStackTrace();
//			}

			String dbUrl = "jdbc:oracle:thin:@localhost:1521/xepdb1";
			String user = "scott";
			String password = "TIGER";

			try {
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (SQLException e) {
				e.printStackTrace(); // better way coming soon
			}
		}
		return conn;
	}

	public void close() {
		if (conn != null) {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
