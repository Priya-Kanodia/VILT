package com.fidelity.integration;

import java.io.IOException;
import java.util.Properties;

public class DepartmentDaoFactory {

	public static DepartmentDao getDepartmentDao() {
		Properties properties = new Properties();
		try {
			properties.load(DepartmentDaoFactory.class.getClassLoader()
					.getResourceAsStream("dao.properties"));
		} catch (IOException e) {
			// Let it die by printing stack trace
			e.printStackTrace();
		}
		String active = properties.getProperty("dao.active");
		return getDepartmentDao(active);
	}

	public static DepartmentDao getDepartmentDao(String active) {
		switch (active.toLowerCase()) {
			case "oracle":
				return new DepartmentDaoOracleImpl();
			case "mysql":
				return new DepartmentDaoMysqlImpl();
			case "hsqldb":
				return new DepartmentDaoHsqldbImpl();
			default:
				throw new IllegalArgumentException();
		}
	}
}
