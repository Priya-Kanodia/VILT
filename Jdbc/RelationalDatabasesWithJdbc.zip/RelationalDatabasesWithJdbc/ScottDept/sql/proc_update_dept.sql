CREATE OR REPLACE PROCEDURE update_dept
    (
        parm_deptno IN  dept.deptno%TYPE,
        parm_dname  OUT dept.dname%TYPE
    )
IS
BEGIN
    parm_dname := '';
    
    UPDATE dept
    SET    dname = 'NEW ' || dname
    WHERE  deptno = parm_deptno;
    
    IF SQL%ROWCOUNT = 1 THEN
        SELECT dname
        INTO   parm_dname
        FROM   dept
        WHERE  deptno = parm_deptno;
    END IF;
END;
/

-- We could test the proc if we wanted

--SET serveroutput ON;
--
--DECLARE
--  parm_dname dept.dname%TYPE;
--BEGIN
--  update_dept(10, parm_dname);
--  DBMS_OUTPUT.PUT_LINE( parm_dname );
--END;
--/
--
--UPDATE dept SET dname = 'ACCOUNTING' WHERE deptno = 10;
--
--COMMIT;

