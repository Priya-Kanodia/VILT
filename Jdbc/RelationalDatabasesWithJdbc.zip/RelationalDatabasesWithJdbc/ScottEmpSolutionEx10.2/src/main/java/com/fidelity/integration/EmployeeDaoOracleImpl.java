package com.fidelity.integration;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Employee;

public class EmployeeDaoOracleImpl implements EmployeeDao {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDaoOracleImpl.class);
	
	private Connection conn;

	// 7.4 #3
	@Override
	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// Since this is now called separately, throwing an exception will probably not hide one
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	private Connection getConnection() {

		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				logger.error("Cannot read db.properties", e);
				throw new DatabaseException("Cannot read db.properties", e);
			} catch (SQLException e) {
				logger.error("Cannot connect", e);
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

	// 7.2 #1
	// 10.2 #1 removed TO_CHAR on hiredate
	@Override
	public List<Employee> queryAllEmployees() {
		String sql = "SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno FROM emp";
		List<Employee> emps = new ArrayList<>();
		// 7.4 #4
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryAllEmployees: {}", sql, e);
			throw new DatabaseException("Cannot execute queryAllEmployees", e);
		}
		return emps;
	}

	// Optional 7.3 #2
	// 10.1 #1 updated salary and commission to BigDecimal
	private List<Employee> getAndHandleResults(PreparedStatement stmt) throws SQLException {
		List<Employee> emps = new ArrayList<>();
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int empNumber = rs.getInt("empno");
			String empName = rs.getString("ename");
			String job = rs.getString("job");
			Integer mgrNumber = rs.getInt("mgr");
			// Optional 10.1 #2
			if (rs.wasNull()) {
				mgrNumber = null;
			}
			// 10.2 #1
			Date tempDate = rs.getDate("hiredate");
			LocalDate hireDate = (tempDate == null) ? null : tempDate.toLocalDate();
			BigDecimal sal = rs.getBigDecimal("sal");
			BigDecimal comm = rs.getBigDecimal("comm");
			int deptNumber = rs.getInt("deptno");
			Employee emp = new Employee(empNumber, empName, job, mgrNumber, hireDate, sal, comm, deptNumber);
			emps.add(emp);
		}
		return emps;
	}

	// 7.2 #2
	// 7.3 #1
	// 10.2 #1 removed TO_CHAR on hiredate
	@Override
	public List<Employee> queryEmployeesByName(String name) {
		String sql = "SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno FROM emp "
				+ "WHERE ename = ?";
		List<Employee> emps = new ArrayList<>();
		// 7.4 #4
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, name);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeesByName: {} for {}", sql, name, e);
			throw new DatabaseException("Cannot execute queryEmployeesByName", e);
		}
		return emps;
	}

	// Optional 7.2 #3
	// Optional 7.3 #3
	// 10.2 #1 removed TO_CHAR on hiredate
	@Override
	public Employee queryEmployeeByNumber(int empNo) {
		String sql = "SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno FROM emp "
				+ "WHERE empno = ?";
		List<Employee> emps = new ArrayList<>();
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, empNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeeByNumber: {} for {}", sql, empNo, e);
			throw new DatabaseException("Cannot execute queryEmployeeByNumber", e);
		}
		/*
		 * This method only returns one Employee, but the generic query handler (getAndHandleResults) returns a list.
		 * 
		 * Return the first item in the list, if there is one. Doing it this way avoids an index out of bounds exception.
		 */
		return emps.size() > 0 ? emps.get(0) : null;
	}

	// Optional 7.2 #4
	// Optional 7.3 #4
	// 10.2 #1 removed TO_CHAR on hiredate
	@Override
	public List<Employee> queryEmployeesByDepartment(int deptNo) {
		String sql = "SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno FROM emp "
				+ "WHERE deptno = ?";
		List<Employee> emps = new ArrayList<>();
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, deptNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeesByDepartment: {} for {}", sql, deptNo, e);
			throw new DatabaseException("Cannot execute queryEmployeesByDepartment", e);
		}
		return emps;
	}

	// 9.1 #1
	// Optional 9.1 #4 re-factored to use batch method
	@Override
	public void updateEmployee(Employee emp) {
		List<Employee> emps = new ArrayList<>();
		emps.add(emp);
		updateEmployee(emps);
	}

	/*
	 * 9.1 #2
	 * 
	 * It would be conventional to list empno first in the INSERT statement. I certainly could have done that, but
	 * I have chosen to make the setXXX lists the same for UPDATE and INSERT, which will allow a better re-factoring. 
	 * 
	 * Optional 9.1 #4 re-factored to use batch method
	 */
	@Override
	public void insertEmployee(Employee emp) {
		List<Employee> emps = new ArrayList<>();
		emps.add(emp);
		insertEmployee(emps);
	}


	// 9.1 #2 (not asked for, but needed to allow tests to be reversing)
	// Optional 9.1 #4 re-factored to use batch method
	@Override
	public void deleteEmployee(int empNumber) {
		List<Integer> empNumbers = new ArrayList<>();
		empNumbers.add(empNumber);
		deleteEmployee(empNumbers);
	}

	// Optional 9.1 #3
	// 10.1 #1 updated to BigDecimal
	// 10.2 #1 updated to LocalDate
	@Override
	public int updateEmployeeSalary(BigDecimal raise, LocalDate date) {
		if (date == null) {
			throw new NullPointerException("Cannot update salary with null date");
		}
		String sql = "UPDATE emp SET sal = sal + ? WHERE hiredate < ?";
		int rows = 0;
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setBigDecimal(1, raise);
			stmt.setDate(2, Date.valueOf(date));
			rows = stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("Cannot execute updateEmployeeSalary: {} for raise {} and date {}", sql, raise, date, e);
			throw new DatabaseException("Cannot update salary", e);
		}
		return rows;
	}

	/*
	 *  Optional 9.1 #4
	 *  
	 *  You may think it would be useful to return the number of rows affected, unfortunately Oracle don't agree with
	 *  you, since the row count is not available (always returns SUCCESS_NO_INFO).
	 */
	// 10.2 #1 removed TO_DATE on hiredate
	@Override
	public void updateEmployee(List<Employee> emps) {
		String sql = "UPDATE emp SET ename = ?, job = ?, mgr = ?, hiredate = ?, "
				+ "sal = ?, comm = ?, deptno = ? WHERE empno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			handleUpdateParameters(emps, stmt);
		} catch (SQLException e) {
			logger.error("Cannot execute updateEmployee: {} for {}", sql, emps, e);
			throw new DatabaseException("Cannot update employee", e);
		}
	}

	// 10.1 #1 updated salary and commission to BigDecimal
	private void handleUpdateParameters(List<Employee> emps, PreparedStatement stmt) throws SQLException {
		for (Employee emp : emps) {
			stmt.setString(1, emp.getEmpName());
			stmt.setString(2, emp.getJob());
			// Optional 10.1 #2
			if (emp.getMgrNumber() == null) {
				stmt.setNull(3, java.sql.Types.NUMERIC);
			} else {
				stmt.setInt(3, emp.getMgrNumber());
			}
			// 10.2 #1
			stmt.setDate(4, (emp.getHireDate() == null) ? null : Date.valueOf(emp.getHireDate()));
			stmt.setBigDecimal(5, emp.getSalary());
			stmt.setBigDecimal(6, emp.getComm());
			stmt.setInt(7, emp.getDeptNumber());
			stmt.setInt(8, emp.getEmpNumber());
			stmt.addBatch();
		}
		stmt.executeBatch();
	}

	// 10.2 #1 removed TO_DATE on hiredate
	@Override
	public void insertEmployee(List<Employee> emps) {
		String sql = "INSERT INTO emp (ename, job, mgr, hiredate, sal, comm, deptno, empno) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			handleUpdateParameters(emps, stmt);
		} catch (SQLException e) {
			logger.error("Cannot execute insertEmployee: {} for {}", sql, emps, e);
			throw new DatabaseException("Cannot insert employee", e);
		}
	}

	@Override
	public void deleteEmployee(List<Integer> empNumbers) {
		String sql = "DELETE FROM emp WHERE empno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			for (int empNumber : empNumbers) {
				stmt.setInt(1, empNumber);
				stmt.addBatch();
			}
			stmt.executeBatch();
		} catch (SQLException e) {
			logger.error("Cannot execute deleteEmployee: {} for {}", sql, empNumbers, e);
			throw new DatabaseException("Cannot delete employee", e);
		}
	}

	// 9.2 #1
	@Override
	public void insertEmployeeInTransaction(List<Employee> emps) {
		Connection conn = getConnection();
		// By doing this separately, we know that AutoCommit was definitely changed by the time we reach the next try block
		try {
			conn.setAutoCommit(false);
		} catch (SQLException e) {
			throw new DatabaseException("Cannot set autocommit false, cannot start transaction", e);
		}
		/*
		 * Handling exceptions in the catch and finally blocks is extremely troublesome. Avoid it if you can. This is one
		 * of the key advantages of the try-with-resources block.
		 *  
		 * In the catch block, there is an exception being processed. It is almost certainly more important than any
		 * exception thrown in the catch block.
		 *  
		 * In the finally block, you cannot tell whether an exception was handled by the catch block, or not.
		 */
		DatabaseException dbEx = null;
		try {
			for (Employee emp : emps) {
				insertEmployee(emp);
			}
			conn.commit();
		} catch (DatabaseException | SQLException e) {
			// Catch the original exception because this is the one we want to report
			dbEx = new DatabaseException("Transactional update failed", e); 
			try {
				conn.rollback();
			} catch (SQLException e1) {
				dbEx = new DatabaseException("Cannot rollback after transactional update failed", dbEx);
				// the addSuppressed method is designed explicitly for this situation (it is used by try-with-resources)
				dbEx.addSuppressed(e1);
			}
			logger.error("Transactional update failed", dbEx);
			/*
			 * You are used to seeing the formula:
			 *     throw new DatabaseException(..., e)
			 * but the exception doesn't have to be created in the throw statement
			 */
			throw dbEx;
		} finally {
			try {
				conn.setAutoCommit(true);
			} catch (SQLException e) {
				// If the exception is null, then there was no exception thrown earlier
				if (dbEx == null) {
					throw new DatabaseException("Unable to reset autocommit to true", e);
				} else {
					dbEx.addSuppressed(e);
					// No need to throw this because the exception is already being handled
				}
			}
		}
	}

}
