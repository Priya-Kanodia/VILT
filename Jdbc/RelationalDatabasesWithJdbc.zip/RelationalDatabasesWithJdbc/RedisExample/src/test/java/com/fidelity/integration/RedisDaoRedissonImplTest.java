package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Character;
import com.fidelity.model.Voice;

class RedisDaoRedissonImplTest {

	RedisDao dao;

	@BeforeEach
	void setUp() {
		dao = new RedisDaoRedissonImpl();
		dao.deleteAllKeys();
	}

	@Test
	void testSimpleKeyValue() {
		String value42 = "Cosette";
		String value99 = "Fantine";
		
		dao.setUserName(42, value42);
		dao.setUserName(99, value99);
		
		// do something else
		
		assertEquals(value42, dao.getUserName(42));
		assertEquals(value99, dao.getUserName(99));
	}

	@Test
	void testSimpleHash() {
		Character valjean = new Character("Jean", "Valjean", Voice.DRAMATIC_TENOR);
		Character marius = new Character("Marius", "Pontmercy", Voice.TENOR);
	
		dao.storeCharacter("valjean", valjean);
		dao.storeCharacter("marius", marius);
		
		// do something else
		
		assertEquals(valjean, dao.getCharacter("valjean"));
		assertEquals(marius, dao.getCharacter("marius"));
	}

}
