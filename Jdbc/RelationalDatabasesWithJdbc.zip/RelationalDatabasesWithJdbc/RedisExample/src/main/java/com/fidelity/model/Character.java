package com.fidelity.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Character {
	private String firstName;
	private String lastName;
	private Voice voice;

	/*
	 * Json annotations are required to use Redisson with Jackson, or define class
	 * as Serializable and use with default Redisson codec (FST).
	 */
	@JsonCreator
	public Character(@JsonProperty("firstName") String firstName, 
			@JsonProperty("lastName") String lastName, 
			@JsonProperty("voice") Voice voice) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.voice = voice;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public Voice getVoice() {
		return voice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((voice == null) ? 0 : voice.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Character other = (Character) obj;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (voice != other.voice)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Character [firstName=" + firstName + ", lastName=" + lastName + ", voice=" + voice + "]";
	}

}
