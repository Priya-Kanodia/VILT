package com.fidelity.integration;

import com.fidelity.model.Character;

public interface RedisDao {

	void deleteAllKeys();

	/*
	 * Choose one key scheme and stick to it (e.g. type:id:attribute, or
	 * type/id/attribute).
	 * 
	 * All Redis types can support full binary data.
	 */
	void setUserName(int clientId, String name);

	String getUserName(int clientId);

	/*
	 * A Redis hash is a natural data type to store object data, but doesn't have 
	 * any specific support for object packaging, so objects need to be packaged
	 * and unpackaged manually.
	 * 
	 * Object can also be serialized to a known format and stored in a simple key.
	 * Typical formats are JSON (via, say, Jackson or Fastjson), Java serialization 
	 * or binary JSON (e.g. by kryo). However, doing this prevents working directly
	 * on the data using Redis primitives (e.g. transactional increment).
	 */
	void storeCharacter(String key, Character character);

	Character getCharacter(String key);

}