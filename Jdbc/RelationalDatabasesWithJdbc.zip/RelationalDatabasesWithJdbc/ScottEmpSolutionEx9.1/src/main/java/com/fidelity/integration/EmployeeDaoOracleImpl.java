package com.fidelity.integration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Employee;

public class EmployeeDaoOracleImpl implements EmployeeDao {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDaoOracleImpl.class);
	
	private Connection conn;

	// 7.4 #3
	@Override
	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// Since this is now called separately, throwing an exception will probably not hide one
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	private Connection getConnection() {

		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				logger.error("Cannot read db.properties", e);
				throw new DatabaseException("Cannot read db.properties", e);
			} catch (SQLException e) {
				logger.error("Cannot connect", e);
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

	// 7.2 #1
	@Override
	public List<Employee> queryAllEmployees() {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp";
		List<Employee> emps = new ArrayList<>();
		// 7.4 #4
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryAllEmployees: {}", sql, e);
			throw new DatabaseException("Cannot execute queryAllEmployees", e);
		}
		return emps;
	}

	// Optional 7.3 #2
	private List<Employee> getAndHandleResults(PreparedStatement stmt) throws SQLException {
		List<Employee> emps = new ArrayList<>();
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int empNumber = rs.getInt("empno");
			String empName = rs.getString("ename");
			String job = rs.getString("job");
			int mgrNumber = rs.getInt("mgr");
			String hireDate = rs.getString("hiredate");
			double sal = rs.getDouble("sal");
			double comm = rs.getDouble("comm");
			int deptNumber = rs.getInt("deptno");
			Employee emp = new Employee(empNumber, empName, job, mgrNumber, hireDate, sal, comm, deptNumber);
			emps.add(emp);
		}
		return emps;
	}

	// 7.2 #2
	// 7.3 #1
	@Override
	public List<Employee> queryEmployeesByName(String name) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE ename = ?";
		List<Employee> emps = new ArrayList<>();
		// 7.4 #4
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setString(1, name);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeesByName: {} for {}", sql, name, e);
			throw new DatabaseException("Cannot execute queryEmployeesByName", e);
		}
		return emps;
	}

	// Optional 7.2 #3
	// Optional 7.3 #3
	@Override
	public Employee queryEmployeeByNumber(int empNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE empno = ?";
		List<Employee> emps = new ArrayList<>();
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, empNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeeByNumber: {} for {}", sql, empNo, e);
			throw new DatabaseException("Cannot execute queryEmployeeByNumber", e);
		}
		/*
		 * This method only returns one Employee, but the generic query handler (getAndHandleResults) returns a list.
		 * 
		 * Return the first item in the list, if there is one. Doing it this way avoids an index out of bounds exception.
		 */
		return emps.size() > 0 ? emps.get(0) : null;
	}

	// Optional 7.2 #4
	// Optional 7.3 #4
	@Override
	public List<Employee> queryEmployeesByDepartment(int deptNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE deptno = ?";
		List<Employee> emps = new ArrayList<>();
		Connection conn = getConnection();
		// 7.4 #4c
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, deptNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// 7.4 #6
			logger.error("Cannot execute queryEmployeesByDepartment: {} for {}", sql, deptNo, e);
			throw new DatabaseException("Cannot execute queryEmployeesByDepartment", e);
		}
		return emps;
	}

	// 9.1 #1
	@Override
	public void updateEmployee(Employee emp) {
		String sql = "UPDATE emp SET ename = ?, job = ?, mgr = ?, hiredate = TO_DATE(?, 'DD-MON-YYYY'), "
				+ "sal = ?, comm = ?, deptno = ? WHERE empno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1, emp.getEmpName());
			stmt.setString(2, emp.getJob());
			stmt.setInt(3, emp.getMgrNumber());
			stmt.setString(4, emp.getHireDate());
			stmt.setDouble(5, emp.getSalary());
			stmt.setDouble(6, emp.getComm());
			stmt.setInt(7, emp.getDeptNumber());
			stmt.setInt(8, emp.getEmpNumber());
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("Cannot execute updateEmployee: {} for {}", sql, emp, e);
			throw new DatabaseException("Cannot update employee", e);
		}
	}

	/*
	 * 9.1 #2
	 * 
	 * It would be conventional to list empno first in the INSERT statement. I certainly could have done that, but
	 * I have chosen to make the setXXX lists the same for UPDATE and INSERT, which will allow a better re-factoring. 
	 */
	@Override
	public void insertEmployee(Employee emp) {
		String sql = "INSERT INTO emp (ename, job, mgr, hiredate, sal, comm, deptno, empno) "
				+ "VALUES (?, ?, ?, TO_DATE(?, 'DD-MON-YYYY'), ?, ?, ?, ?)";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setString(1, emp.getEmpName());
			stmt.setString(2, emp.getJob());
			stmt.setInt(3, emp.getMgrNumber());
			stmt.setString(4, emp.getHireDate());
			stmt.setDouble(5, emp.getSalary());
			stmt.setDouble(6, emp.getComm());
			stmt.setInt(7, emp.getDeptNumber());
			stmt.setInt(8, emp.getEmpNumber());
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("Cannot execute insertEmployee: {} for {}", sql, emp, e);
			throw new DatabaseException("Cannot insert employee", e);
		}
	}


	// 9.1 #2 (not asked for, but needed to allow tests to be reversing)
	@Override
	public void deleteEmployee(int empNumber) {
		String sql = "DELETE FROM emp WHERE empno = ?";
		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)){
			stmt.setInt(1, empNumber);
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("Cannot execute deleteEmployee: {} for {}", sql, empNumber, e);
			throw new DatabaseException("Cannot delete employee", e);
		}
	}

}
