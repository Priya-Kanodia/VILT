package com.fidelity.integration;

import java.util.ArrayList;
import java.util.List;

import com.fidelity.model.Employee;

public class EmployeeDaoMockImpl implements EmployeeDao {

	Employee emp7369;
	Employee emp7934;
	
	public EmployeeDaoMockImpl() {
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, "17-DEC-1980", 800.0, 0.0, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, "23-JAN-1982", 1300.0, 0.0, 10);
	}

	@Override
	public void close() {
		// do nothing
	}

	@Override
	public List<Employee> queryAllEmployees() {
		// Test is for 2 employees that contain both of the test employees
		List<Employee> emps = new ArrayList<>();
		emps.add(emp7369);
		emps.add(emp7934);
		return emps;
	}

	@Override
	public List<Employee> queryEmployeesByName(String name) {
		List<Employee> emps = new ArrayList<>();
		if (name.equals("SMITH")) {
			emps.add(emp7369);
		}
		return emps;
	}


	@Override
	public Employee queryEmployeeByNumber(int empNo) {
		if (empNo == 7369) {
			return emp7369;
		}
		return null;
	}

	@Override
	public List<Employee> queryEmployeesByDepartment(int deptNo) {
		List<Employee> emps = new ArrayList<>();
		if (deptNo == 10) {
			emps.add(emp7934);	
		} else if (deptNo == 20) {
			emps.add(emp7369);
		}
		return emps;
	}

	// 9.1 #1 & 2: no need to support these operations in the mock
	@Override
	public void updateEmployee(Employee upd7369) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void insertEmployee(Employee new8000) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void deleteEmployee(int i) {
		throw new UnsupportedOperationException();
	}

}
