package com.fidelity.model;

import java.time.LocalDate;

public class HighLowTemp {

	@Override
	public String toString() {
		return "HighLowTemp [recordDate=" + recordDate + ", highTemp=" + highTemp + ", lowTemp=" + lowTemp + "]";
	}

	private LocalDate recordDate;
	private double highTemp;
	private double lowTemp;
	
	public HighLowTemp(LocalDate recordDate, double highTemp, double lowTemp) {
		super();
		this.recordDate = recordDate;
		this.highTemp = highTemp;
		this.lowTemp = lowTemp;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(highTemp);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(lowTemp);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((recordDate == null) ? 0 : recordDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HighLowTemp other = (HighLowTemp) obj;
		if (Double.doubleToLongBits(highTemp) != Double.doubleToLongBits(other.highTemp))
			return false;
		if (Double.doubleToLongBits(lowTemp) != Double.doubleToLongBits(other.lowTemp))
			return false;
		if (recordDate == null) {
			if (other.recordDate != null)
				return false;
		} else if (!recordDate.equals(other.recordDate))
			return false;
		return true;
	}
	
	
}
