package com.fidelity.integration;

import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.dbunit.DatabaseUnitException;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.ext.oracle.OracleDataTypeFactory;

import com.fidelity.model.HighLowTemp;

public class HighLowTempDao {

	// Prepare a DBUnit data set from the whole table (makes no real attempt to handle exceptions because we expect to call directly)
    public void makeDbUnitDataSet(String fileName) throws DatabaseUnitException, IOException, SQLException {

    	Connection conn = getConnection();
        IDatabaseConnection connection = new DatabaseConnection(conn);

        // No idea why this should be necessary. The DBUnit log appears to show it creating a type factory correctly.
        DatabaseConfig config = connection.getConfig();
        config.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new OracleDataTypeFactory());
        
        QueryDataSet newDataSet = new QueryDataSet(connection);
        newDataSet.addTable("HIGHLOW_TEMP", "SELECT * FROM HIGHLOW_TEMP");
        FlatXmlDataSet.write(newDataSet, new FileOutputStream(fileName));

        // Normally we would just close the DBUnit database connection, which closes the underlying connection, but because of the way
        // we are managing connections here, we need to reset conn.
        connection.close();
        this.conn = null;
    }

	public List<HighLowTemp> getAllTemps() {
		String sql = "SELECT record_date, high_temp, low_temp FROM highlow_temp";
		List<HighLowTemp> temps = new ArrayList<>();
		Statement stmt = null;
		
		Connection conn = getConnection();
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				LocalDate recordDate = rs.getDate("record_date").toLocalDate();
				Double highTemp = rs.getDouble("high_temp");
				Double lowTemp = rs.getDouble("low_temp");
				
				temps.add(new HighLowTemp(recordDate, highTemp, lowTemp));
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot execute SQL query for dept: " + sql, e);	
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return temps;
	}

	// Standard methods below this line
	private Connection conn;

	private Connection getConnection() {
		
		if (conn == null) {
			try {
				Properties properties = new Properties();
				properties.load(this.getClass().getClassLoader()
						.getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");
				
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				throw new DatabaseException("Cannot read database properties file", e);
			} catch (SQLException e) {
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}


}
