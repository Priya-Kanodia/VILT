package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Properties;

import org.dbunit.IDatabaseTester;
import org.dbunit.IOperationListener;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.oracle.Oracle10DataTypeFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.HighLowTemp;

/*
 * This is the "modern" style of DBUnit, where the test class does not extend DBTestCase.
 * JUnit 5 compatibility is provided by the JdbcDatabaseTester helper class.
 */
class HighLowTempDaoTest {

	private HighLowTempDao dao;

	private IDatabaseTester dbTester;
	private IDataSet dataSet;

	@BeforeEach
	void setUp() throws Exception {
		Properties properties = new Properties();
		properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
		String dbUrl = properties.getProperty("db.url");
		String dbDriver = properties.getProperty("db.driver");
		String user = properties.getProperty("db.username");
		String password = properties.getProperty("db.password");
		String schema = "SCOTT";

		// Create database tester helper class
		dbTester = new JdbcDatabaseTester(dbDriver, dbUrl, user, password, schema);

	    dbTester.setOperationListener(new IOperationListener() {
			@Override
			public void connectionRetrieved(IDatabaseConnection connection) {
			    DatabaseConfig dbConfig = connection.getConfig();
			    // added this line to get rid of the warning about the type factory
			    dbConfig.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new Oracle10DataTypeFactory());
			  //  dbConfig.setProperty(DatabaseConfig.FEATURE_QUALIFIED_TABLE_NAMES, true);
			}

			@Override
			public void operationSetUpFinished(IDatabaseConnection connection) {
				// do nothing
			}

			@Override
			public void operationTearDownFinished(IDatabaseConnection connection) {
				// do nothing
			}
	    });

		// Create "before" data set and use it to populate the tables
		dataSet = new FlatXmlDataSetBuilder().build(this.getClass().getClassLoader().getResourceAsStream("data.xml"));
		dbTester.setDataSet(dataSet);

		// will call default setUpOperation (which is CLEAN_INSERT)
		dbTester.onSetup();

		dao = new HighLowTempDao();
	}

	@AfterEach
	void tearDown() throws Exception {
		dao.close();

		// will call default tearDownOperation (which is NONE)
		dbTester.onTearDown();
	}

	@Test
	void testSimple() {
		HighLowTemp expected = new HighLowTemp(LocalDate.of(2017,1,1), 15.1, 30.7);
		List<HighLowTemp> temps = dao.getAllTemps();
		assertTrue(temps.contains(expected), "Should contain expected data");
		assertEquals(3, temps.size(), "Should be 3 records");
	}

	@Test
	void testFullCompare() throws Exception {
		/*
		 * This is just an example. As written, we don't need to use the dao at all for this test to work.
		 * 
		 * Normally, we follow this approach:
		 * 1. Create expected data
		 * 2. Perform database action at the heart of the test
		 * 3. Take a snapshot and compare
		 * 
		 * The expected data might come from a snapshot (with or without some modification in code) or from an XML file
		 * or from a query:
		 *     ITable expectedTable = getConnection().createQueryTable("FAKE_DATA", "SELECT * FROM TABLE1, TABLE2 WHERE ...");
		 * 
		 * There are also assert methods that ignore specific columns in the tables.
		 * 
		 * In this example, the expected data will be the DataSet we created from the XML file earlier. Clearly, we just
		 * loaded this file, so this particular example isn't realistic.
		 */

		// At this point, we would perform some database operation using the Dao under test
		
		/*
		 * For some reason, using the connection to create a DataSet does not invoke the listener, so manually set the 
		 * data type factory to the appropriate type to avoid the warning
		 */
		IDatabaseConnection conn = dbTester.getConnection();
	    DatabaseConfig dbConfig = conn.getConfig();
	    dbConfig.setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new Oracle10DataTypeFactory());
	  //  dbConfig.setProperty(DatabaseConfig.FEATURE_QUALIFIED_TABLE_NAMES, true);
	    
		// Create an extract from the database including just the table(s) we're interested in
		String[] tables = {"HIGHLOW_TEMP"};
		IDataSet actualDataSet = conn.createDataSet(tables);

		// Get the same table from two DataSets
		ITable actualTable = actualDataSet.getTable("HIGHLOW_TEMP");
		ITable expectedTable = dataSet.getTable("HIGHLOW_TEMP");

		// Compare the tables (use a fully qualified class name to avoid conflicts with JUnit)
		org.dbunit.Assertion.assertEquals(expectedTable, actualTable);
		// Alternatively, we could compare the whole DataSet
		org.dbunit.Assertion.assertEquals(dataSet, actualDataSet);
	}

}
