CREATE TABLE highlow_temp
(
    record_date DATE PRIMARY KEY,
    high_temp   NUMBER(6,2),
    low_temp    NUMBER(6,2)
);

