package com.fidelity.integration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.pool.OracleDataSource;

public class EmployeeDao {
	
	private Connection conn;

	public Connection getConnection() throws SQLException, ClassNotFoundException {

		if (conn == null) {
			String dbUrl = "jdbc:oracle:thin:@localhost:1521/xepdb1";
			String user = "scott";
			String password = "TIGER";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dbUrl, user, password);

		}
		return conn;
	}



}
