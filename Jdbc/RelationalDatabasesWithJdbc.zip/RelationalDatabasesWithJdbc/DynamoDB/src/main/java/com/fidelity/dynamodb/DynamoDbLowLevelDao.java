package com.fidelity.dynamodb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.CreateTableResult;
import com.amazonaws.services.dynamodbv2.model.DescribeTableRequest;
import com.amazonaws.services.dynamodbv2.model.GetItemResult;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ListTablesRequest;
import com.amazonaws.services.dynamodbv2.model.ListTablesResult;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.QueryRequest;
import com.amazonaws.services.dynamodbv2.model.QueryResult;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;
import com.amazonaws.services.dynamodbv2.model.ReturnConsumedCapacity;
import com.amazonaws.services.dynamodbv2.model.ReturnItemCollectionMetrics;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;
import com.amazonaws.waiters.FixedDelayStrategy;
import com.amazonaws.waiters.MaxAttemptsRetryStrategy;
import com.amazonaws.waiters.PollingStrategy;
import com.amazonaws.waiters.Waiter;
import com.amazonaws.waiters.WaiterParameters;
import com.amazonaws.waiters.WaiterTimedOutException;
import com.amazonaws.waiters.WaiterUnrecoverableException;
import com.fidelity.model.Music;

public class DynamoDbLowLevelDao implements DynamoDbDao {
	private static final String TABLE_NAME = "MusicJava";
	private static AmazonDynamoDB client;

	private AmazonDynamoDB getClient() {
		if (client == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("dyn.properties"));
			} catch (IOException e) {
				throw new DatabaseException(e);
			}
			String url = properties.getProperty("dyn.url");
			String region = properties.getProperty("dyn.region");

			client = AmazonDynamoDBClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(url, region))
					.build();
		}
		return client;
	}

	@Override
	public void deleteTable(boolean ignoreNotFound) {
		AmazonDynamoDB client = getClient();

		try {
			client.deleteTable(TABLE_NAME);
		} catch (ResourceNotFoundException e) {
			if (!ignoreNotFound) {
				throw e;
			}
		}

		/*
		 * Working on the local DynamoDB, the delete operation will complete immediately,
		 * but when working on the cloud version, deleting a table will take some time
		 */
		Waiter<DescribeTableRequest> waiter = client.waiters().tableNotExists();
		try {
			waiter.run(new WaiterParameters<DescribeTableRequest>(new DescribeTableRequest(TABLE_NAME))
					.withPollingStrategy(new PollingStrategy(new MaxAttemptsRetryStrategy(25), new FixedDelayStrategy(5))));
		} catch (WaiterTimedOutException | WaiterUnrecoverableException e) {
			throw new IllegalArgumentException("Table " + TABLE_NAME + " is not deleted.", e);
		}

	}

	@Override
	public void createTable() {
		AmazonDynamoDB client = getClient();

		CreateTableRequest request = new CreateTableRequest()
				.withTableName(TABLE_NAME)
				.withAttributeDefinitions(new AttributeDefinition("artist", ScalarAttributeType.S),
						new AttributeDefinition("trackTitle", ScalarAttributeType.S))
				.withKeySchema(new KeySchemaElement("artist", KeyType.HASH),
						new KeySchemaElement("trackTitle", KeyType.RANGE))
				.withProvisionedThroughput(new ProvisionedThroughput(1L, 1L));
		@SuppressWarnings("unused")
		CreateTableResult response = client.createTable(request);
		// response contains a TableDescription, similar to the CLI response

		/*
		 * As with the delete, when working on the local DynamoDB, the create operation will
		 * complete immediately, but when working on the cloud version, it will take some time
		 */
		Waiter<DescribeTableRequest> waiter = client.waiters().tableExists();
		try {
			waiter.run(new WaiterParameters<DescribeTableRequest>(new DescribeTableRequest(TABLE_NAME))
					.withPollingStrategy(new PollingStrategy(new MaxAttemptsRetryStrategy(25), new FixedDelayStrategy(5))));
		} catch (WaiterTimedOutException | WaiterUnrecoverableException e) {
			throw new IllegalArgumentException("Table " + TABLE_NAME + " did not transition into ACTIVE state.", e);
		}
	}

	@Override
	public boolean checkTableExists() {
		AmazonDynamoDB client = getClient();

		ListTablesRequest request;
		boolean moreTables = true;
		String lastTable = null;

		while (moreTables) {
			if (lastTable == null) {
				request = new ListTablesRequest()
						.withLimit(10); // defaults to 100 tables
			} else {
				request = new ListTablesRequest()
						.withLimit(10)
						.withExclusiveStartTableName(lastTable);
			}

			ListTablesResult result = client.listTables(request);
			List<String> tableNames = result.getTableNames();
			for (String name : tableNames) {
				if (name.equals(TABLE_NAME)) {
					return true;
				}
			}

			lastTable = result.getLastEvaluatedTableName();
			if (lastTable == null) {
				moreTables = false;
			}
		}
		return false;
	}

	@Override
	public void putItem(Music music) {
		AmazonDynamoDB client = getClient();

		Map<String, AttributeValue> item = createItemFromMusic(music);
		@SuppressWarnings("unused")
		PutItemResult pir = client.putItem(TABLE_NAME, item);
		// We don't do anything with the result here, but we could!
	}

	@Override
	public void putItemExtended(Music music) {
		AmazonDynamoDB client = getClient();

		Map<String, AttributeValue> item = createItemFromMusic(music);
		PutItemRequest request = new PutItemRequest()
				.withTableName(TABLE_NAME)
				.withReturnValues(ReturnValue.ALL_OLD)
				.withReturnConsumedCapacity(ReturnConsumedCapacity.INDEXES)
				.withReturnItemCollectionMetrics(ReturnItemCollectionMetrics.SIZE)
				.withItem(item);
		PutItemResult pir = client.putItem(request);
		// We print the result just so it can be compared to the CLI output
		System.out.println(pir);
	}

	@Override
	public Music getMusicByKey(String artist, String trackTitle) {
		AmazonDynamoDB client = getClient();

		Map<String, AttributeValue> key = new HashMap<>();
		key.put("artist", new AttributeValue(artist));
		key.put("trackTitle", new AttributeValue(trackTitle));
		GetItemResult gir = client.getItem(TABLE_NAME, key);
		return createMusicFromItem(gir.getItem());
	}

	@Override
	public List<Music> getAllMusic() {
		return scanMusic(new ScanRequest());
	}

	@Override
	public List<Music> getThreeMinuteTracks() {
		Map<String, AttributeValue> values = new HashMap<>();
		values.put(":length", new AttributeValue().withN("180"));

		ScanRequest request = new ScanRequest()
				.withFilterExpression("lengthInSeconds < :length")
				.withExpressionAttributeValues(values);
		return scanMusic(request);
	}

	private List<Music> scanMusic(ScanRequest request) {
		AmazonDynamoDB client = getClient();
		
		request.setTableName(TABLE_NAME);

		ScanResult result = client.scan(request);
		List<Map<String, AttributeValue>> items = result.getItems();
		List<Music> music = new ArrayList<>();
		for (Map<String, AttributeValue> item: items) {
			music.add(createMusicFromItem(item));
		}
		return music;
	}

	@Override
	public List<Music> queryMusicByArtist(String artist) {
		AmazonDynamoDB client = getClient();

		Map<String, AttributeValue> values = new HashMap<>();
		values.put(":artist", new AttributeValue(artist));

		QueryRequest request = new QueryRequest()
				.withTableName(TABLE_NAME)
				.withKeyConditionExpression("artist = :artist")
				.withExpressionAttributeValues(values);
		QueryResult result = client.query(request);
		List<Map<String, AttributeValue>> items = result.getItems();
		List<Music> music = new ArrayList<>();
		for (Map<String, AttributeValue> item: items) {
			music.add(createMusicFromItem(item));
		}
		return music;
	}

	private Map<String, AttributeValue> createItemFromMusic(Music music) {
		Map<String, AttributeValue> item = new HashMap<>();
		
		item.put("artist", new AttributeValue(music.getArtist()));
		item.put("trackTitle", new AttributeValue(music.getTrackTitle()));
		if (music.getAvailable() != null) {
			item.put("available", new AttributeValue().withBOOL(music.getAvailable()));
		}
		if (music.getAlbumTitle() != null) {
			item.put("albumTitle", new AttributeValue(music.getAlbumTitle()));
		}
		if (music.getGenres() != null) {
			item.put("genres", new AttributeValue().withSS(music.getGenres()));
		}
		if (music.getLengthInSeconds() != null) {
			item.put("lengthInSeconds", new AttributeValue().withN(Integer.toString(music.getLengthInSeconds())));
		}
		if (music.getYear() != null) {
			item.put("year", new AttributeValue().withN(Integer.toString(music.getYear())));
		}
		return item;
	}

	private Music createMusicFromItem(Map<String, AttributeValue> item) {
		Music music = new Music();
		music.setArtist(item.get("artist").getS());
		music.setTrackTitle(item.get("trackTitle").getS());
		if (item.containsKey("available")) {
			music.setAvailable(item.get("available").getBOOL());
		}
		if (item.containsKey("albumTitle")) {
			music.setAlbumTitle(item.get("albumTitle").getS());
		}
		if (item.containsKey("genres")) {
			music.setGenres(item.get("genres").getSS());
		}
		if (item.containsKey("lengthInSeconds")) {
			music.setLengthInSeconds(Integer.valueOf(item.get("lengthInSeconds").getN()));
		}
		if (item.containsKey("year")) {
			music.setYear(Integer.valueOf(item.get("year").getN()));
		}
		return music;
	}
}
