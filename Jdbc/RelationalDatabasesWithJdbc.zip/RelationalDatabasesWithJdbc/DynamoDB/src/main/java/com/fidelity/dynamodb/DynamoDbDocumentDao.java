package com.fidelity.dynamodb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.TableCollection;
import com.amazonaws.services.dynamodbv2.document.spec.PutItemSpec;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.spec.ScanSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ListTablesResult;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ResourceNotFoundException;
import com.amazonaws.services.dynamodbv2.model.ReturnConsumedCapacity;
import com.amazonaws.services.dynamodbv2.model.ReturnItemCollectionMetrics;
import com.amazonaws.services.dynamodbv2.model.ReturnValue;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.fidelity.model.Music;

public class DynamoDbDocumentDao implements DynamoDbDao {
	private static final String TABLE_NAME = "MusicJava";
	private static DynamoDB dynamoDb;

	private DynamoDB getClient() {
		if (dynamoDb == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("dyn.properties"));
			} catch (IOException e) {
				throw new DatabaseException(e);
			}
			String url = properties.getProperty("dyn.url");
			String region = properties.getProperty("dyn.region");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(url, region))
					.build();

			dynamoDb = new DynamoDB(client);
		}
		return dynamoDb;
	}

	@Override
	public void deleteTable(boolean ignoreNotFound) {
		DynamoDB dynamoDb = getClient();

		Table table = dynamoDb.getTable(TABLE_NAME);
		try {
			table.delete();
		} catch (ResourceNotFoundException e) {
			if (!ignoreNotFound) {
				throw e;
			}
		}
		try {
			table.waitForDelete();
		} catch (InterruptedException e) {
			throw new DatabaseException(e);
		}
	}

	@Override
	public void createTable() {
		DynamoDB dynamoDb = getClient();

		Table table = dynamoDb.createTable(TABLE_NAME,
				Arrays.asList(new KeySchemaElement("artist", KeyType.HASH),	// Partition key
						new KeySchemaElement("trackTitle", KeyType.RANGE)),	// Sort key
				Arrays.asList(new AttributeDefinition("artist", ScalarAttributeType.S),
						new AttributeDefinition("trackTitle", ScalarAttributeType.S)),
				new ProvisionedThroughput(1L, 1L));
		try {
			table.waitForActive();
		} catch (InterruptedException e) {
			throw new DatabaseException(e);
		}
	}

	/*
	 * Clearly we could also do this with a Table#describe, but this illustrates listTables().
	 * 
	 * Note that DynamoDB#getTable does not cause any network traffic, so it does not actually 
	 * check that the table exists.
	 */
	@Override
	public boolean checkTableExists() {
		DynamoDB dynamoDb = getClient();

		TableCollection<ListTablesResult> list = dynamoDb.listTables();
		Iterator<Table> iterator = list.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().getTableName().equals(TABLE_NAME)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void putItem(Music music) {
		DynamoDB dynamoDb = getClient();
		Table table = dynamoDb.getTable(TABLE_NAME);

		Item item = createItemFromMusic(music);
		@SuppressWarnings("unused")
		PutItemOutcome pio = table.putItem(item);
		// We don't do anything with the outcome here, but we could!
	}

	@Override
	public void putItemExtended(Music music) {
		DynamoDB dynamoDb = getClient();
		Table table = dynamoDb.getTable(TABLE_NAME);

		Item item = createItemFromMusic(music);
		PutItemSpec spec = new PutItemSpec()
				.withReturnValues(ReturnValue.ALL_OLD)
				.withReturnConsumedCapacity(ReturnConsumedCapacity.INDEXES)
				.withReturnItemCollectionMetrics(ReturnItemCollectionMetrics.SIZE)
				.withItem(item);
		PutItemOutcome pio = table.putItem(spec);
		// We print the outcome just so it can be compared to the CLI output
		System.out.println(pio);
	}

	@Override
	public Music getMusicByKey(String artist, String trackTitle) {
		DynamoDB dynamoDb = getClient();
		Table table = dynamoDb.getTable(TABLE_NAME);

		Item item = table.getItem("artist", artist, "trackTitle", trackTitle);
		return createMusicFromItem(item);
	}

	@Override
	public List<Music> getAllMusic() {
		return scanMusic(new ScanSpec());
	}

	@Override
	public List<Music> getThreeMinuteTracks() {
		ScanSpec spec = new ScanSpec()
				.withFilterExpression("lengthInSeconds < :length")
				.withValueMap(new ValueMap().withNumber(":length", 180));
		return scanMusic(spec);
	}

	private List<Music> scanMusic(ScanSpec spec) {
		DynamoDB dynamoDb = getClient();
		Table table = dynamoDb.getTable(TABLE_NAME);

		ItemCollection<ScanOutcome> items = table.scan(spec);
		Iterator<Item> iterator = items.iterator();
		List<Music> music = new ArrayList<>();
		while (iterator.hasNext()) {
			music.add(createMusicFromItem(iterator.next()));
		}
		return music;
	}

	@Override
	public List<Music> queryMusicByArtist(String artist) {
		DynamoDB dynamoDb = getClient();
		Table table = dynamoDb.getTable(TABLE_NAME);

		QuerySpec spec = new QuerySpec()
				.withKeyConditionExpression("artist = :artist")
				.withValueMap(new ValueMap().withString(":artist", artist));
		ItemCollection<QueryOutcome> items = table.query(spec);
		Iterator<Item> iterator = items.iterator();
		List<Music> music = new ArrayList<>();
		while (iterator.hasNext()) {
			music.add(createMusicFromItem(iterator.next()));
		}
		return music;
	}

	private Item createItemFromMusic(Music music) {
		Item item = new Item().withPrimaryKey("artist", music.getArtist(), "trackTitle", music.getTrackTitle());
		if (music.getAvailable() != null) {
			item.withBoolean("available", music.getAvailable());
		}
		if (music.getAlbumTitle() != null) {
			item.withString("albumTitle", music.getAlbumTitle());
		}
		if (music.getGenres() != null) {
			item.withStringSet("genres", music.getGenres().toArray(new String[1]));
		}
		if (music.getLengthInSeconds() != null) {
			item.withInt("lengthInSeconds", music.getLengthInSeconds());
		}
		if (music.getYear() != null) {
			item.withInt("year", music.getYear());
		}
		return item;
	}

	private Music createMusicFromItem(Item item) {
		Music music = new Music();
		music.setArtist(item.getString("artist"));
		music.setTrackTitle(item.getString("trackTitle"));
		if (item.isPresent("available") && !item.isNull("available")) {
			music.setAvailable(item.getBoolean("available"));
		}
		if (item.isPresent("albumTitle") && !item.isNull("albumTitle")) {
			music.setAlbumTitle(item.getString("albumTitle"));
		}
		if (item.isPresent("genres") && !item.isNull("genres")) {
			music.setGenres(new ArrayList<String>(item.getStringSet("genres")));
		}
		if (item.isPresent("lengthInSeconds") && !item.isNull("lengthInSeconds")) {
			music.setLengthInSeconds(item.getInt("lengthInSeconds"));
		}
		if (item.isPresent("year") && !item.isNull("year")) {
			music.setYear(item.getInt("year"));
		}
		return music;
	}

}
