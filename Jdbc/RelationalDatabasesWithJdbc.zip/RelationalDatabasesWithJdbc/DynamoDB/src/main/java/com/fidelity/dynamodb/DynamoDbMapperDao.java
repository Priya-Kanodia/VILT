package com.fidelity.dynamodb;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIgnore;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverted;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import com.fidelity.model.Music;

public class DynamoDbMapperDao implements DynamoDbDao {
	private static DynamoDBMapper mapper;

	private DynamoDBMapper getClient() {
		if (mapper == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("dyn.properties"));
			} catch (IOException e) {
				throw new DatabaseException(e);
			}
			String url = properties.getProperty("dyn.url");
			String region = properties.getProperty("dyn.region");

			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard()
					.withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(url, region))
					.build();

			mapper = new DynamoDBMapper(client);
		}
		return mapper;
	}

	/*
	 * By default, save uses updateItem rather than putItem, which means it does
	 * not overwrite non-key attributes if they are not present in the item being
	 * saved. This can be changed by passing in an optional DynamoDBMapperConfig.
	 */
	@Override
	public void putItem(Music music) {
		DynamoDBMapper mapper = getClient();
		
		MusicItem item = new MusicItem(music);
		mapper.save(item);
	}

	public Music getMusicByKey(String artist, String trackTitle) {
		DynamoDBMapper mapper = getClient();

		MusicItem item = mapper.load(MusicItem.class, artist, trackTitle);
		return convertMusicItemToMusic(item);
	}

	public List<Music> getAllMusic() {
		return scanMusic(new DynamoDBScanExpression());
	}

	public List<Music> getThreeMinuteTracks() {
		Map<String, AttributeValue> values = new HashMap<>();
		values.put(":length", new AttributeValue().withN("180"));

		DynamoDBScanExpression expression = new DynamoDBScanExpression()
				.withFilterExpression("lengthInSeconds < :length")
				.withExpressionAttributeValues(values);
		return scanMusic(expression);
	}

	private List<Music> scanMusic(DynamoDBScanExpression scanExpression) {
		DynamoDBMapper mapper = getClient();

        List<MusicItem> items = mapper.scan(MusicItem.class, scanExpression);
        return convertMusicItemsToMusicList(items);
	}

	public List<Music> queryMusicByArtist(String artist) {
		DynamoDBMapper mapper = getClient();

		Map<String, AttributeValue> values = new HashMap<>();
		values.put(":artist", new AttributeValue(artist));

        DynamoDBQueryExpression<MusicItem> queryExpression = new DynamoDBQueryExpression<MusicItem>()
				.withKeyConditionExpression("artist = :artist")
				.withExpressionAttributeValues(values);

        List<MusicItem> items = mapper.query(MusicItem.class, queryExpression);
        return convertMusicItemsToMusicList(items);
	}

	/*
	 * Normally, we would just annotated the domain class (Music), but in this case,
	 * we wanted to leave Music "clean" to show how it would be for the low-level and
	 * document APIs. For that reason, we have created a second domain class here that
	 * represents a MusicItem. We will convert from that to a normal Music object so 
	 * that the DAO interface can be the same as the other DAOs.
	 */
	private Music convertMusicItemToMusic(MusicItem item) {
		return new Music(item.getArtist(), item.getTrackTitle(), 
				item.getAlbumTitle(), item.getYear(), item.getLengthInSeconds(), 
				item.getGenres(), item.getAvailable());
	}

	private List<Music> convertMusicItemsToMusicList(List<MusicItem> items) {
        List<Music> music = new ArrayList<>();
		for (MusicItem item: items) {
			music.add(convertMusicItemToMusic(item));
		}
		return music;
	}


	@DynamoDBTable(tableName = "MusicJava")
	public static class MusicItem {
		@DynamoDBHashKey(attributeName="artist")
		private String artist;

		@DynamoDBRangeKey(attributeName="trackTitle")
		private String trackTitle;

		private String albumTitle;
		private Integer year;
		private Integer lengthInSeconds;

		@DynamoDBTypeConverted(converter=GenreConverter.class)
		@DynamoDBAttribute(attributeName="genres")
		private List<String> genreList;

		private Boolean	available;

		// This field is just here so we can ignore it later
		@DynamoDBIgnore
		private String dummy = "DUMMY";

		// Copy constructor from Music
		public MusicItem(Music music) {
			this.artist = music.getArtist();
			this.trackTitle = music.getTrackTitle();
			this.albumTitle = music.getAlbumTitle();
			this.year = music.getYear();
			this.lengthInSeconds = music.getLengthInSeconds();
			this.genreList = music.getGenres();
			this.available = music.getAvailable();	
		}

		// Eclipse generated from here
		public MusicItem() {
			super();
		}

		public MusicItem(String artist, String trackTitle, String albumTitle, Integer year, Integer lengthInSeconds,
				List<String> genres, Boolean available) {
			super();
			this.artist = artist;
			this.trackTitle = trackTitle;
			this.albumTitle = albumTitle;
			this.year = year;
			this.lengthInSeconds = lengthInSeconds;
			this.genreList = genres;
			this.available = available;
		}

		public String getArtist() {
			return artist;
		}

		public void setArtist(String artist) {
			this.artist = artist;
		}

		public String getTrackTitle() {
			return trackTitle;
		}

		public void setTrackTitle(String trackTitle) {
			this.trackTitle = trackTitle;
		}

		public String getAlbumTitle() {
			return albumTitle;
		}

		public void setAlbumTitle(String albumTitle) {
			this.albumTitle = albumTitle;
		}

		public Integer getYear() {
			return year;
		}

		public void setYear(Integer year) {
			this.year = year;
		}

		public Integer getLengthInSeconds() {
			return lengthInSeconds;
		}

		public void setLengthInSeconds(Integer lengthInSeconds) {
			this.lengthInSeconds = lengthInSeconds;
		}

		public List<String> getGenres() {
			return genreList;
		}

		public void setGenres(List<String> genres) {
			this.genreList = genres;
		}

		public Boolean getAvailable() {
			return available;
		}

		public void setAvailable(Boolean available) {
			this.available = available;
		}

		public String getDummy() {
			return dummy;
		}

		public void setDummy(String dummy) {
			this.dummy = dummy;
		}

		@Override
		public String toString() {
			return "MusicItem [artist=" + artist + ", trackTitle=" + trackTitle + ", albumTitle=" + albumTitle + ", year="
					+ year + ", lengthInSeconds=" + lengthInSeconds + ", genres=" + genreList + ", available=" + available
					+ ", dummy=" + dummy + "]";
		}
	}

	/*
	 * This illustrates how to convert a Java type that is not automatically supported.
	 * 
	 * The first type parameter is the storage type, the second is the Java property type.
	 */
	public static class GenreConverter implements DynamoDBTypeConverter<Set<String>, List<String>> {

		@Override
		public Set<String> convert(List<String> object) {
			return new HashSet<String>(object);
		}

		@Override
		public List<String> unconvert(Set<String> object) {
			return new ArrayList<String>(object);
		}
	}
	
	/*
	 * The mapper API does not allow table level operations, so delegate those to 
	 * the Document API, where necessary. Otherwise have them throw an exception.
	 * 
	 * This is the proxy pattern at work.
	 */
	private static DynamoDbDao documentDao = new DynamoDbDocumentDao();

	@Override
	public void deleteTable(boolean ignoreNotFound) {
		documentDao.deleteTable(ignoreNotFound);
	}

	@Override
	public void createTable() {
		documentDao.createTable();
	}

	/*
	 * This method is not used in this DAO, but could easily be delegated to the 
	 * Document API.
	 */
	
	@Override
	public boolean checkTableExists() {
		throw new UnsupportedOperationException("not implemented");
	}

	/*
	 * There is no direct equivalent of the putItem that uses a Request or a 
	 * Spec since the save method does not return anything. 
	 */
	@Override
	public void putItemExtended(Music music) {
		throw new UnsupportedOperationException("not implemented");
	}

}
