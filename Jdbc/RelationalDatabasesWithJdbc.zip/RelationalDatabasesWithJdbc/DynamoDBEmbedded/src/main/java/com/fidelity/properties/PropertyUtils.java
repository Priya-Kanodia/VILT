package com.fidelity.properties;

import java.io.IOException;
import java.util.Properties;

public class PropertyUtils {
	private static final Class<?> CLAZZ = PropertyUtils.class;
	private static final String DEFAULT_PORT = "8000";
	private static Properties properties = new Properties();
	
	private PropertyUtils() {
		// prevent construction
	}

	static {
		try {
			properties.load(CLAZZ.getClassLoader().getResourceAsStream("dyn.properties"));
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

	public static String getPort() {
		String url = properties.getProperty("dyn.url");
		String port = url.substring(url.lastIndexOf(':') + 1);
		if (port.matches("[0-9]+")) {
			return port;
		}
		return DEFAULT_PORT;
	}

	public static boolean getEmbedded() {
		String embedded = properties.getProperty("dyn.embedded");
		if ("true".equalsIgnoreCase(embedded)) {
			return true;
		}
		return false;
	}

	public static String getUrl() {
		return properties.getProperty("dyn.url");
	}

	public static String getRegion() {
		return properties.getProperty("dyn.region");
	}
}
