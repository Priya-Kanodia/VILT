package com.fidelity.model;

import java.util.List;

public class Music {
	private String artist;
	private String trackTitle;
	private String albumTitle;
	private Integer year;
	private Integer lengthInSeconds;
	private List<String> genres;
	private Boolean	available;
	
	// Eclipse generated from here
	public Music() {
		super();
	}
	
	public Music(String artist, String trackTitle, String albumTitle, Integer year, Integer lengthInSeconds,
			List<String> genres, Boolean available) {
		super();
		this.artist = artist;
		this.trackTitle = trackTitle;
		this.albumTitle = albumTitle;
		this.year = year;
		this.lengthInSeconds = lengthInSeconds;
		this.genres = genres;
		this.available = available;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getTrackTitle() {
		return trackTitle;
	}

	public void setTrackTitle(String trackTitle) {
		this.trackTitle = trackTitle;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getLengthInSeconds() {
		return lengthInSeconds;
	}

	public void setLengthInSeconds(Integer lengthInSeconds) {
		this.lengthInSeconds = lengthInSeconds;
	}

	public List<String> getGenres() {
		return genres;
	}

	public void setGenres(List<String> genres) {
		this.genres = genres;
	}

	public Boolean getAvailable() {
		return available;
	}

	public void setAvailable(Boolean available) {
		this.available = available;
	}

	@Override
	public String toString() {
		return "Music [artist=" + artist + ", trackTitle=" + trackTitle + ", albumTitle=" + albumTitle + ", year=" + year
				+ ", lengthInSeconds=" + lengthInSeconds + ", genres=" + genres + ", available=" + available + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((albumTitle == null) ? 0 : albumTitle.hashCode());
		result = prime * result + ((artist == null) ? 0 : artist.hashCode());
		result = prime * result + ((available == null) ? 0 : available.hashCode());
		result = prime * result + ((genres == null) ? 0 : genres.hashCode());
		result = prime * result + ((lengthInSeconds == null) ? 0 : lengthInSeconds.hashCode());
		result = prime * result + ((trackTitle == null) ? 0 : trackTitle.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Music other = (Music) obj;
		if (albumTitle == null) {
			if (other.albumTitle != null)
				return false;
		} else if (!albumTitle.equals(other.albumTitle))
			return false;
		if (artist == null) {
			if (other.artist != null)
				return false;
		} else if (!artist.equals(other.artist))
			return false;
		if (available == null) {
			if (other.available != null)
				return false;
		} else if (!available.equals(other.available))
			return false;
		if (genres == null) {
			if (other.genres != null)
				return false;
		} else if (!genres.equals(other.genres))
			return false;
		if (lengthInSeconds == null) {
			if (other.lengthInSeconds != null)
				return false;
		} else if (!lengthInSeconds.equals(other.lengthInSeconds))
			return false;
		if (trackTitle == null) {
			if (other.trackTitle != null)
				return false;
		} else if (!trackTitle.equals(other.trackTitle))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}

}
