package com.fidelity.dynamodb;

import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fidelity.model.Music;

public class JsonTestUtils {

	List<Music> loadData(String fileName) throws Exception {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(this.getClass().getClassLoader().getResource(fileName), 
				new TypeReference<List<Music>>() {});
	}
}
