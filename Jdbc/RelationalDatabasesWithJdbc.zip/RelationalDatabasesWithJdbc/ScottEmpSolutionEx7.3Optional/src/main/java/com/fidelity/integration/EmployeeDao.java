package com.fidelity.integration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.Employee;

public class EmployeeDao {
    private final Logger logger = LoggerFactory.getLogger(EmployeeDao.class);
	
	private Connection conn;

	public Connection getConnection() throws SQLException {

		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				/*
				 * Why throw SQLException, but catch IOException?
				 * 
				 * Because all the exception handling is a compromise at this point. There is a much better solution
				 * that we will discover later. So many JDBC methods throw SQLException that we will need handling 
				 * for that in every other method of the DAO, whereas only this method throws IOException.
				 */
				logger.error("Cannot read db.properties", e);
			}
		}
		return conn;
	}

	// 7.2 #1
	public List<Employee> queryAllEmployees() {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp";
		List<Employee> emps = new ArrayList<>();
		// Declare these outside the try-catch-finally block so they are available in finally
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			/*
			 * This logs the error, but effectively ignores it. Better solution coming soon.
			 * 
			 * Try changing the query string so that it generates an SQL error and see what happens. The test will 
			 * fail, but not with an exception because the exception doesn't get that far. However, it *will* be 
			 * logged to the console.
			 */
			logger.error("Cannot execute queryAllEmployees: {}", sql, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close statement", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close connection", e);
				}
			}
		}
		return emps;
	}

	// Optional 7.3 #2
	private List<Employee> getAndHandleResults(PreparedStatement stmt) throws SQLException {
		List<Employee> emps = new ArrayList<>();
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int empNumber = rs.getInt("empno");
			String empName = rs.getString("ename");
			String job = rs.getString("job");
			int mgrNumber = rs.getInt("mgr");
			String hireDate = rs.getString("hiredate");
			double sal = rs.getDouble("sal");
			double comm = rs.getDouble("comm");
			int deptNumber = rs.getInt("deptno");
			Employee emp = new Employee(empNumber, empName, job, mgrNumber, hireDate, sal, comm, deptNumber);
			emps.add(emp);
		}
		return emps;
	}

	// 7.2 #2
	// 7.3 #1
	public List<Employee> queryEmployeesByName(String name) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE ename = ?";
		List<Employee> emps = new ArrayList<>();
		PreparedStatement stmt = null;
		Connection conn = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, name);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// This logs the error, but effectively ignores it. Better solution coming soon.
			logger.error("Cannot execute queryEmployeesByName: {} for {}", sql, name, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close statement", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close connection", e);
				}
			}
		}
		return emps;
	}

	// Optional 7.2 #3
	// Optional 7.3 #3
	public Employee queryEmployeeByNumber(int empNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE empno = ?";
		List<Employee> emps = new ArrayList<>();
		PreparedStatement stmt = null;
		Connection conn = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, empNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// This logs the error, but effectively ignores it. Better solution coming soon.
			logger.error("Cannot execute queryEmployeeByNumber: {} for {}", sql, empNo, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close statement", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close connection", e);
				}
			}
		}
		/*
		 * This method only returns one Employee, but the generic query handler (getAndHandleResults) returns a list.
		 * 
		 * Return the first item in the list, if there is one. Doing it this way avoids an index out of bounds exception.
		 */
		return emps.size() > 0 ? emps.get(0) : null;
	}

	// Optional 7.2 #4
	// Optional 7.3 #4
	public List<Employee> queryEmployeesByDepartment(int deptNo) {
		String sql = "SELECT empno, ename, job, mgr, TO_CHAR(hiredate, 'DD-MON-YYYY') AS hiredate, sal, comm, deptno FROM emp "
				+ "WHERE deptno = ?";
		List<Employee> emps = new ArrayList<>();
		PreparedStatement stmt = null;
		Connection conn = null;
		try {
			conn = getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, deptNo);
			emps = getAndHandleResults(stmt);
		} catch (SQLException e) {
			// This logs the error, but effectively ignores it. Better solution coming soon.
			logger.error("Cannot execute queryEmployeesByDepartment: {} for {}", sql, deptNo, e);
		} finally {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close statement", e);
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// This logs the error, but effectively ignores it. Better solution coming soon.
					logger.error("Cannot close connection", e);
				}
			}
		}
		return emps;
	}



}
