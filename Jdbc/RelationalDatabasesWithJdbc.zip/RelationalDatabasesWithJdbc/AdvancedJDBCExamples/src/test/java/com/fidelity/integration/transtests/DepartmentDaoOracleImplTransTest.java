package com.fidelity.integration.transtests;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Savepoint;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Department;

class DepartmentDaoOracleImplTransTest {

	private DepartmentDao dao;
	private Savepoint sp;

	private Department dept10;
	private Department dept30;
	private Department dept40;
	private Department new10;
	
	@BeforeEach
	void setUp() {
		dao = new DepartmentDaoOracleImpl();
		// Savepoint version is safer
//		dao.beginTransaction();
		sp = dao.beginSavepointTransaction("test");
		dept10 = new Department(10, "ACCOUNTING", "NEW YORK");
		dept30 = new Department(30, "SALES", "CHICAGO");
		dept40 = new Department(40, "OPERATIONS", "BOSTON");
		new10 = new Department(10, "NEW ACCOUNTING", "NEW YORK");
	}
	
	@AfterEach
	void tearDown() {
		// Savepoint version is safer
//		dao.rollbackTransaction();
		dao.rollbackSavepointTransaction(sp);
		dao.close();
	}
	
	@Test
	void testQueryAllDepartments() {
		List<Department> depts = dao.queryAllDepartments();
		assertEquals(4, depts.size(), "Should be 4 departments");
		assertTrue(depts.contains(dept10), "Should contain ACCOUNTING");
		assertTrue(depts.contains(dept40), "Should contain OPERATIONS");
	}
	
	@Test
	void testInsert() {
		Department dept90 = new Department(90, "NEW RESEARCH", "CARY");
		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(dept90), "Should not contain new dept before insert");
		assertEquals(4, depts.size(),"Should be 4 records before insert");
		dao.addNewDepartment(dept90);
		depts = dao.queryAllDepartments();
		assertTrue(depts.contains(dept90), "Should contain new dept after insert");
		assertEquals(5, depts.size(), "Should be 5 records after insert");
	}

	// Previously, this was bundled with the insert test, now needs to be separate
	@Test
	void testDelete() {
		int size = dao.queryAllDepartments().size();

		// already have tests that check dept 40 exists before delete

		dao.deleteDepartment(40);
		List<Department> depts = dao.queryAllDepartments();
		assertFalse(depts.contains(dept40), "Dept 40 should not exist after delete");
		assertEquals(size - 1, depts.size(), "Should only have deleted 1 dept");
	}

	@Test
	void testUpdate() {
		// already have tests that check data before the update

		dao.updateDepartment(new10);
		List<Department> depts = dao.queryAllDepartments();
		assertTrue(depts.contains(new10), "dept 10 after update");
		assertTrue(depts.contains(dept30), "dept 30 unchanged");
		assertEquals(4, depts.size(), "Should be 4 records after update");
	}

}
