DROP TABLE emp_perf;

-- In a "real" situation, we would store perf_code or perf_name, but not both
-- (this is just to illustrate the two ways of doing it)
CREATE TABLE emp_perf
(
    empno     NUMBER(4,0) PRIMARY KEY NOT NULL,
    perf_code NUMBER(1,0) NOT NULL,
    perf_name VARCHAR2(7) NOT NULL
);

INSERT INTO emp_perf VALUES (7369, 1, 'ABOVE');
INSERT INTO emp_perf VALUES (7499, 3, 'BELOW');
INSERT INTO emp_perf VALUES (7521, 2, 'AVERAGE');
INSERT INTO emp_perf VALUES (7566, 2, 'AVERAGE');
INSERT INTO emp_perf VALUES (7654, 2, 'AVERAGE');
INSERT INTO emp_perf VALUES (7698, 2, 'AVERAGE');

COMMIT;
