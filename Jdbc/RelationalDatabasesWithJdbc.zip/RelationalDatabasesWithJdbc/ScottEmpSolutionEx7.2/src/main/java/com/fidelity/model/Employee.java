package com.fidelity.model;

public class Employee {
	private int empNumber;
	private String empName;
	private String job;
	private int mgrNumber;
	private String hireDate;
	private double salary;
	private double comm;
	private int deptNumber;
	
	public Employee(int empNumber, String empName, String job, int mgrNumber, String hireDate, double salary,
			double comm, int deptNumber) {
		super();
		this.empNumber = empNumber;
		this.empName = empName;
		this.job = job;
		this.mgrNumber = mgrNumber;
		this.hireDate = hireDate;
		this.salary = salary;
		this.comm = comm;
		this.deptNumber = deptNumber;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(comm);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + deptNumber;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + empNumber;
		result = prime * result + ((hireDate == null) ? 0 : hireDate.hashCode());
		result = prime * result + ((job == null) ? 0 : job.hashCode());
		result = prime * result + mgrNumber;
		temp = Double.doubleToLongBits(salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (Double.doubleToLongBits(comm) != Double.doubleToLongBits(other.comm))
			return false;
		if (deptNumber != other.deptNumber)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (empNumber != other.empNumber)
			return false;
		if (hireDate == null) {
			if (other.hireDate != null)
				return false;
		} else if (!hireDate.equals(other.hireDate))
			return false;
		if (job == null) {
			if (other.job != null)
				return false;
		} else if (!job.equals(other.job))
			return false;
		if (mgrNumber != other.mgrNumber)
			return false;
		if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Employee [empNumber=" + empNumber + ", empName=" + empName + ", job=" + job + ", mgrNumber=" + mgrNumber
				+ ", hireDate=" + hireDate + ", salary=" + salary + ", comm=" + comm + ", deptNumber=" + deptNumber
				+ "]";
	}
	
}
