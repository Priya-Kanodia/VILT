package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.bson.Document;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.domain.Product;

class ProductMongoDaoTest {

	private ProductMongoDao dao;

	@BeforeEach
	void setUp() {
		dao = new ProductMongoDao();
	}

	@AfterEach
	void tearDown() {
		dao.close();
	}

	@Test
	void testGetCollection() {
		List<Document> products = dao.getAllProductsAsDocument();
		for (Document document : products) {
			// Just to show what a Mongo Document looks like
			System.out.println(document);
			assertNotNull(document);
		}
	}

	@Test
	void testInsertCollection() {
		List<Document> products = dao.getAllProductsAsDocument();
		int expected = products.size() + 1;

		Document newProduct = new Document("item", "TV")
				.append("manufacturer", "Sony")
				.append("price", 599.98);
		dao.insertProductAsDocument(newProduct);

		products = dao.getAllProductsAsDocument();
		assertEquals(expected, products.size());
	}

	@Test
	void testGetCollectionTyped() {
		List<Product> products = dao.getAllProductsAsProduct();
		for (Product product : products) {
			// Might as well print the Product for comparison
			System.out.println(product);
			assertNotNull(product);
		}
	}

	@Test
	void testInsertCollectionTyped() {
		List<Product> products = dao.getAllProductsAsProduct();
		int expected = products.size() + 1;

		Product newProduct = new Product("TV", "Sony", 599.98);
		dao.insertProductAsProduct(newProduct);

		products = dao.getAllProductsAsProduct();
		assertEquals(expected, products.size());
	}
}
