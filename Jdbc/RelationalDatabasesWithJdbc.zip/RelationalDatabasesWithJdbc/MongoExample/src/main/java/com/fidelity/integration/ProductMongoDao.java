package com.fidelity.integration;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

import com.fidelity.domain.Product;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class ProductMongoDao {

	private MongoClientOptions options;
	private final String host = "localhost";
	private MongoClient mongoClient;

	public ProductMongoDao() {
		CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(
				MongoClient.getDefaultCodecRegistry(),
				CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));
		options = MongoClientOptions.builder()
				.codecRegistry(pojoCodecRegistry)
				.build();
	}

	private MongoDatabase getDatabase() {
		if (mongoClient == null) {
			mongoClient = new MongoClient(host, options);
		}
		return mongoClient.getDatabase("productdb");
	}

	public void close() {
		mongoClient.close();
	}

	/*
	 * The tests are repeatable because they insert every time and don't worry
	 * about the exact contents, but just in case, here is a method that resets
	 * the data to the state after the exercise.
	 */
	public void resetData() {
		MongoDatabase db = getDatabase();
		MongoCollection<Document> products = db.getCollection("products");

		products.drop();
		
		db.createCollection("products");
		products = db.getCollection("products");

		Product newProduct = new Product("TV", "Sony", 199.99);
		insertProductAsProduct(newProduct);
		newProduct = new Product("TV", "Samsung", 259.99);
		insertProductAsProduct(newProduct);
		newProduct = new Product("Blu-Ray", "Toshiba", 89.99);
		insertProductAsProduct(newProduct);
	}
	
	public List<Document> getAllProductsAsDocument() {
		List<Document> results = new ArrayList<>();

		MongoDatabase db = getDatabase();
		MongoCollection<Document> products = db.getCollection("products");

		FindIterable<Document> iter = products.find();
		for (Document product : iter) {
			results.add(product);
		}
		return results;
	}
	
	public void insertProductAsDocument(Document newProduct) {
		MongoDatabase db = getDatabase();
		MongoCollection<Document> products = db.getCollection("products");

		products.insertOne(newProduct);
	}

	public List<Product> getAllProductsAsProduct() {
		List<Product> results = new ArrayList<>();

		MongoDatabase db = getDatabase();
		MongoCollection<Product> products = db.getCollection("products", Product.class);

		FindIterable<Product> iter = products.find();
		for (Product product : iter) {
			results.add(product);
		}
		return results;
	}

	public void insertProductAsProduct(Product newProduct) {
		MongoDatabase db = getDatabase();
		MongoCollection<Product> products = db.getCollection("products", Product.class);

		products.insertOne(newProduct);
	}
	

}
