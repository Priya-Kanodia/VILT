package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Employee;

class EmployeeDaoMockImplTest {
	EmployeeDao dao;
	
	Employee emp7369;
	Employee emp7934;
	
	@BeforeEach
	void setUp() {
		dao = new EmployeeDaoMockImpl();
		
		// Note format of date depends on query and/or database parameters
		// NULL commission is mapped to 0
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, "17-DEC-1980", 800.0, 0.0, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, "23-JAN-1982", 1300.0, 0.0, 10);
	}

	@AfterEach
	void tearDown() {
		dao.close();
	}

	// 8.2 #4 Changed from expecting 14 employees to expecting 2, still a representative test
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = dao.queryAllEmployees();
		assertEquals(2, emps.size(), "Should be 2 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}
	
	@Test
	void testQueryEmployeeByName() {
		List<Employee> emps = dao.queryEmployeesByName("SMITH");
		assertEquals(1, emps.size(), "Should be 1 record");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
	}

	@Test
	void testQueryEmployeeByNameFail() {
		List<Employee> emps = dao.queryEmployeesByName("PANKHURST");
		assertEquals(0, emps.size(), "Should be 0 records");
	}
	
	@Test
	void testQueryEmployeesByNameInjection() {
		List<Employee> emps = dao.queryEmployeesByName("SMITH' OR '1' = '1");
		assertEquals(0, emps.size(), "Should be 0 records");
	}

	@Test
	void testQueryEmployeeByNumber7369() {
		Employee emp = dao.queryEmployeeByNumber(7369);
		assertEquals(emp7369, emp);
	}
	
	@Test
	void testQueryEmployeeByNumber8000() {
		Employee emp = dao.queryEmployeeByNumber(8000);
		assertNull(emp);
	}
	
	// 8.2 #4 Changed from expecting 3 employees to expecting 1, still a representative test
	@Test
	void testQueryEmployeesByDept10() {
		List<Employee> emps = dao.queryEmployeesByDepartment(10);
		assertEquals(1, emps.size(), "Should be 1 records");
		assertFalse(emps.contains(emp7369), "Should not contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}
	
	// 8.2 #4 Changed from expecting 5 employees to expecting 1, still a representative test
	@Test
	void testQueryEmployeesByDept20() {
		List<Employee> emps = dao.queryEmployeesByDepartment(20);
		assertEquals(1, emps.size(), "Should be 1 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertFalse(emps.contains(emp7934), "Should not contain MILLER 7934");
	}

	@Test
	void testQueryEmployeesByDept90() {
		List<Employee> emps = dao.queryEmployeesByDepartment(90);
		assertEquals(0, emps.size(), "Should be 0 records");
	}

}
