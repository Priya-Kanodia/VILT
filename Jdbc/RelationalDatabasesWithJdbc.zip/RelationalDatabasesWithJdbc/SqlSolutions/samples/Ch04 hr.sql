
-- INNER JOINs

SELECT locations.location_id
     , locations.city     
     , departments.department_id
     , departments.department_name
FROM   departments
JOIN   locations
ON     departments.location_id = locations.location_id; 

SELECT employees.employee_id
     , employees.first_name
     , employees.last_name
     , employees.job_id
     , jobs.job_title
FROM   employees
JOIN   jobs
ON     employees.job_id = jobs.job_id;

SELECT last_name FROM employees;

SELECT employees.last_name FROM employees;

SELECT e.last_name FROM employees e;

SELECT employees.last_name FROM employees e;

SELECT e.employee_id
     , e.first_name
     , e.last_name
     , e.job_id
     , j.job_title
FROM   employees e
JOIN   jobs j
ON     e.job_id = j.job_id;

SELECT e.employee_id
     , e.first_name
     , e.last_name
     , e.job_id
     , j.job_title
FROM   employees e
JOIN   jobs j
ON     e.job_id = j.job_id
WHERE  e.job_id = 'FI_ACCOUNT';

-- on the slide
SELECT e.employee_id
     , e.first_name
     , e.last_name
     , e.job_id
     , j.job_title
FROM   employees e
JOIN   jobs j
ON     e.job_id = j.job_id
WHERE  e.job_id = 'FI_ACCOUNT'
ORDER BY 
       job_title, employee_id;

-- better
SELECT e.employee_id
     , e.first_name
     , e.last_name
     , e.job_id
     , j.job_title
FROM   employees e
JOIN   jobs j
ON     e.job_id = j.job_id
WHERE  e.job_id = 'FI_ACCOUNT'
ORDER BY 
       j.job_title, e.employee_id;

SELECT e.employee_id
     , e.first_name
     , e.last_name
     , e.job_id
     , j.job_title
     , d.department_name
FROM   employees e
JOIN   jobs j
ON     e.job_id = j.job_id
JOIN   departments d
ON     e.department_id = d.department_id
ORDER BY 
       j.job_title, e.employee_id;

SELECT e.first_name, e.last_name, e.salary, j.job_title, j.max_salary
FROM   employees e
JOIN   jobs j
ON     e.salary BETWEEN j.min_salary AND j.max_salary
AND    e.job_id != j.job_id
WHERE  e.employee_id = 103;


-- OUTER JOINs

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
INNER JOIN 
       departments d
ON     e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
FULL OUTER JOIN 
       departments d
ON     e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
LEFT OUTER JOIN
       departments d
ON     e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
RIGHT OUTER JOIN 
       departments d
ON     e.department_id = d.department_id;


SELECT e.first_name, e.last_name, d.department_name
FROM   departments d
LEFT OUTER JOIN 
       employees e 
ON     e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
RIGHT OUTER JOIN 
       departments d
ON     e.department_id = d.department_id;


SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
LEFT OUTER JOIN 
       departments d
ON     e.department_id = d.department_id
WHERE  d.department_name LIKE 'P%';

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
LEFT OUTER JOIN
       departments d
ON     e.department_id = d.department_id
AND    d.department_name LIKE 'P%';


-- Self JOIN

SELECT e.employee_id, e.last_name, e.manager_id, m.last_name AS manager
FROM   employees e 
LEFT OUTER JOIN 
       employees m
ON     e.manager_id = m.employee_id
ORDER BY 
       e.employee_id;


-- SQL-89 & Cartesian JOIN

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e 
INNER JOIN 
       departments d
ON     e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e, departments d
WHERE  e.department_id = d.department_id;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e, departments d;

SELECT first_name, last_name 
FROM   employees;

SELECT department_name 
FROM   departments;

SELECT e.first_name, e.last_name, d.department_name
FROM   employees e
CROSS JOIN 
       departments d;
