
-- Create and Drop Tables

CREATE TABLE clients (
    client_id         NUMBER(5) NOT NULL
  , client_name       VARCHAR2(20)
  , client_type       NUMBER(2) DEFAULT 01
  , client_start_date DATE
);

CREATE TABLE new_jobs 
AS
SELECT * 
FROM   jobs;

SELECT * 
FROM new_jobs;

-- Will need to drop the table if you ran the earlier code
CREATE TABLE new_jobs 
AS 
SELECT * 
FROM   jobs
WHERE  1 = 2;

SELECT * 
FROM new_jobs;

-- Will need to drop the table if you ran the earlier code
CREATE TABLE new_jobs (title, job_number) 
AS
SELECT job_title, job_id 
FROM jobs;

SELECT * 
FROM   new_jobs;

-- Will need to drop the table if you ran the earlier code
CREATE TABLE new_jobs (title, job_number) 
AS 
SELECT job_title, job_id 
FROM   jobs
WHERE  job_id LIKE 'IT%';

SELECT * 
FROM   new_jobs;

CREATE TABLE jobs_employees 
AS 
SELECT j.job_title, e.last_name 
FROM   jobs j 
JOIN   employees e 
USING  (job_id)
WHERE  job_id LIKE 'IT%';

SELECT * FROM jobs_employees;


-- Don't execute this!
RENAME jobs TO regional_jobs;


TRUNCATE TABLE new_jobs;

DROP TABLE new_jobs;

FLASHBACK TABLE new_jobs TO BEFORE DROP;

FLASHBACK TABLE new_jobs TO BEFORE DROP RENAME TO some_jobs;

DROP TABLE new_jobs PURGE;

SELECT original_name, object_name, type, droptime, can_undrop FROM user_recyclebin;

PURGE TABLE new_jobs;

PURGE DBA_RECYCLEBIN;


-- Alter Table

ALTER TABLE new_jobs
ADD (effective_date DATE);

DESCRIBE new_jobs

ALTER TABLE new_jobs 
MODIFY (max_salary  NUMBER(8));

DESCRIBE new_jobs

-- Should fail because too small
ALTER TABLE new_jobs 
MODIFY (job_title VARCHAR2(4));

-- Should fail, cannot change data type when not empty
ALTER TABLE new_jobs 
MODIFY (job_id  NUMBER(6));

ALTER TABLE new_jobs 
DROP (min_salary, max_salary) CASCADE CONSTRAINTS;

DESCRIBE new_jobs

ALTER TABLE new_jobs 
SET UNUSED (effective_date) CASCADE CONSTRAINTS;
	
DESCRIBE new_jobs

ALTER TABLE new_jobs 
DROP UNUSED COLUMNS;

ALTER TABLE new_jobs
RENAME COLUMN job_title TO title;

DESCRIBE new_jobs


-- Sequence

-- Some examples here are in the scott schema

-- This could be in scott or hr, but is more "hr-like"
CREATE TABLE clients (
    client_id         NUMBER GENERATED ALWAYS AS IDENTITY
  , client_name       VARCHAR2(20)
  , client_type       NUMBER(2) DEFAULT 01
  , client_start_date DATE
);


-- Constraints

-- Examples are in scott schema


-- Views

CREATE OR REPLACE VIEW vw_jobs (max_sal, min_sal, title) 
AS
SELECT max_salary, min_salary, job_title
FROM jobs 
WHERE max_salary < 8000
WITH CHECK OPTION CONSTRAINT ck_restrict_jobs;

SELECT * FROM vw_jobs;

UPDATE vw_jobs
SET max_sal = 7500
WHERE title = 'Administration Assistant';

-- Will fail because of CHECK OPTION
UPDATE vw_jobs
SET max_sal = 8500
WHERE title = 'Administration Assistant';

SELECT table_name, column_name, updatable 
FROM   user_updatable_columns 
WHERE  table_name = 'VW_JOBS';


-- Indexes

-- Most examples are in scott schema

CREATE INDEX emp_fname_uppercase_ix 
ON employees (UPPER(first_name)); 

