
CREATE OR REPLACE PACKAGE pack_employee IS
    PROCEDURE prep_emps;
END pack_employee;
/

CREATE OR REPLACE PACKAGE BODY pack_employee IS
    TYPE emp_strong_t IS REF CURSOR RETURN employees%ROWTYPE;
    TYPE emp_weak_t IS REF CURSOR;

    FUNCTION count_emp(
        like_value IN VARCHAR2,
        emps_cur   IN SYS_REFCURSOR
    ) RETURN PLS_INTEGER
    IS
        found PLS_INTEGER := 0;
        emp employees%ROWTYPE;
    BEGIN
        LOOP
            FETCH emps_cur INTO emp;
            EXIT WHEN emps_cur%NOTFOUND;
            IF emp.last_name LIKE like_value THEN
                DBMS_OUTPUT.PUT_LINE(emp.first_name || ' ' || emp.last_name);
                found := found + 1;
            END IF;
        END LOOP;
        CLOSE emps_cur;
        RETURN found;
    END count_emp;
    
    PROCEDURE prep_emps
    IS
        emps_cur SYS_REFCURSOR;
        emps_count PLS_INTEGER := 0;
    BEGIN
        OPEN emps_cur FOR
        SELECT *
        FROM   employees;
        
        emps_count := count_emp('S%', emps_cur);
        DBMS_OUTPUT.PUT_LINE('Found ' || emps_count || ' records');
    END prep_emps;
END pack_employee;
/

BEGIN
    pack_employee.prep_emps;
END;
/