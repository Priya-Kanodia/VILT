
SELECT ename, sal, comm, sal + comm "Total Compensation"
FROM   emp;

SELECT ename, sal, comm, sal + NVL(comm, 0) "Total Compensation"
FROM   emp;
