REM INSERTING into CLIENTS
SET DEFINE OFF;
INSERT INTO clients (client_id, client_name, client_address, client_type, client_indu, client_start_date)
VALUES (1, NULL, NULL, 1, NULL, NULL);

REM INSERTING into STAFF
SET DEFINE OFF;
-- Nothing to see here!
