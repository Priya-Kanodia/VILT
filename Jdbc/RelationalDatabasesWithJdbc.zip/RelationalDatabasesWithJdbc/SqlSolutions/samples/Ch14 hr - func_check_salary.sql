
-- Used with proc_update_salary

CREATE OR REPLACE FUNCTION func_check_salary(
    job_id IN jobs.job_id%TYPE,
    salary IN jobs.min_salary%TYPE
)
RETURN BOOLEAN
IS
    job_count NUMBER(5);
BEGIN
    IF job_id IS NULL OR salary IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'parameters may not be null');
    END IF;

    SELECT COUNT(*)
    INTO   job_count
    FROM   jobs j
    WHERE  j.job_id = func_check_salary.job_id
    AND    func_check_salary.salary BETWEEN min_salary AND max_salary;
    
    IF job_count <> 1 THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END func_check_salary;
/
