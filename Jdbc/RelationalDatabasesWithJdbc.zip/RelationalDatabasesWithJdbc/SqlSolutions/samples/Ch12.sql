DROP TABLE ACTORS;
DROP TABLE OSCAR_WINNERS;

--------------------------------------------------------
--  DDL for Table ACTORS
--------------------------------------------------------
CREATE TABLE ACTORS ( 
    FIRST_NAME VARCHAR2(20), 
	LAST_NAME  VARCHAR2(20)
);
--------------------------------------------------------
--  DDL for Table OSCAR_WINNERS
--------------------------------------------------------
CREATE TABLE OSCAR_WINNERS (
    FIRST_NAME VARCHAR2(20), 
	LAST_NAME  VARCHAR2(20)
) ;

REM INSERTING into ACTORS
SET DEFINE OFF;
INSERT INTO ACTORS (FIRST_NAME, LAST_NAME) VALUES ('Priyanka', 'Chopra');
INSERT INTO ACTORS (FIRST_NAME, LAST_NAME) VALUES ('Johnny', 'Depp');
INSERT INTO ACTORS (FIRST_NAME, LAST_NAME) VALUES ('Tom', 'Hanks');
INSERT INTO ACTORS (FIRST_NAME, LAST_NAME) VALUES ('Peter', 'O''Toole');
INSERT INTO ACTORS (FIRST_NAME, LAST_NAME) VALUES ('Jing', 'Tian');

REM INSERTING into OSCAR_WINNERS
SET DEFINE OFF;
INSERT INTO OSCAR_WINNERS (FIRST_NAME, LAST_NAME) VALUES ('Tom', 'Hanks');
INSERT INTO OSCAR_WINNERS (FIRST_NAME, LAST_NAME) VALUES ('Neil', 'Jordan');
INSERT INTO OSCAR_WINNERS (FIRST_NAME, LAST_NAME) VALUES ('Ang', 'Lee');
INSERT INTO OSCAR_WINNERS (FIRST_NAME, LAST_NAME) VALUES ('Peter', 'O''Toole');

COMMIT;

SELECT first_name, last_name 
FROM   actors
UNION
SELECT first_name, last_name 
FROM   oscar_winners
ORDER BY 
       last_name, first_name;

SELECT first_name, last_name 
FROM   actors
UNION ALL
SELECT first_name, last_name 
FROM   oscar_winners
ORDER BY 
       last_name DESC, first_name;

SELECT first_name, last_name 
FROM   actors
INTERSECT
SELECT first_name, last_name 
FROM   oscar_winners
ORDER BY
       first_name;

SELECT first_name, last_name 
FROM   actors
MINUS
SELECT first_name, last_name 
FROM   oscar_winners
ORDER BY 
       last_name;
