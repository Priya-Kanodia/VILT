
-- Working with PL/SQL
CREATE TABLE waiting_list
AS
SELECT employee_id, job_id
FROM employees
WHERE 1 = 0;

DECLARE
    no_of_employees          NUMBER(2); 
    max_employees   CONSTANT NUMBER(2) := 5;
BEGIN
    SELECT COUNT(*) 
    INTO no_of_employees 
    FROM employees
    WHERE job_id = 'IT_PROG';

    IF no_of_employees < max_employees THEN
        UPDATE employees
        SET job_id = 'IT_PROG'
        WHERE employee_id = 171;
    ELSE
        INSERT INTO waiting_list (
            employee_id, 
            job_id
        )
        VALUES (171, 'IT_PROG');
    END IF;
END;
/ 

SET SERVEROUTPUT ON

DECLARE
    l_country_id   countries.country_id%TYPE;
    l_country_name countries.country_name%TYPE;
    l_region_id    countries.region_id%TYPE;
BEGIN
    SELECT country_id, country_name, region_id
    INTO   l_country_id, l_country_name, l_region_id
    FROM   countries
    WHERE  region_id = 2
    AND    ROWNUM <= 1;
    
    DBMS_OUTPUT.PUT_LINE('country_id: ' || l_country_id || ' country_name: ' 
        || l_country_name || ' region: ' || l_region_id);
END;
/

DECLARE
    country_rec    countries%ROWTYPE;
BEGIN
    SELECT *
    INTO   country_rec
    FROM   countries
    WHERE  region_id = 2
    AND    ROWNUM <= 1;
    
    DBMS_OUTPUT.PUT_LINE('country_id: ' || country_rec.country_id || ' country_name: ' 
        || country_rec.country_name || ' region: ' || country_rec.region_id);
    
    country_rec.country_id := 'PE';
    country_rec.country_name := 'PERU';

    INSERT INTO 
           countries
    VALUES country_rec;

    SELECT *
    INTO   country_rec
    FROM   countries
    WHERE  region_id = 2
    AND    country_id = country_rec.country_id
    AND    ROWNUM <= 1;

    DBMS_OUTPUT.PUT_LINE('country_id: ' || country_rec.country_id || ' country_name: ' 
        || country_rec.country_name || ' region: ' || country_rec.region_id);
    
END;
/

-- Unintentionally, Argentina rather than Brazil
DECLARE
    country_id   countries.country_id%TYPE := 'BR'; 
    country_name countries.country_name%TYPE;
    region_id    countries.region_id%TYPE;
BEGIN
    SELECT country_id, country_name, region_id
    INTO   country_id, country_name, region_id
    FROM   countries
    WHERE  region_id = 2
    AND    country_id = country_id
    AND    ROWNUM <= 1;
    
    DBMS_OUTPUT.PUT_LINE('country_id: ' || country_id || ' country_name: ' 
        || country_name || ' region: ' || region_id);
END;
/

<<country_check>>
DECLARE
    country_id   countries.country_id%TYPE := 'BR'; 
    country_name countries.country_name%TYPE;
    region_id    countries.region_id%TYPE;
BEGIN
    SELECT c.country_id, c.country_name, c.region_id
    INTO   country_check.country_id, country_check.country_name, country_check.region_id
    FROM   countries c
    WHERE  c.region_id = 2
    AND    c.country_id = country_check.country_id
    AND    ROWNUM <= 1;
    
    DBMS_OUTPUT.PUT_LINE('country_id: ' || country_check.country_id || ' country_name: ' 
        || country_check.country_name || ' region: ' || country_check.region_id);
END;
/

-- and, by naming convention
DECLARE
    l_country_id   countries.country_id%TYPE;
    l_country_name countries.country_name%TYPE;
    l_region_id    countries.region_id%TYPE;
    p_country_id   countries.country_id%TYPE;
BEGIN
    p_country_id := 'BR'; 
    
    SELECT country_id, country_name, region_id
    INTO   l_country_id, l_country_name, l_region_id
    FROM   countries
    WHERE  region_id = 2
    AND    country_id = p_country_id
    AND    ROWNUM <= 1;
    
    DBMS_OUTPUT.PUT_LINE('country_id: ' || l_country_id || ' country_name: ' 
        || l_country_name || ' region: ' || l_region_id);
END;
/


-- Control Structures

DECLARE
    n_employee_id	employees.employee_id%TYPE := 170;
    n_commission	employees.commission_pct%TYPE;
    n_allowance		NUMBER(4);
BEGIN
    SELECT NVL(commission_pct,0)
    INTO n_commission
    FROM employees
    WHERE employee_id = n_employee_id;

    IF TRUNC(n_commission * 100) = 0 THEN
        n_allowance := 500;
    ELSIF TRUNC(n_commission * 100) = 10 THEN
        n_allowance := 400;
    ELSIF TRUNC(n_commission * 100) = 20 THEN
        n_allowance := 300;
    ELSE
        n_allowance := 200;
    END IF;	

    UPDATE employees
    SET salary = salary + n_allowance
    WHERE employee_id = n_employee_id;
END;
/

DECLARE
    n_employee_id	employees.employee_id%TYPE := 170;
    n_commission	employees.commission_pct%TYPE;
    n_allowance		NUMBER(4);
BEGIN
    SELECT NVL(commission_pct,0)
    INTO n_commission
    FROM employees
    WHERE employee_id = n_employee_id;

    CASE 
        WHEN TRUNC(n_commission * 100) = 0 THEN 
            n_allowance := 500;
        WHEN TRUNC(n_commission * 100) = 10 THEN 
            n_allowance := 400;
        WHEN TRUNC(n_commission * 100) = 20 THEN 
            n_allowance := 300;
        ELSE 
            n_allowance := 200;
    END CASE;

    UPDATE employees
    SET salary = salary + n_allowance
    WHERE employee_id = n_employee_id;
END;
/

DECLARE
    n_employee_id	employees.employee_id%TYPE := 170;
    n_commission	employees.commission_pct%TYPE;
    n_allowance		NUMBER(4);
BEGIN
    SELECT NVL(commission_pct,0)
    INTO n_commission
    FROM employees
    WHERE employee_id = n_employee_id;

    CASE TRUNC(n_commission * 100)
        WHEN 0 THEN 
            n_allowance := 500;
        WHEN 10 THEN 
            n_allowance := 400;
        WHEN 20 THEN 
            n_allowance := 300;
        ELSE 
            n_allowance := 200;
    END CASE;

    UPDATE employees
    SET salary = salary + n_allowance
    WHERE employee_id = n_employee_id;
END;
/

DECLARE
    n_employee_id	employees.employee_id%TYPE := 170;
    n_commission	employees.commission_pct%TYPE;
    n_allowance		NUMBER(4);
BEGIN
    SELECT NVL(commission_pct,0)
    INTO n_commission
    FROM employees
    WHERE employee_id = n_employee_id;

    n_allowance := 
        CASE 
            WHEN TRUNC(n_commission * 100) =  0 THEN 500
            WHEN TRUNC(n_commission * 100) = 10 THEN 400
            WHEN TRUNC(n_commission * 100) = 20 THEN 300
            ELSE 200
        END;

    UPDATE employees
    SET salary = salary + n_allowance
    WHERE employee_id = n_employee_id;
END;
/

DECLARE
    n_employee_id	employees.employee_id%TYPE := 170;
    n_commission	employees.commission_pct%TYPE;
    n_allowance		NUMBER(4);
BEGIN
    SELECT NVL(commission_pct,0)
    INTO n_commission
    FROM employees
    WHERE employee_id = n_employee_id;

    n_allowance := 
        CASE TRUNC(n_commission * 100) 
            WHEN 0  THEN 500
            WHEN 10 THEN 400
            WHEN 20 THEN 300
            ELSE 200
        END;

    UPDATE employees
    SET salary = salary + n_allowance
    WHERE employee_id = n_employee_id;
END;
/

DECLARE
    i NUMBER(3) := 0;
BEGIN
    LOOP
        i := i + 10;
        DBMS_OUTPUT.PUT_LINE(i);
        IF i > 100 THEN
            EXIT;
        END IF;
    END LOOP;
END;
/

DECLARE
    i NUMBER(3) := 0;
BEGIN
    LOOP
        i := i + 10;
        DBMS_OUTPUT.PUT_LINE(i);
        EXIT WHEN i > 100;
    END LOOP;
END;
/

DECLARE
    i NUMBER(3) := 0;
BEGIN
    WHILE i <= 100 LOOP
        i := i + 10;
        DBMS_OUTPUT.PUT_LINE(i);
    END LOOP;
END;
/

BEGIN
    FOR outer_counter IN 1 .. 9 LOOP
        FOR inner_counter IN 1 .. 9 LOOP
            -- INSERT INTO cartesian_product
            -- VALUES (outer_counter, inner_counter);
            DBMS_OUTPUT.PUT_LINE(outer_counter || ' ' || inner_counter);
        END LOOP;
    END LOOP;
END;
/


-- Exceptions

-- This code, from the slide, will actually fail because SMITH does not exist
DECLARE
    n_employee_id employees.employee_id%TYPE;
BEGIN
    SELECT e.employee_id
    INTO   n_employee_id
    FROM   employees e
    WHERE  e.last_name = 'SMITH';

    UPDATE departments
    SET    manager_id = n_employee_id
    WHERE  department_id = 150;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20999, 'Employee does not exist');
    WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20999, 'Multiple employees found');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20999, SQLERRM);
END;
/

-- Smith does exist, but has multiple
DECLARE
    n_employee_id employees.employee_id%TYPE;
BEGIN
    SELECT e.employee_id
    INTO   n_employee_id
    FROM   employees e
    WHERE  e.last_name = 'Smith';

    UPDATE departments
    SET    manager_id = n_employee_id
    WHERE  department_id = 150;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20999, 'Employee does not exist');
    WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20999, 'Multiple employees found');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20999, SQLERRM);
END;
/

-- So, if you want this to work, try Zlotkey!
DECLARE
    n_employee_id employees.employee_id%TYPE;
BEGIN
    SELECT e.employee_id
    INTO   n_employee_id
    FROM   employees e
    WHERE  e.last_name = 'Zlotkey';

    UPDATE departments
    SET    manager_id = n_employee_id
    WHERE  department_id = 150;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20999, 'Employee does not exist');
    WHEN TOO_MANY_ROWS THEN
        RAISE_APPLICATION_ERROR(-20999, 'Multiple employees found');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20999, SQLERRM);
END;
/

-- Just don't do this. Catch a more specific exception, or pre-check the COUNT(*)
<<find_country>>
DECLARE
    country_id   countries.country_id%TYPE := 'XX'; 
    country_name countries.country_name%TYPE;
BEGIN
    SELECT c.country_name
    INTO   find_country.country_name
    FROM   countries c
    WHERE  c.country_id = find_country.country_id;

    DBMS_OUTPUT.PUT_LINE('Country found with name ' || find_country.country_name);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Country not found');
END;
/


-- Cursors

-- There actually aren't any 212 area codes in the data, so these use 515

DECLARE
    CURSOR e_cur
    IS
        SELECT employee_id, phone_number
        FROM   employees;
    e_rec  e_cur%ROWTYPE;
BEGIN
    OPEN e_cur;

    LOOP
        FETCH e_cur INTO e_rec;
        EXIT WHEN e_cur%NOTFOUND;

        IF SUBSTR(e_rec.phone_number, 1,3) = '515' THEN
            e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);

            UPDATE employees
            SET phone_number = e_rec.phone_number
            WHERE employee_id = e_rec.employee_id;
        END IF;
    END LOOP;

    CLOSE e_cur;
END;
/

DECLARE 
    CURSOR e_cur_parm(in_area_code VARCHAR2)
    IS
        SELECT employee_id, phone_number
        FROM   employees
        WHERE  SUBSTR(phone_number, 1,3) = in_area_code;

    e_rec e_cur_parm%ROWTYPE;
BEGIN
    OPEN e_cur_parm('515');

    LOOP
        FETCH e_cur_parm INTO e_rec;
        EXIT WHEN e_cur_parm%NOTFOUND;

        e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);

        UPDATE employees
        SET phone_number = e_rec.phone_number
        WHERE employee_id = e_rec.employee_id;
    END LOOP;

    CLOSE e_cur_parm;
END;
/

DECLARE
    CURSOR e_cur_parm(in_area_code VARCHAR2) 
    IS
        SELECT employee_id, phone_number
        FROM   employees
        WHERE  SUBSTR(phone_number, 1, 3) = in_area_code;
BEGIN
    FOR e_rec IN e_cur_parm('515') LOOP
        e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);

        UPDATE employees
        SET phone_number = e_rec.phone_number
        WHERE employee_id = e_rec.employee_id;
    END LOOP;
END;
/

DECLARE
    CURSOR e_cur_parm(in_area_code VARCHAR2) 
    IS
        SELECT ROWID AS e_rowid, phone_number
        FROM   employees
        WHERE  SUBSTR(phone_number, 1, 3) = in_area_code;
BEGIN
    FOR e_rec IN e_cur_parm('515') LOOP
        e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);

        UPDATE employees
        SET phone_number = e_rec.phone_number
        WHERE ROWID = e_rec.e_rowid;
    END LOOP;
END;
/

DECLARE 
    CURSOR e_cur_parm(in_area_code VARCHAR2) 
    IS
        SELECT phone_number
        FROM employees
        WHERE SUBSTR(phone_number, 1, 3) = in_area_code
        FOR UPDATE;
BEGIN
    FOR e_rec IN e_cur_parm('515') LOOP
        e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);

        UPDATE employees
        SET phone_number = e_rec.phone_number
        WHERE CURRENT OF e_cur_parm;
    END LOOP;
END;
/

BEGIN
    FOR e_rec IN (
        SELECT ROWID, phone_number
        FROM   employees
        WHERE  SUBSTR(phone_number, 1, 3) = '515'
    ) LOOP
        e_rec.phone_number := '818' || SUBSTR(e_rec.phone_number, 4);
        
        UPDATE employees
        SET phone_number = e_rec.phone_number
        WHERE ROWID = e_rec.ROWID;
    END LOOP;
END;
/

-- Switched this one round. The one on the slide works if you don't ROLLBACK the previous code
DECLARE
    CURSOR cur(in_area_code VARCHAR2) 
    IS
        SELECT ROWID, phone_number 
        FROM employees 
        WHERE SUBSTR(phone_number, 1, 3) = in_area_code;
    batchsize CONSTANT PLS_INTEGER := 1000;
    TYPE emp_array IS VARRAY(batchsize) OF cur%ROWTYPE;
    emps emp_array;
BEGIN
    OPEN cur(in_area_code => '515');
    LOOP
        FETCH cur BULK COLLECT INTO emps LIMIT batchsize;
        -- The for loop doesn't run when emps.COUNT() = 0
        FOR j IN 1..emps.COUNT() LOOP
            emps(j).phone_number := '818' || SUBSTR(emps(j).phone_number, 4);
        END LOOP;

        FORALL i IN 1..emps.COUNT()
            UPDATE employees e
            SET    e.phone_number = emps(i).phone_number
            WHERE  ROWID  = emps(i).ROWID;

        EXIT WHEN cur%NOTFOUND;
    END LOOP;
    CLOSE cur;
END;
/
