
-- Trigger
CREATE OR REPLACE TRIGGER emp_after_insert
    AFTER INSERT 
    ON employees
    FOR EACH ROW
BEGIN
    IF NOT func_check_salary(job_id => :NEW.job_id,
            salary => :NEW.salary) THEN
        RAISE_APPLICATION_ERROR(-20001, 'Salary out of range for job');
    END IF;
END;
/

-- Drop at end
DROP TRIGGER emp_after_insert;

-- Execute tests
BEGIN
    ut.run('test_insert_trigger');
END;
/

CREATE OR REPLACE PACKAGE test_insert_trigger
IS
    --%suite(Tests for insert trigger on employees)
    
    --%test(Test failing insert)
    --%throws(-20001)
    PROCEDURE salary_out_of_range;

    --%test(Test normal insert)
    PROCEDURE salary_in_range;
END test_insert_trigger;
/

CREATE OR REPLACE PACKAGE BODY test_insert_trigger
IS
    test_emp_id CONSTANT employees.employee_id%TYPE := 999;
    test_job_id CONSTANT employees.job_id%TYPE := 'PU_CLERK';
    
    PROCEDURE perform_insert(
        salary employees.salary%TYPE
    );

    PROCEDURE salary_out_of_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 10000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
        count_after      PLS_INTEGER;
        count_before     PLS_INTEGER;
        salary_after     employees.salary%TYPE;
    BEGIN
        -- INSERT new row (set non NULL columns and salary out of range)
        perform_insert(salary => test_salary);
    END salary_out_of_range;

    FUNCTION get_unchanged(
        employee_id employees.employee_id%TYPE
    )
    RETURN SYS_REFCURSOR;

    PROCEDURE salary_in_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 4000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
        count_after      PLS_INTEGER;
        count_before     PLS_INTEGER;
        salary_after     employees.salary%TYPE;
    BEGIN
        -- Get data before INSERT
        unchanged_before := get_unchanged(
            employee_id => test_emp_id);
        
        SELECT COUNT(*)
        INTO   count_before
        FROM   employees;
        
        -- INSERT new row (set non NULL columns and salary in range)
        perform_insert(salary => test_salary);
        
        -- Get data after INSERT
        unchanged_after := get_unchanged(
            employee_id => test_emp_id);

        SELECT COUNT(*)
        INTO   count_after
        FROM   employees;

        -- Assert
        ut.expect(unchanged_after)
            .to_equal(unchanged_before)
            .join_by('EMPLOYEE_ID');

        ut.expect(count_after).to_equal(count_before + 1);

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        SELECT e.salary
        INTO   salary_after
        FROM   employees e
        WHERE  e.employee_id = test_emp_id;

        ut.expect(salary_after).to_equal(test_salary);

    EXCEPTION
        -- We could let this fail normally, 
        -- but this allows us to customize the message
        WHEN NO_DATA_FOUND THEN
            ut.expect(TRUE, 
                'There was no employee with id ' || test_emp_id)
                    .not_to_equal(TRUE);
    END;

    -- Test utilities from here

    -- Get all employees except the one identified
    FUNCTION get_unchanged(
        employee_id employees.employee_id%TYPE
    )
    RETURN SYS_REFCURSOR
    IS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
        SELECT e.*
        FROM   employees e
        WHERE  e.employee_id != get_unchanged.employee_id
        ORDER BY
               e.employee_id;
        
        RETURN cur;
    END get_unchanged;

    -- INSERT new row (set non NULL columns and salary)
    PROCEDURE perform_insert(
        salary employees.salary%TYPE
    )
    IS
    BEGIN
        INSERT INTO
            employees(
                employee_id,
                last_name,
                email,
                hire_date,
                job_id,
                salary
        )
        VALUES (
                test_emp_id,
                'SAWYER',
                'TSAWYER',
                SYSDATE,
                test_job_id,
                perform_insert.salary
        );
    END;

END test_insert_trigger;
/


-- Bonus from here

-- Trigger
CREATE OR REPLACE TRIGGER emp_after_insert_update
    AFTER INSERT 
    OR UPDATE OF job_id, salary
    ON employees
    FOR EACH ROW
BEGIN
    IF NOT func_check_salary(job_id => :NEW.job_id,
            salary => :NEW.salary) THEN
        IF INSERTING THEN
            RAISE_APPLICATION_ERROR(-20001, 'Salary out of range for job');
        ELSIF UPDATING THEN
            RAISE_APPLICATION_ERROR(-20002, 'Salary out of range for job');
        END IF;
    END IF;
END;
/

-- Drop trigger at end
DROP TRIGGER emp_after_insert_update;

-- Execute tests
BEGIN
    ut.run('test_insert_update_trigger');
END;
/

CREATE OR REPLACE PACKAGE test_insert_update_trigger
IS
    --%suite(Tests for insert trigger on employees)

    --%test(Test failing insert)
    --%throws(-20001)
    PROCEDURE insert_salary_out_of_range;

    --%test(Test normal insert)
    PROCEDURE insert_salary_in_range;

    --%test(Test normal update of salary)
    PROCEDURE update_salary_in_range;

    --%test(Test normal update of job_id)
    PROCEDURE update_job_id_in_range;

    --%test(Test normal update of salary and job_id)
    PROCEDURE update_both_in_range;

    --%test(Test failing update of salary)
    --%throws(-20002)
    PROCEDURE update_salary_out_of_range;

    --%test(Test failing update of job_id)
    --%throws(-20002)
    PROCEDURE update_job_id_out_of_range;

    --%test(Test failing update of salary and job_id)
    --%throws(-20002)
    PROCEDURE update_both_out_of_range;

END test_insert_update_trigger;
/

CREATE OR REPLACE PACKAGE BODY test_insert_update_trigger
IS
    test_new_emp_id CONSTANT employees.employee_id%TYPE := 999;
    test_new_job_id CONSTANT employees.job_id%TYPE := 'PU_CLERK';
    test_upd_emp_id CONSTANT employees.employee_id%TYPE := 107;

    PROCEDURE perform_insert(
        salary employees.salary%TYPE
    );

    PROCEDURE insert_salary_out_of_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 10000;
    BEGIN
        -- INSERT new row (set non NULL columns and salary out of range)
        perform_insert(salary => test_salary);
    END insert_salary_out_of_range;

    FUNCTION get_unchanged(
        employee_id employees.employee_id%TYPE
    )
    RETURN SYS_REFCURSOR;

    PROCEDURE insert_salary_in_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 4000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
        count_after      PLS_INTEGER;
        count_before     PLS_INTEGER;
        salary_after     employees.salary%TYPE;
    BEGIN
        -- Get data before INSERT
        unchanged_before := get_unchanged(
            employee_id => test_new_emp_id);
        
        SELECT COUNT(*)
        INTO   count_before
        FROM   employees;
        
        -- INSERT new row (set non NULL columns and salary in range)
        perform_insert(salary => test_salary);
        
        -- Get data after INSERT
        unchanged_after := get_unchanged(
            employee_id => test_new_emp_id);

        SELECT COUNT(*)
        INTO   count_after
        FROM   employees;

        -- Assert
        ut.expect(unchanged_after)
            .to_equal(unchanged_before)
            .join_by('EMPLOYEE_ID');

        ut.expect(count_after).to_equal(count_before + 1);

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        SELECT e.salary
        INTO   salary_after
        FROM   employees e
        WHERE  e.employee_id = test_new_emp_id;

        ut.expect(salary_after).to_equal(test_salary);

    EXCEPTION
        -- We could let this fail normally, 
        -- but this allows us to customize the message
        WHEN NO_DATA_FOUND THEN
            ut.expect(TRUE, 
                'There was no employee with id ' || test_new_emp_id)
                    .not_to_equal(TRUE);
    END insert_salary_in_range;

    PROCEDURE test_working_update(
        unchanged_before SYS_REFCURSOR,
        count_before     PLS_INTEGER,
        expected_salary  employees.salary%TYPE,
        expected_job_id  employees.job_id%TYPE
    );

    PROCEDURE update_salary_in_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 5000;
        unchanged_before SYS_REFCURSOR;
        count_before     PLS_INTEGER;
        salary_before    employees.salary%TYPE;
        job_id_before    employees.job_id%TYPE;
    BEGIN
        -- Get data before UPDATE
        unchanged_before := get_unchanged(
            employee_id => test_upd_emp_id);

        SELECT COUNT(*)
        INTO   count_before
        FROM   employees;

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        SELECT e.salary, e.job_id
        INTO   salary_before, job_id_before
        FROM   employees e
        WHERE  e.employee_id = test_upd_emp_id;

        -- UPDATE and set salary to valid value
        UPDATE employees
        SET    salary      = test_salary
        WHERE  employee_id = test_upd_emp_id;

        -- All the checks are the same for each test
        test_working_update(
            unchanged_before => unchanged_before,
            count_before     => count_before,
            expected_salary  => test_salary,
            expected_job_id  => job_id_before -- unchanged
        );
    EXCEPTION
        -- We could let this fail normally, 
        -- but this allows us to customize the message
        WHEN NO_DATA_FOUND THEN
            ut.expect(TRUE, 
                'There was no employee with id ' || test_upd_emp_id)
                    .not_to_equal(TRUE);
    END update_salary_in_range;

    PROCEDURE update_job_id_in_range
    IS
        test_job_id CONSTANT employees.job_id%TYPE := 'MK_REP';
        unchanged_before SYS_REFCURSOR;
        count_before     PLS_INTEGER;
        salary_before    employees.salary%TYPE;
        job_id_before    employees.job_id%TYPE;
    BEGIN
        -- Get data before UPDATE
        unchanged_before := get_unchanged(
            employee_id => test_upd_emp_id);

        SELECT COUNT(*)
        INTO   count_before
        FROM   employees;

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        SELECT e.salary, e.job_id
        INTO   salary_before, job_id_before
        FROM   employees e
        WHERE  e.employee_id = test_upd_emp_id;

        -- UPDATE and set salary to valid value
        UPDATE employees
        SET    job_id      = test_job_id
        WHERE  employee_id = test_upd_emp_id;

        -- All the checks are the same for each test
        test_working_update(
            unchanged_before => unchanged_before,
            count_before     => count_before,
            expected_salary  => salary_before,  -- unchanged
            expected_job_id  => test_job_id
        );
    EXCEPTION
        -- We could let this fail normally, 
        -- but this allows us to customize the message
        WHEN NO_DATA_FOUND THEN
            ut.expect(TRUE, 
                'There was no employee with id ' || test_upd_emp_id)
                    .not_to_equal(TRUE);
    END update_job_id_in_range;

    PROCEDURE update_both_in_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 10000;
        test_job_id CONSTANT employees.job_id%TYPE := 'MK_MAN';
        unchanged_before SYS_REFCURSOR;
        count_before     PLS_INTEGER;
        salary_before    employees.salary%TYPE;
        job_id_before    employees.job_id%TYPE;
    BEGIN
        -- Get data before UPDATE
        unchanged_before := get_unchanged(
            employee_id => test_upd_emp_id);

        SELECT COUNT(*)
        INTO   count_before
        FROM   employees;

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        SELECT e.salary, e.job_id
        INTO   salary_before, job_id_before
        FROM   employees e
        WHERE  e.employee_id = test_upd_emp_id;

        -- UPDATE and set salary to valid value
        UPDATE employees
        SET    job_id      = test_job_id,
               salary      = test_salary
        WHERE  employee_id = test_upd_emp_id;

        -- All the checks are the same for each test
        test_working_update(
            unchanged_before => unchanged_before,
            count_before     => count_before,
            expected_salary  => test_salary,
            expected_job_id  => test_job_id
        );
    EXCEPTION
        -- We could let this fail normally, 
        -- but this allows us to customize the message
        WHEN NO_DATA_FOUND THEN
            ut.expect(TRUE, 
                'There was no employee with id ' || test_upd_emp_id)
                    .not_to_equal(TRUE);
    END update_both_in_range;

    PROCEDURE update_salary_out_of_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 12000;
    BEGIN
        UPDATE employees
        SET    salary      = test_salary
        WHERE  employee_id = test_upd_emp_id;
    END;

    PROCEDURE update_job_id_out_of_range
    IS
        test_job_id CONSTANT employees.job_id%TYPE := 'ST_MAN';
    BEGIN
        UPDATE employees
        SET    job_id      = test_job_id
        WHERE  employee_id = test_upd_emp_id;
    END;

    PROCEDURE update_both_out_of_range
    IS
        test_salary CONSTANT employees.salary%TYPE := 12000;
        test_job_id CONSTANT employees.job_id%TYPE := 'ST_MAN';
    BEGIN
        UPDATE employees
        SET    job_id      = test_job_id,
               salary      = test_salary
        WHERE  employee_id = test_upd_emp_id;
    END;

    -- Test utilities from here

    -- Get all employees except the one identified
    FUNCTION get_unchanged(
        employee_id employees.employee_id%TYPE
    )
    RETURN SYS_REFCURSOR
    IS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
        SELECT e.*
        FROM   employees e
        WHERE  e.employee_id != get_unchanged.employee_id
        ORDER BY
               e.employee_id;
        
        RETURN cur;
    END get_unchanged;

    -- INSERT new row (set non NULL columns and salary)
    PROCEDURE perform_insert(
        salary employees.salary%TYPE
    )
    IS
    BEGIN
        INSERT INTO
            employees(
                employee_id,
                last_name,
                email,
                hire_date,
                job_id,
                salary
        )
        VALUES (
                test_new_emp_id,
                'SAWYER',
                'TSAWYER',
                SYSDATE,
                test_new_job_id,
                perform_insert.salary
        );
    END;

    -- Most checks for working updates are the same
    PROCEDURE test_working_update(
        unchanged_before SYS_REFCURSOR,
        count_before     PLS_INTEGER,
        expected_salary  employees.salary%TYPE,
        expected_job_id  employees.job_id%TYPE
    )
    IS
        unchanged_after  SYS_REFCURSOR;
        count_after      PLS_INTEGER;
        salary_after     employees.salary%TYPE;
        job_id_after     employees.job_id%TYPE;
    BEGIN
        -- UPDATE has already occurred at this point

        -- Get data after UPDATE
        unchanged_after := get_unchanged(
            employee_id => test_upd_emp_id);

        SELECT COUNT(*)
        INTO   count_after
        FROM   employees;

        -- Assert
        ut.expect(unchanged_after)
            .to_equal(unchanged_before)
            .join_by('EMPLOYEE_ID');

        ut.expect(count_after).to_equal(count_before);

        -- This SELECT could throw NO_DATA_FOUND, which would be a failure
        -- Exception is caught by calling procedure
        SELECT e.salary, e.job_id
        INTO   salary_after, job_id_after
        FROM   employees e
        WHERE  e.employee_id = test_upd_emp_id;

        ut.expect(salary_after).to_equal(expected_salary);
        ut.expect(job_id_after).to_equal(expected_job_id);
    END test_working_update;

END test_insert_update_trigger;
/

