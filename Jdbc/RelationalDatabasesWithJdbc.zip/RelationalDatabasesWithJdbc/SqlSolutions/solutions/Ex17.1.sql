
-- Drop the benefits table to start fresh
DROP TABLE benefits;

-- 1
CREATE TABLE benefits (
    benefit_id             NUMBER(3)    NOT NULL,
    benefit_name           VARCHAR2(25),
    benefit_type           VARCHAR2(20) DEFAULT 'HEALTH CARE',
    benefit_effective_date DATE,
    benefit_max_allowance  NUMBER(8,2)
);

-- Make benefit_id the primary key
-- (could also have done this in the create table)
ALTER TABLE benefits
    ADD CONSTRAINT benefits_pk PRIMARY KEY(benefit_id);

-- 2
DESCRIBE benefits;

-- 3
-- drop the sequence so we can start fresh
DROP SEQUENCE seq_benefits;
CREATE SEQUENCE seq_benefits 
    INCREMENT BY 1 START WITH 1;

-- 4
INSERT INTO
       benefits
VALUES (
       seq_benefits.NEXTVAL,
       '401K',
       'Retirement' ,
       DATE '2010-01-01',
       250000.00
);

-- 5
INSERT INTO
       benefits (
           benefit_id,
           benefit_name,
           benefit_type,
           benefit_effective_date,
           benefit_max_allowance
       )
VALUES (
       seq_benefits.NEXTVAL,
       'Medical PPO',
       'Health' ,
       DATE '2011-01-01',
       100000.00
);

-- 6
INSERT INTO
       benefits(
           benefit_id,
           benefit_name,
           benefit_type,
           benefit_effective_date,
           benefit_max_allowance
       )
VALUES (
       seq_benefits.NEXTVAL,
       'Medical Ins',
       DEFAULT,
       DATE '2012-01-01',
       125000.00
);

-- 7
SELECT *
FROM   benefits;

-- 8
INSERT INTO
       benefits (
           benefit_id,
           benefit_name,
           benefit_effective_date,
           benefit_max_allowance
       )
VALUES (
       seq_benefits.NEXTVAL,
       'No default name provided' ,
       DATE '2013-01-01',
       150000.00
);

-- 9
SELECT *
FROM   benefits;

-- 10
UPDATE benefits
SET    benefit_type = DEFAULT
WHERE  benefit_type LIKE 'H%';

-- 11
SELECT *
FROM   benefits;

-- 12
COMMIT;

-- 13
CREATE OR REPLACE VIEW vw_h_b
AS
    SELECT benefit_id ,
           benefit_name,
           benefit_type,
           benefit_max_allowance
    FROM   benefits
    WHERE  benefit_type LIKE 'HEALTH%';

-- 14
DESCRIBE vw_h_b
  
-- 15
SELECT *
FROM   vw_h_b;

-- 16
-- this will fail since the table is not empty
ALTER TABLE benefits
  ADD (max_dependents NUMBER(2) NOT NULL);

-- 17
ALTER TABLE benefits
  ADD (max_dependents NUMBER(2) DEFAULT 0 NOT NULL);

-- 18
SELECT *
FROM   benefits;

-- 19
SELECT *
FROM   vw_h_b;


-- BONUS

-- 20
ALTER TABLE benefits
  MODIFY (benefit_name VARCHAR2(50));

DESCRIBE benefits

-- 21
-- This will fail because the size is too small
ALTER TABLE benefits
  MODIFY (benefit_name VARCHAR2(20));

-- 22
INSERT INTO
       benefits(
           benefit_id,
           benefit_name,
           benefit_type,
           benefit_effective_date,
           benefit_max_allowance,
           max_dependents
       )
SELECT seq_benefits.NEXTVAL,
       benefit_name,
       benefit_type,
       benefit_effective_date,
       benefit_max_allowance,
       max_dependents
FROM   benefits;

-- 23
SELECT *
FROM   benefits;

-- 24
ROLLBACK;
  
-- 25
INSERT INTO
       benefits(
           benefit_id,
           benefit_name,
           benefit_type,
           benefit_effective_date,
           benefit_max_allowance,
           max_dependents
       )
SELECT seq_benefits.NEXTVAL,
       benefit_name,
       benefit_type,
       benefit_effective_date,
       benefit_max_allowance,
       max_dependents
FROM   benefits;

-- 26
SELECT *
FROM   benefits;
