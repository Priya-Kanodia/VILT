
-- 1
SELECT COUNT(*) AS "Count" 
FROM   emp;

-- 2
SELECT empno, ename, sal, comm 
FROM   emp
ORDER BY
       sal;

-- 3
SELECT COUNT(sal) AS "Count",
       COUNT(DISTINCT sal) AS "CDistinct"
FROM   emp;

-- 4
SELECT COUNT(comm) AS "Count",
       SUM(comm)   AS "Sum",
       AVG(comm)   AS "Average"
FROM emp;

-- 5
SELECT COUNT(comm) AS "Count",
       SUM(comm)   AS "Sum",
       AVG(comm)   AS "Average",
       ROUND(AVG(COALESCE(comm, 0)), 3)
                   AS "Average of all Records"
FROM   emp;

-- 6
SELECT MAX(sal) AS "Maximum Salary",
       MIN(sal) AS "Minimum Salary"
FROM   emp;

-- 7
SELECT MAX(hiredate) "Maximum Hire Date", 
       MIN(hiredate) "Minimum Hire Date"
FROM   emp;
