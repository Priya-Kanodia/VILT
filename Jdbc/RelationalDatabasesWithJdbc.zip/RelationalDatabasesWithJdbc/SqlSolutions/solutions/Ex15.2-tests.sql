CREATE OR REPLACE PACKAGE test_update_salary
IS
    --%suite(Tests for proc_update_salary)
    
    --%test(Updates if salary is in range)
    PROCEDURE salary_in_range;

    --%test(Does not update if salary is below minimum)
    PROCEDURE salary_below_minimum;

    --%test(Returns false if salary is above maximum)
    PROCEDURE salary_above_maximum;

    --%test(Checks a second employee_id)
    PROCEDURE check_second_employee_id;

    --%test(Throws exception for NULL employee_id)
    --%throws(-20001)
    PROCEDURE exception_for_null_employee_id;

    -- could use "throws", as above, but this is an alternative 
    -- that allows us to check no data was updated
    --%test(Throws exception for NULL salary)
    PROCEDURE exception_for_null_salary;

    --%test(Does nothing if employee_id does not exist)
    PROCEDURE employee_id_does_not_exist;

END test_update_salary;
/

CREATE OR REPLACE PACKAGE BODY test_update_salary
IS

    PROCEDURE check_normal_function(
        test_emp_id employees.employee_id%TYPE,
        test_salary employees.salary%TYPE
    );

    PROCEDURE salary_in_range
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := 110;
        test_salary CONSTANT employees.salary%TYPE := 8500;
    BEGIN
        check_normal_function(
            test_emp_id => test_emp_id,
            test_salary => test_salary
        );
    END salary_in_range;

    FUNCTION get_all_as_cursor RETURN SYS_REFCURSOR;

    PROCEDURE salary_below_minimum
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := 110;
        test_salary CONSTANT employees.salary%TYPE := 4000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
    BEGIN
        -- prepare expected and before data
        unchanged_before := get_all_as_cursor;

        -- execute
        proc_update_salary(employee_id => test_emp_id, 
                    salary => test_salary);
        
        -- check results
        unchanged_after := get_all_as_cursor;

        ut.expect(unchanged_after).to_equal(unchanged_before);

    END salary_below_minimum;

    PROCEDURE salary_above_maximum
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := 110;
        test_salary CONSTANT employees.salary%TYPE := 10000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
    BEGIN
        -- prepare expected and before data
        unchanged_before := get_all_as_cursor;

        -- execute
        proc_update_salary(employee_id => test_emp_id, 
                    salary => test_salary);
        
        -- check results
        unchanged_after := get_all_as_cursor;

        ut.expect(unchanged_after).to_equal(unchanged_before);

    END salary_above_maximum;
    
    PROCEDURE check_second_employee_id
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := 107;
        test_salary CONSTANT employees.salary%TYPE := 5000;
    BEGIN
        check_normal_function(
            test_emp_id => test_emp_id,
            test_salary => test_salary
        );
    END check_second_employee_id;

    PROCEDURE exception_for_null_employee_id
    IS
    BEGIN
        proc_update_salary(NULL, 4000);
    END exception_for_null_employee_id;

    PROCEDURE exception_for_null_salary
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := 110;
        test_salary CONSTANT employees.salary%TYPE := NULL;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
    BEGIN
        -- prepare expected and before data
        unchanged_before := get_all_as_cursor;

        -- execute
        proc_update_salary(employee_id => test_emp_id, 
                    salary => test_salary);
        
        -- there is no fail function
        ut.expect(1).to_equal(0);
    EXCEPTION
        WHEN OTHERS THEN
            ut.expect(SQLCODE).to_equal(-20001);

            -- check results
            unchanged_after := get_all_as_cursor;
    
            ut.expect(unchanged_after).to_equal(unchanged_before);
    END exception_for_null_salary;

    PROCEDURE employee_id_does_not_exist
    IS
        test_emp_id CONSTANT employees.employee_id%TYPE := -1;
        test_salary CONSTANT employees.salary%TYPE := 5000;
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
    BEGIN
        -- prepare expected and before data
        unchanged_before := get_all_as_cursor;

        -- execute
        proc_update_salary(employee_id => test_emp_id, 
                    salary => test_salary);
        
        -- check results
        unchanged_after := get_all_as_cursor;

        ut.expect(unchanged_after).to_equal(unchanged_before);

    END employee_id_does_not_exist;

    -- Utilities from here
    FUNCTION get_all_as_cursor
    RETURN SYS_REFCURSOR
    IS
        cur SYS_REFCURSOR;
    BEGIN
        OPEN cur FOR
        SELECT *
        FROM   employees
        ORDER BY
               employee_id;
        
        RETURN cur;
    END;

    PROCEDURE check_normal_function(
        test_emp_id employees.employee_id%TYPE,
        test_salary employees.salary%TYPE
    )
    IS
        unchanged_before SYS_REFCURSOR;
        unchanged_after  SYS_REFCURSOR;
        expected         SYS_REFCURSOR;
        actual           SYS_REFCURSOR;
        actual_salary    employees.salary%TYPE;
    BEGIN
        -- prepare expected and before data
        OPEN unchanged_before FOR
        SELECT *
        FROM   employees
        WHERE  employee_id != test_emp_id
        ORDER BY employee_id;

        OPEN expected FOR
        SELECT *
        FROM   employees
        WHERE  employee_id = test_emp_id;
        
        -- execute
        proc_update_salary(employee_id => test_emp_id, 
                    salary => test_salary);
        
        -- check results
        OPEN actual FOR
        SELECT *
        FROM   employees
        WHERE  employee_id = test_emp_id;

        SELECT salary
        INTO   actual_salary
        FROM   employees
        WHERE  employee_id = test_emp_id;

        OPEN unchanged_after FOR
        SELECT *
        FROM   employees
        WHERE  employee_id != test_emp_id
        ORDER BY employee_id;

        ut.expect(actual).to_equal(expected).exclude('SALARY');
        ut.expect(actual_salary).to_equal(test_salary);        
        ut.expect(unchanged_after).to_equal(unchanged_before);

    END check_normal_function;

END test_update_salary;
/

