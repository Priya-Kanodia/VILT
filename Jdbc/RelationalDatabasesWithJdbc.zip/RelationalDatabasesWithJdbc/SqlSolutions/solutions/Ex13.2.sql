
SET SERVEROUTPUT ON;

SELECT *
FROM   employees
WHERE  hire_date < DATE '2003-01-01';

-- 1-8
DECLARE
    CURSOR emp_cur(
      in_hire_date DATE
    )
    IS
        SELECT *
        FROM   employees
        WHERE  hire_date < in_hire_date
        FOR UPDATE;
    emp_rec emp_cur%ROWTYPE;
    raise   employees.salary%TYPE := 5000;
    v_date  DATE                  := DATE '2003-01-01';
BEGIN
    OPEN emp_cur( v_date );
    LOOP
        FETCH emp_cur INTO emp_rec;
        EXIT WHEN emp_cur%NOTFOUND;
        
        DBMS_OUTPUT.PUT_LINE('Updating '
                              || emp_rec.employee_id
                              || ' '
                              || emp_rec.last_name
                              || ' from '
                              || emp_rec.salary);
 
        UPDATE employees
        SET    salary = salary + raise
        WHERE CURRENT OF emp_cur;
    END LOOP;
    
    CLOSE emp_cur;
END;
/

SELECT *
FROM   employees
WHERE  hire_date < DATE '2003-01-01';

-- 9
ROLLBACK;


-- 10
DECLARE
    CURSOR emp_cur(
      in_hire_date DATE
    )
    IS
        SELECT *
        FROM   employees
        WHERE  hire_date < in_hire_date
        FOR UPDATE;
    new_salary employees.salary%TYPE := 11000;
    v_date     DATE                  := DATE '2003-01-01';
BEGIN
    FOR emp_rec IN emp_cur( v_date ) LOOP
        DBMS_OUTPUT.PUT_LINE('Updating '
                              || emp_rec.employee_id
                              || ' '
                              || emp_rec.last_name
                              || ' from '
                              || emp_rec.salary);
 
        UPDATE employees
        SET    salary = new_salary
        WHERE CURRENT OF emp_cur;
    END LOOP;
END;
/

SELECT *
FROM   employees
WHERE  hire_date < DATE '2003-01-01';

-- 11
ROLLBACK;

