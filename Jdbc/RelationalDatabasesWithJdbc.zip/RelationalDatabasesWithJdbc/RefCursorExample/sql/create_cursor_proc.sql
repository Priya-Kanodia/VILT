CREATE OR REPLACE PROCEDURE get_emp_by_dept (
    parm_deptno dept.deptno%TYPE,
    parm_emp_cur OUT SYS_REFCURSOR
)   
IS   
BEGIN   
    OPEN parm_emp_cur FOR 
        SELECT empno, ename, job, mgr, hiredate, sal, comm, deptno 
        FROM   emp
        WHERE  deptno = parm_deptno;
END;
/
