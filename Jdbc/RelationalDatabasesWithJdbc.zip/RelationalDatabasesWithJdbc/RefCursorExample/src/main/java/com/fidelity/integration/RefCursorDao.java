package com.fidelity.integration;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.fidelity.model.Employee;

import oracle.jdbc.OracleTypes;

public class RefCursorDao {
	
	public List<Employee> queryEmployeesByDepartment(int deptNumber) {
		String sql = "{CALL get_emp_by_dept(?, ?)}";
		List<Employee> emps = new ArrayList<>();
		Connection conn = getConnection();
		try (CallableStatement stmt = conn.prepareCall(sql)) {
			stmt.setInt(1, deptNumber);
			stmt.registerOutParameter(2, OracleTypes.CURSOR);
			stmt.executeUpdate();
			ResultSet rs = (ResultSet) stmt.getObject(2);
			while (rs.next()) {
				int empNumber = rs.getInt("empno");
				String empName = rs.getString("ename");
				String job = rs.getString("job");
				int mgr = rs.getInt("mgr");
				LocalDate hiredate = (rs.getDate("hiredate") == null) ? null : rs.getDate("hiredate").toLocalDate();
				double sal = rs.getDouble("sal");
				double comm = rs.getDouble("comm");
				int deptno = rs.getInt("deptno");
				emps.add(new Employee(empNumber, empName, job, mgr, hiredate, sal, comm, deptno));
			}
		} catch (SQLException e) {
			throw new DatabaseException("Cannot call proc get_emp_by_dept " + sql, e);
		}
		return emps;
	}
	
	private Connection conn;

	private Connection getConnection() {
		
		if (conn == null) {
			try {
				Properties properties = new Properties();
				properties.load(this.getClass().getClassLoader()
						.getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");
				
				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				throw new DatabaseException("Cannot read database properties file", e);
			} catch (SQLException e) {
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

	public void close() {
		if (conn != null) {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
