package com.fidelity.integration;


public class DatabaseException extends RuntimeException {

	// Appease the serialization gods
	private static final long serialVersionUID = -4052645550360688064L;

	public DatabaseException() {
		super();
		// do nothing
	}

	protected DatabaseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// do nothing
	}

	public DatabaseException(String message, Throwable cause) {
		super(message, cause);
		// do nothing
	}

	public DatabaseException(String message) {
		super(message);
		// do nothing
	}

	public DatabaseException(Throwable cause) {
		super(cause);
		// do nothing
	}

}
